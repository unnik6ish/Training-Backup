import axios from 'axios';
import { useState } from 'react'
import { Button, Form, Table } from 'react-bootstrap'

const Front = () => {

  const [depts, setDepts] = useState([]);
  const [deptID, setdeptID] = useState(0);
  const [deptName, setdeptName] = useState(``);
  const [location, setLocation] = useState(``);

  const enterId =(event) =>
  {
    setdeptID(event.target.value)
  }
  const enterName =(event) =>
  {
    setdeptName(event.target.value)
  }
  const enterLocation =(event) =>
  {
    setLocation(event.target.value)
  }
  var url = `http://localhost:8080/department/`
  const api = axios.create({
    baseURL: `http://localhost:8080/department/`
})

async function findDetails() 
{
  var object
  var arr = [];
  await axios.get(`http://localhost:8080/department/${deptID}`)
    .then(response => 
      object =  response.data
      ) 
    .catch(error => console.log(error))

  console.log(depts);
  console.log(arr.push(object))
  setDepts( arr)
}

  const findAllDetails = () => 
  {
    axios.get(url)
      .then(response => setDepts(response.data))
      .catch(error => console.log(error))
    console.log(depts);
  }

  const saveDetails = () => 
  {
      var newDept = 
      {   
        "deptId":deptID,
        "deptName":deptName,
        "location":location
      }
      api.post(`/`, newDept)
                  .then(response => { console.log(response) })
                  .catch(err => console.log(err))

  }
  const updateDetails = () => 
  {
    var newDept = 
    {   
      "deptId":deptID,
      "deptName":deptName,
      "location":location
    }
    api.put(`/`, newDept)
                .then(response => { console.log(response) })
                .catch(err => console.log(err))
      findAllDetails()        
  }

  let deleteDetails = ()=>
  {
    var delDept = {
        "deptId": deptID,
        "deptName": deptName,
        "location": location
    } 
    api.delete(`/`, 
    {data: delDept})
    .then(res=>{
      console.log(res);
    })
    .catch(err=> {
      console.log(err);
    })
    findAllDetails();
  }

  return (
    <div>
    <Form className="mt-4  pt-4" >
    <h4 className="mb-3">Department Details</h4>
      <Form.Group className="mb-3">
        <Form.Control type="number" placeholder="Enter department ID" autoComplete="off" onChange={enterId}/>
      </Form.Group>

      <Form.Group className="mb-3">
        <Form.Control type="text" placeholder="Enter department Name" autoComplete="off" onChange={enterName}/>
      </Form.Group>

      <Form.Group className="mb-3">
        <Form.Control type="text" placeholder="Enter department location" autoComplete="off" onChange={enterLocation}/>
      </Form.Group>
      
      <Button className='m-2' variant="primary" type="submit" onClick={saveDetails}>Save</Button>
      <Button className='m-2'variant="primary" type="submit" onClick={updateDetails}>Update</Button>
      <Button className='m-2'variant="primary" type="submit" onClick={findDetails}>Find</Button>
      <Button className='m-2'variant="primary" type="submit" onClick={deleteDetails}>Delete</Button>
      <Button className='m-2'variant="primary" type="submit" onClick={findAllDetails}>Find All</Button>
    </Form>
      <Table className="mt-4  pt-4" striped bordered hover size="sm">
      <thead>
        <tr>
          <th>Department ID</th>
          <th>Department Name</th>
          <th>Location</th>
        </tr>
      </thead>
      <tbody>
      {depts.map((dept) =>
        <tr key={dept.deptId}>
          <td>{dept.deptId}</td>
          <td>{dept.deptName}</td>
          <td>{dept.location}</td>
        </tr>
        )}
      </tbody>
    </Table>
    </div>
  )
}

export default Front