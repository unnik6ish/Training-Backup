import './App.css';
import Front from './Components/Front';

function App() {
  return (
    <div className="App">
      <Front/>
    </div>
  );
}

export default App;
