package com.example.demo.controller;

import com.example.demo.model.NetflixUsers;
import com.example.demo.service.NetflixUserService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
public class NetflixUserControllerTest {

    private MockMvc mockMvc;
    @Mock
    NetflixUserService netflixService;
    @InjectMocks
    private NetflixController netflixController;

    private NetflixUsers netflixUsers;
    private List<NetflixUsers> netflisUserList;


    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(netflixController).build();
        netflixUsers = new NetflixUsers();
        netflixUsers.setId("Roger");
        netflixUsers.setName("Blog1");
        netflixUsers.setEmailid("Sample content");
        netflixUsers.setMobno((long) 1234567891);
        netflixUsers.setPassword("Imneet");
        netflisUserList = new ArrayList<>();
        netflisUserList.add(netflixUsers);
    }

    @AfterEach
    public void tearDown() {
    	netflixUsers = null;
    }

    @Test
    public void givenNetflixUserToSaveThenShouldReturnSavedNetflixUsers() throws Exception {
        when(netflixService.registerUser(any())).thenReturn(netflixUsers);
        mockMvc.perform(post("/netflixusers")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(netflixUsers)))
                .andExpect(status().isCreated())
                .andDo(MockMvcResultHandlers.print());
        verify(netflixService).registerUser(any());
    }

    @Test
    public void givenGetAllNetflixUsersThenShouldReturnListOfAllNetflixUsers() throws Exception {
        when(netflixService.getAllUser()).thenReturn(netflisUserList);
        mockMvc.perform(MockMvcRequestBuilders.get("/netflixusers")
                .contentType(MediaType.APPLICATION_JSON).content(asJsonString(netflixUsers)))
                .andDo(MockMvcResultHandlers.print());
        verify(netflixService).getAllUser();
        verify(netflixService, times(1)).getAllUser();

    }

    @Test
    void givenNetflixUserIdThenShouldReturnRespectiveNetflixUser() throws Exception {
        when(netflixService.findUserbyId(netflixUsers.getId())).thenReturn(netflixUsers);
        mockMvc.perform(get("/netflixusers/Roger"))
                .andExpect(MockMvcResultMatchers.status()
                        .isOk())
                .andDo(MockMvcResultHandlers.print());

    }

    @Test
    public void givenNetflixUserIdToDeleteThenShouldNotReturnDeletedNetflixUser() throws Exception {
        when(netflixService.deleteAUser(netflixUsers.getId())).thenReturn(netflixUsers);
        mockMvc.perform(delete("/netflixusers/Roger")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(netflixUsers)))
                .andExpect(MockMvcResultMatchers.status().isAccepted()).andDo(MockMvcResultHandlers.print());
    }

    @Test
    public void givenNetflixUserToUpdateThenShouldReturnUpdatedNetflixUser() throws Exception {
        when(netflixService.updateAUser(any())).thenReturn(netflixUsers);
        mockMvc.perform(put("/netflixusers").contentType(MediaType.APPLICATION_JSON).content(asJsonString(netflixUsers)))
                .andExpect(status().isCreated()).andDo(MockMvcResultHandlers.print());
    }

    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}


