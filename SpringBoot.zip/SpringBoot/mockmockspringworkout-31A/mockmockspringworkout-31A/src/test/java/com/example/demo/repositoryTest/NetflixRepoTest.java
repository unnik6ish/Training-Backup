package com.example.demo.repositoryTest;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.model.NetflixUsers;
import com.example.demo.repository.NetflixUserRepo;

@SpringBootTest
public class NetflixRepoTest {
		
	@Autowired
    private NetflixUserRepo netRepo;
    private NetflixUsers netflixUsers;

    @BeforeEach
    public void setUp() {
    	netflixUsers = new NetflixUsers();
    	netflixUsers.setId("Roger");
    	netflixUsers.setName("Blog1");
    	netflixUsers.setEmailid("Sample content");
    	netflixUsers.setMobno((long) 1234567891);
    	netflixUsers.setPassword("Imneet");

    }
    
    @AfterEach
    public void tearDown() {
    	netRepo.deleteAll();
    	netflixUsers = null;
    }
    
    @Test
    public void givenNetflixUserToSaveThenShouldReturnSavedNetflixUser() {
    	netRepo.save(netflixUsers);
    	NetflixUsers fetchedUsers = netRepo.findById(netflixUsers.getId()).get();
        assertEquals(5, fetchedUsers.getId().length());
    }


    @Test
    public void givenGetAllNetflixUsersThenShouldReturnListOfAllNetflixUsers() {
    	NetflixUsers netflixUsers = new NetflixUsers("Roger", "William", "william125@gmail.com", (long) 1234567891, "Root12345");
    	NetflixUsers netflixUsers1 = new NetflixUsers("prasad", "Sankar", "Hari125@gmail.com", (long) 944215854, "Hari12345");
    	netRepo.save(netflixUsers);
    	netRepo.save(netflixUsers1);

        List<NetflixUsers> blogList = (List<NetflixUsers>) netRepo.findAll();
        assertEquals("William", blogList.get(1).getName());
    }

    @Test
    public void givenNetflixUserIdThenShouldReturnRespectiveNetflixUser() {
    	NetflixUsers netflixUsers = new NetflixUsers("Roger", "William", "william125@gmail.com", (long) 1234567891, "Root12345");
    	NetflixUsers netflixUsers1 = netRepo.save(netflixUsers);
        Optional<NetflixUsers> optional = netRepo.findById(netflixUsers1.getId());
        assertEquals(netflixUsers1.getId(), optional.get().getId());
        assertEquals(netflixUsers1.getName(), optional.get().getName());
        assertEquals(netflixUsers1.getEmailid(), optional.get().getEmailid());
        assertEquals(netflixUsers1.getMobno(), optional.get().getMobno());
        assertEquals(netflixUsers1.getPassword(), optional.get().getPassword());

    }
    
    @Test
    public void givenNetflixUserIdToDeleteThenShouldReturnDeletedNetflixUser() {
    	NetflixUsers netflixUsers = new NetflixUsers("Roger", "William", "william125@gmail.com", (long) 1234567891, "Root12345");
    	netRepo.save(netflixUsers);
    	netRepo.deleteById(netflixUsers.getId());
        Optional optional = netRepo.findById(netflixUsers.getId());
        assertEquals(Optional.empty(), optional);
    }



    
}