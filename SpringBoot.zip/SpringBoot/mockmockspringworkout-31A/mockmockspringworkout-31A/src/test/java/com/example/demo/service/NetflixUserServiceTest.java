package com.example.demo.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.demo.exception.UserAlreadyExistException;
import com.example.demo.exception.UserNotFoundException;
import com.example.demo.model.NetflixUsers;
import com.example.demo.repository.NetflixUserRepo;

@ExtendWith(MockitoExtension.class)
public class NetflixUserServiceTest {
	
	@Mock
    private NetflixUserRepo netRepo;
	
	@InjectMocks
    private NetflixUserServiceImpl  netflixService;
    private NetflixUsers netflixUsers,netflixUsers1;
    private List<NetflixUsers> netflisUserList;
    private Optional optional;

    
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        netflixUsers = new NetflixUsers("Roger", "William", "william125@gmail.com", (long) 1234567891, "Root12345");
        netflixUsers1 = new NetflixUsers("prasad", "Sankar", "Hari125@gmail.com", (long) 944215854, "Hari12345");
        optional = Optional.of(netflixUsers);
    }


    @AfterEach
    public void tearDown() {
    	netflixUsers = null;
    }

    @Test
    public void givenNetflixUserToSaveThenShouldReturnSavedNetflixUser() throws UserAlreadyExistException {
        when(netRepo.save(any())).thenReturn(netflixUsers);
        assertEquals(netflixUsers, netflixService.registerUser(netflixUsers));
        verify(netRepo, times(1)).save(any());
    }

    @Test
    public void givenNetflixUserToSaveThenShouldNotReturnSavedNetflixUser() {
        when(netRepo.save(any())).thenThrow(new RuntimeException());
        Assertions.assertThrows(RuntimeException.class,() -> {
        	netflixService.registerUser(netflixUsers);
        });
        verify(netRepo, times(1)).save(any());
    }

    @Test
    public void givenGetAllNetflixUsersThenShouldReturnListOfAllNetflixUsers() {
    	netRepo.save(netflixUsers);
        //stubbing the mock to return specific data
        when(netRepo.findAll()).thenReturn(netflisUserList);
        List<NetflixUsers> netflisUserList1 = netflixService.getAllUser();
        assertEquals(netflisUserList, netflisUserList1);
        verify(netRepo, times(1)).save(netflixUsers);
        verify(netRepo, times(1)).findAll();
    }

    @Test
    public void givenNetflixUserIdThenShouldReturnRespectiveNetflixUser() throws UserNotFoundException {
        when(netRepo.findById(anyString())).thenReturn(Optional.of(netflixUsers));
        NetflixUsers retrievedNetflixUser = netflixService.findUserbyId(netflixUsers.getId());
        verify(netRepo, times(1)).findById(anyString());

    }

   
    @Test
    void givenNetflixUserIdToDeleteThenShouldReturnDeletedNetflixUser() {
        when(netRepo.findById(netflixUsers.getId())).thenReturn(optional);
        NetflixUsers deletedNetflixUser = netflixService.deleteAUser("Roger");
        assertEquals("Roger", deletedNetflixUser.getId());

        verify(netRepo, times(2)).findById(netflixUsers.getId());
        verify(netRepo, times(1)).deleteById(netflixUsers.getId());
    }

    @Test
    void givenNetflixUserIdToDeleteThenShouldNotReturnDeletedNetflixUser() {
        when(netRepo.findById(netflixUsers.getId())).thenReturn(Optional.empty());
        NetflixUsers deletedNetflixUser = netflixService.deleteAUser("Roger");
        verify(netRepo, times(1)).findById(netflixUsers.getId());
    }
    
    @Test
    public void givenNetflixUserToUpdateThenShouldReturnUpdatedNetflixUser() {
        when(netRepo.findById(netflixUsers.getId())).thenReturn(optional);
        when(netRepo.save(netflixUsers)).thenReturn(netflixUsers);
        netflixUsers.setEmailid("william125@gmail.com");
        NetflixUsers netflixUsers1 = netflixService.updateAUser(netflixUsers);
        assertEquals(netflixUsers1.getEmailid(), "william125@gmail.com");
        verify(netRepo, times(1)).save(netflixUsers);
        verify(netRepo, times(2)).findById(netflixUsers.getId());
    }

    @Test
    public void givenNetflixUserToUpdateThenShouldNotReturnUpdatedNetflixUser() {
        when(netRepo.findById(netflixUsers.getId())).thenReturn(Optional.empty());
        NetflixUsers netflixUsers1 = netflixService.updateAUser(netflixUsers);
        assertNull(netflixUsers1);
        verify(netRepo, times(1)).findById(netflixUsers.getId());
    }


}
