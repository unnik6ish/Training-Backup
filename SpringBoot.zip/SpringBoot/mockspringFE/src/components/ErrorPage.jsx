import React from 'react'

const ErrorPage = () => {
  return (
    <div>
        <center>
        <h2>404 Page Not found</h2>
        </center>
    </div>
  )
}

export default ErrorPage