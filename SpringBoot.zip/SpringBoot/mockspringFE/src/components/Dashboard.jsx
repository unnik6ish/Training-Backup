import React from 'react'
import { Button } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom';


const Dashboard = () => {

  const navigate = useNavigate();

  const logout = () => {
    localStorage.removeItem("user");
     navigate("/login")
    window.location.reload(); 
  };

  return (
    <div>Dashboard

      <Button onClick={logout} > Logout </Button>
    </div>
  )
}

export default Dashboard