import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Button, Col, Container, FloatingLabel, Form, Row } from 'react-bootstrap'
import { useDispatch } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom'
import { login } from '../Features/UserSlice' 
import bcrypt from 'bcryptjs';

const Login = () => {

    const [username, setUsername] = useState(``);
    const [password, setPassword] = useState(``);
    const [userDetails, setUserDetails] = useState([]);
    const [jwtTokenR, setJwtTokenR] = useState(``)

    var db_username = ``;
    var db_email = ``;
    var username_exists = false;
    var db_encryptedpwd = ``;
    var loginValidationStatus = false;

    const dispatch = useDispatch();
    const navigate = useNavigate();
    // console.log(jwtToken);

    useEffect(() => {

        axios.get(`http://localhost:8080/netflixusers`)
            .then(res => setUserDetails(res.data))
            .catch(err => console.log(err))

    })
    for (let i = 0; i < userDetails.length; i++) {
        if (username.toLowerCase() === (userDetails[i].id).toLowerCase()) {

            db_username = userDetails[i].id;
            db_email = userDetails[i].emailid;
            db_encryptedpwd = userDetails[i].password;
            username_exists = true
        }
    }

    // const LoginCheck = (event) => {
    async function LoginCheck(event) {

        event.preventDefault();
        // 
        loginValidationStatus = await bcrypt.compare(password, db_encryptedpwd)



        if ( username == "" || password == "" ) {
            alert(`Please fill all the details`)
        }
        else if ( !username_exists ){
            alert(`Username doesn't Exist`)
        }
        else if (!loginValidationStatus){
            alert(`Password doesnt match our records`)
        }
        else if (loginValidationStatus) {

            axios.post(`http://localhost:8080/login`, { username, password })
                .then(response => {
                    if(response.data.jwtToken){
                        localStorage.setItem("user", JSON.stringify(response.data));
                    }
                    return response.data
                })


                //     {
                //     localStorage.setItem("user", JSON.stringify(res.data.jwtToken))
                //     setJwtTokenR(res.data.jwtToken)
                //     console.log(res)
                // })
                .catch(err => console.log(err))
            alert("login success. Navigating to dashboard...")
            dispatch(login(
                {
                    username: ``,
                    email: ``,
                    loginStatus: true,
                    jwtToken: jwtTokenR
                }
    
            ))
                // setTimeout(() => {
                        
                navigate("/dashboard")  
                window.location.reload();      
                // }, 5000);
            
            }

    }

    const RouteToHomePage = () => {
        navigate('/')
    }

    const RouteToSignPage = () => {
        navigate('/signup')
    }

    return (

        <Container fluid >
            <Row className="mt-4 pt-4 ">
                <Col lg={4} md={6} sm={9} className="p-3 m-auto shadow-lg rounded-lg bg-light">
                    <Form className='bg-light'>
                        <h4 className='text-center' >Wallet Pay</h4>
                        <h6 className='mb-3 text-center ' >Welcome back! Please Login into Continue </h6>
                        <FloatingLabel controlId="floatingInput" label="Username" className="mb-3" autoComplete="off" >
                            <Form.Control type="text" placeholder="Username" onChange={(e) => setUsername(e.target.value)} />
                        </FloatingLabel>

                        <FloatingLabel controlId="floatingPassword" label="Password" className="mb-3" autoComplete="off" >
                            <Form.Control type="password" placeholder="Password" onChange={(e) => setPassword(e.target.value)} />
                        </FloatingLabel>
                        <div className='text-center span2'>
                            {/* <div className="d-grid ps-5 gap-2"> */}
                            <Button type='submit' variant="primary" className='mb-2 mt-2 m-3 btn-block' onClick={LoginCheck} >Login</Button>
                            <Button type='reset' variant="warning" className='mb-2 mt-2 btn-block' >Reset</Button>
                        </div>
                        <div className='text-center mt-2 '>
                            <Link to="/forgotpassword" >Forgot Password?</Link>
                        </div>
                        <div className='text-center mt-3 '>
                            <h6>New here? Please Sign Up</h6>
                            <Button variant="secondary" className='mb-3' onClick={RouteToSignPage} >Sign Up</Button>
                        </div>
                        <div className='text-center'>

                            <Button variant="success" className='mb-3' onClick={RouteToHomePage} >Back to Home</Button>
                        </div>
                    </Form>
                </Col>
            </Row>

        </Container>

    )
}

export default Login