import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Button, Col, Container, FloatingLabel, Form, Row } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom'

// Username (@Id)
// Name
// Email-id
// Mobile no.
// Password

const Signup = () => {
    // Getting all the userinputs as a variable    

    const [username, setUsername] = useState(``);
    const [name, setName] = useState(``);
    const [email, setEmail] = useState(``);
    const [mobNo, setMobNo] = useState(``);
    const [password, setPassword] = useState(``);

    var [netflixUsers, setNetflixUsers] = useState([]);
    // const [statusCode, setStatusCode] = useState(0);
    // const [error, setError] = useState(``)
    const navigate = useNavigate();

    const RouteToLoginPage = () => {
        navigate('/login')
    }

    const RouteToHomePage = () => {
        navigate('/')
    }


    var username_exist;
    var email_exist;


    //Regex Variable to compare
    var regExEmail = /^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,3}$/
    var regexUsername = /[A-Za-z0-9]{3,30}/
    var regexName = /[A-Za-z]{3,30}/
    var regex10digits = /^[0-9]\d{09}$/ // to validate phone no 
    var regExPwd = /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#%^&])(?!.* ).{8,20}$/

    useEffect(() => {

        axios.get(`http://localhost:8080/netflixusers`)
            .then(res => setNetflixUsers(res.data))
            .catch(err => console.log(err))

    })


    for (let i = 0; i < netflixUsers.length; i++) {
        if (username === netflixUsers[i].id) {

            username_exist = true
            // alert("username already exist")
        }

    }

    for (let i = 0; i < netflixUsers.length; i++) {
        if (email === netflixUsers[i].emailid) {

            email_exist = true
            // alert("username already exist")
        }

    }

    const SignUp = (event) => {
        // async function SignUp(event){
        event.preventDefault()
        if (!regexUsername.test(username)) {
            alert(`Userame length must be between 3 -20 characters, Only Alpha-numeric allowed`)
        }

        else if (username_exist) {
            alert(`Username already exist. Please use a different a username to continue`)
        }

        else if (!regexName.test(name)) {
            alert(`Please enter a valid name use only alphabets`)

        }

        else if (!regExEmail.test(email)) {
            alert(`Please enter a valid email id`)

        }
        else if (email_exist) {
            alert(`Email ID already exist. Please use a different email id to continue or Login`)
        }
        else if (!regex10digits.test(mobNo)) {
            alert(`Please Enter a valid 10 digit mobile number`)
        }
        else if (!regExPwd.test(password)) {
            alert(`Please create a strong password`)
        }



        else {

            var newUser = {
                "id": username,
                "name": name,
                "emailid": email,
                "mobno": mobNo,
                "password": password
            }


            axios.post(`http://localhost:8080/netflixusers`, newUser)
                .then(response => console.log(response))
                .catch(err => console.log(err))

            navigate("/login")
            alert("Sign Up successful. Redirecting to login...")

            //Backend code
            // var statusCode;
            //     var error;
            //     var errorMessage;
            //     var correctMessage;
            //  api.post(`/`, newUser)
            //         .then(response => correctMessage = response )
            //         .catch(err => error = err)
            //                         // error = err.response.data

            //                         statusCode = error.response.status
            //                         statusCode = correctMessage.response.status
            //                         errorMessage = error.response.data


            // if (statusCode != 201) {
            //     alert(errorMessage)
            // }
            // else {
            //     alert("Sign Up successful. Redirecting to login...")
            // }

        }

    }



    return (
        <div>

            <Container fluid    >
                <Row className="mt-4  pt-4">
                    <Col lg={4} md={6} sm={9} className="p-3 m-auto shadow-lg rounded-lg bg-light">
                        <Form className='bg-light'>
                            <h4 className='text-center ' >Netflix</h4>
                            <h6 className='mb-3 text-center ' >Join and Binge</h6>
                            <FloatingLabel controlId="floatingInput" label="Email Address" className="mb-3" autoComplete="off" >
                                <Form.Control type="email" placeholder="name@example.com" onChange={(e) => setEmail(e.target.value)} />
                            </FloatingLabel>
                            <FloatingLabel controlId="floatingInput" label="Username" className="mb-3" autoComplete="off" >
                                <Form.Control type="text" placeholder="Username" onChange={(e) => setUsername(e.target.value)} />
                                <Form.Text className="text-muted">
                                Username length must be between 3 -20 characters, Only Alpha-numeric allowed
                                </Form.Text>
                            </FloatingLabel>
                            <FloatingLabel controlId="floatingInput" label="Name" className="mb-3" autoComplete="off" >
                                <Form.Control type="text" placeholder="Name" onChange={(e) => setName(e.target.value)} />
                                <Form.Text className="text-muted">
                                Please use only alphabets
                                </Form.Text>
                            </FloatingLabel>
                            <FloatingLabel controlId="floatingInput" label="Mobile Number" className="mb-3" autoComplete="off" >
                                <Form.Control type="number" placeholder="Mobile Number" onChange={(e) => setMobNo(e.target.value)} />
                                <Form.Text className="text-muted">
                                    Please Enter Your 10 digit mobile number
                                </Form.Text>
                            </FloatingLabel>
                            <FloatingLabel controlId="floatingPassword" label="Password" className="mb-3" autoComplete="off" >
                                <Form.Control type="password" placeholder="Password" onChange={(e) => setPassword(e.target.value)} />
                                <Form.Text className="text-muted">
                                    Your password should contain atleast 8 characters. Must Contain 1 uppercase,  1 lowercase, 1 numeric and atleast 1 symbols ( @ # % ^ & - _ )
                                </Form.Text>
                            </FloatingLabel>
                            <div className='text-center span2'>
                                {/* <div className="d-grid ps-5 gap-2"> */}
                                <Button type='submit' variant="primary" className='mb-2 mt-2 m-3 btn-block' onClick={SignUp} >Sign Up</Button>
                                <Button type='reset' variant="warning" className='mb-2 mt-2 btn-block' >Reset</Button>
                            </div>
                            <div className='text-center mt-3'>
                                <h6>Already have an account?</h6>
                                
                                <Button variant="secondary" className='mb-3' onClick={RouteToLoginPage} >Login</Button>

                            </div>
                            <div className='text-center'>
                                
                                <Button variant="success" className='mb-3' onClick={RouteToHomePage} >Back to Home</Button>
                            </div>
                        </Form>
                    </Col>
                </Row>

            </Container>



        </div>
    )
}

export default Signup