import { Link, Route, Routes } from 'react-router-dom';
import Login from "./components/Login";
import Signup from "./components/Signup";
import Homepage from "./components/Homepage";
import ForgotPassword from "./components/ForgotPassword";
import Dashboard from './components/Dashboard';
import AuthService from './Auth/AuthSevice';
import { useEffect, useState } from 'react';
import Unknown from './components/Unknown';

// https://medium.com/codex/json-web-token-authentication-on-react-redux-982e5f003422

function App() {
  const [currentUser, setCurrentUser] = useState(undefined);

  useEffect(() => {
    const user = AuthService.getCurrentUser();

    if (user) {
      setCurrentUser(user);
    }
  }, []);
  // const [currentUser, setCurrentUser] = useState(``);
  // useEffect(() => {
  //   const user = AuthService.getCurrentUser();

  //   if (user) {
  //     setCurrentUser(user);
  //     console.log(user);
  //   }
  // }, []);

  // useEffect(() => {
  //   const user = AuthService.getCurrentUser();

  //   if (user) {
  //     setCurrentUser(user);
  //   }
  // }, []);


  // const logOut = () => {
  //   AuthService.logout();
  // };

  return (
    <div>




      <Routes>
        {/* <Homepage /> */}
        <Route path='/' element={<Homepage />} />
        <Route path='/login' element={<Login />} />
        <Route path='/signup' element={<Signup />} />
        <Route path='/forgotpassword' element={<ForgotPassword />} />
        {currentUser && (
          <Route path='/dashboard' element={<Dashboard />} />
        )}

        {/* <Route path='*' element={<Unknown />} /> */}

      </Routes>

    </div>
  );
}

export default App;
