import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Button, Col, Container, FloatingLabel, Form, Row } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom'

// Username (@Id)
// Name
// Email-id
// Mobile no.
// Password

const Signup = () => {
    // Getting all the userinputs as a variable    

    // const [username, setUsername] = useState(``);
    const [name, setName] = useState(``);
    const [email, setEmail] = useState(``);
    const [mobNo, setMobNo] = useState(``);
    const [accno, setAccno] = useState(``);
    const [address, setAddress] = useState(``);
    const [password, setPassword] = useState(``);


    const [emailError, setEmailError] = useState(``);
    const [usernameError, setUsernameError] = useState(``);
    const [addressError, setAddressError] = useState(``);
    const [accNoError, setAccNoError] = useState(``);
    const [mobNoError, setMobNoError] = useState(``);
    const [passwordError, setPasswordError] = useState(``);

    const navigate = useNavigate();

    const RoutToLoginPage = () => {
        navigate('/login')
    }

    const RoutToHomePage = () => {
        navigate('/')
    }

    var [walletUsers, setWalletUsers] = useState([]);
    // const [statusCode, setStatusCode] = useState(0);
    // const [error, setError] = useState(``)


    var name_exists;
    var email_exist;




    //Regex Variable to compare
    var regExEmail = /^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,3}$/
    var regexUsername = /[A-Za-z0-9]{3,30}/
    var regexName = /[A-Za-z]{3,30}/
    var regex10digits = /^[0-9]\d{09}$/ // to validate phone no 
    var regexAddress = /^[a-zA-Z0-9(?:_*.\-\\,\s)?]{10,100}$/
    var regExPwd = /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#%^&])(?!.* ).{8,20}$/

    //setting up base url for request
    const api = axios.create({
        baseURL: `http://localhost:8080/walletusers`
    })

    useEffect(() => {

        api.get(`http://localhost:8080/walletusers`)
            .then(res => setWalletUsers(res.data))
            .catch(err => console.log(err))

    })


    for (let i = 0; i < walletUsers.length; i++) {
        if (email === walletUsers[i].id) {

            email_exist = true
            // alert("username already exist")
        }

    }

    for (let i = 0; i < walletUsers.length; i++) {
        if (name === walletUsers[i].name) {

            name_exists = true
            // alert("username already exist")
        }

    }

    const SignUp = (event) => {
        event.preventDefault()
        if (!regexUsername.test(name)) {
            // alert(`Userame length must be between 3 -20 characters, Only Alpha-numeric allowed`)
            setUsernameError(`Userame length must be between 3 -20 characters, use only alphabets. numbers & special charaters not allowed`)
        }

        else if (name_exists) {
            alert(`Username already exist. Please use a different a username to continue`)
        }

        else if (!regexName.test(name)) {
            alert(`Please enter a valid name use only alphabets`)

        }


        else if (!regexAddress.test(address)) {
            // alert(`Address length must be between 10 -100 characters`)
            setAddressError(`Address length must be between 10 -100 characters`)
        }
        else if (!regex10digits.test(accno)) {
            setAccNoError(`Please Enter a valid 10 digit account number`)
        }
        else if (!regExEmail.test(email)) {
            // alert(`Please enter a valid email id`)
            setEmailError(`Please enter a valid email id`)

        }
        else if (email_exist) {
            alert(`Email ID already exist. Please use a different email id to continue or Login`)
        }
        else if (!regex10digits.test(mobNo)) {
            // alert(`Please Enter a valid 10 digit mobile number`)
            setMobNoError(`Please Enter a valid 10 digit mobile number`)
        }

        else if (!regExPwd.test(password)) {
            // alert(`Please create a strong password`)
            setPasswordError(`Please create a strong password`)
        }



        else {

            var newUser = {
                "id": email,
                "name": name,
                // "emailid": email,
                "mobno": mobNo,
                "accno": accno,
                "address": address,
                "password": password
            }


            axios.post(`http://localhost:8080/walletusers`, newUser)
                .then(response => console.log(response))
                .catch(err => console.log(err))

            navigate("/login")
            alert("Sign Up successful. Redirecting to login...")

            //Backend code
            // var statusCode;
            //     var error;
            //     var errorMessage;
            //     var correctMessage;
            //  api.post(`/`, newUser)
            //         .then(response => correctMessage = response )
            //         .catch(err => error = err)
            //                         // error = err.response.data

            //                         statusCode = error.response.status
            //                         statusCode = correctMessage.response.status
            //                         errorMessage = error.response.data


            // if (statusCode != 201) {
            //     alert(errorMessage)
            // }
            // else {
            //     alert("Sign Up successful. Redirecting to login...")
            // }

        }

    }

    useEffect(() => { document.body.style.backgroundColor = '#401664' }, [])




    return (
        <div style={{ backgroundColor: '#401664' }}>

            <Container fluid   >
                <Row className="pt-5 rounded">
                    <Col lg={4} md={6} sm={9} className="p-4 m-auto shadow-lg rounded-lg" style={{ backgroundColor: '#CF9FFF', borderRadius: '3%' }}>
                        <Form style={{ backgroundColor: '#CF9FFF	' }} >
                            <h3 className='text-center mb-2'>
                                <img
                                    alt=""
                                    src="https://www.bing.com/th?id=OSK.afa3a68f24db08580c55a8cdbfddaa84&w=148&h=148&c=7&o=6&dpr=1.3&pid=SANGAM"
                                    width="30"
                                    height="30"
                                    className="d-inline-block align-top"
                                />{' '}
                                Natwest Wallet Pay</h3>
                            <FloatingLabel
                                controlId="floatingInput" label="Name" className="mb-3">
                                <Form.Control type="text" placeholder="Name" autoComplete='off'

                                    onChange={(e) => {
                                        setName(e.target.value);
                                        setUsernameError(``)
                                    }}
                                    isInvalid={!!usernameError}

                                    required={true}
                                />
                                <Form.Control.Feedback type='invalid'>
                                    {usernameError}
                                </Form.Control.Feedback>

                                <Form.Text className="text-muted">
                            
                                </Form.Text>

                            </FloatingLabel>
                            <FloatingLabel
                                controlId="floatingInput" label="Address" className="mb-3">
                                <Form.Control type="text" placeholder="Address"
                                    onChange={(e) => {
                                        setAddress(e.target.value);
                                        setAddressError(``)
                                    }}
                                    isInvalid={!!addressError}

                                    required={true} />
                                <Form.Control.Feedback type='invalid'>
                                    {addressError}
                                </Form.Control.Feedback>

                                <Form.Text className="text-muted">
                                </Form.Text>
                            </FloatingLabel>
                            <FloatingLabel
                                controlId="floatingInput" label="Account No" className="mb-3">
                                <Form.Control type="number" placeholder="Account N0" required
                                    onChange={(e) => {
                                        setAccno(e.target.value);
                                        setAccNoError(``)
                                    }}
                                    isInvalid={!!accNoError}
                                />
                                <Form.Control.Feedback type='invalid'>
                                    {accNoError}
                                </Form.Control.Feedback>

                                <Form.Text className="text-muted">
                                </Form.Text>
                            </FloatingLabel>
                            <FloatingLabel
                                controlId="floatingInput" label="Email address" className="mb-3">
                                <Form.Control type="email" placeholder="name@example.com" required
                                    onChange={(e) => {
                                        setEmail(e.target.value);
                                        setEmailError(``)
                                    }}
                                    isInvalid={!!emailError}
                                />
                                <Form.Control.Feedback type='invalid'>
                                    {emailError}

                                </Form.Control.Feedback>

                                <Form.Text className="text-muted">
                                </Form.Text>

                            </FloatingLabel>
                            <FloatingLabel
                                controlId="floatingInput" label="Phone Number" >
                                <Form.Control type="number" placeholder="Phone Number" required
                                    onChange={(e) => {
                                        setMobNo(e.target.value);
                                        setMobNoError(``)
                                    }}
                                    isInvalid={!!mobNoError}
                                />
                                <Form.Control.Feedback type='invalid'>
                                    {mobNoError}
                                </Form.Control.Feedback>

                                <Form.Text className="text-muted">
                                </Form.Text>
                                <br></br>
                            </FloatingLabel>
                            <FloatingLabel controlId="floatingPassword" label="Password">
                                <Form.Control type="password" placeholder="Password" required
                                    onChange={(e) => {
                                        setPassword(e.target.value);
                                        setPasswordError(``)
                                    }}
                                    isInvalid={!!passwordError}

                                />
                                <Form.Control.Feedback type='invalid'>
                                    {passwordError}
                                </Form.Control.Feedback>

                                <Form.Text className="text-muted">
                                </Form.Text>

                            </FloatingLabel>
                            <div className='text-center span2'>
                                <Button type='submit' variant="primary" className='mb-2 mt-2 m-3 btn-block' onClick={SignUp} >Sign Up</Button>
                                <Button type='reset' variant="warning" className='mb-2 mt-2 btn-block' >Reset</Button>
                            </div>
                            <div className='text-center mt-1'>
                                <h6>Already have an account?</h6>
                                <Button variant="secondary" className='mb-3' onClick={RoutToLoginPage} >Login</Button>

                            </div>
                            <div className='text-center '>
                                <Button variant="success" className='mb-1' onClick={RoutToHomePage}>Back to Home</Button>
                            </div>
                        </Form>
                    </Col>
                </Row>

            </Container>



        </div>
    )
}

export default Signup