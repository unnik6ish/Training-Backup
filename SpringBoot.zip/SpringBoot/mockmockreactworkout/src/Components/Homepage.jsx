import React, { useEffect } from 'react'
import { Button, Card, Carousel, Col, Row } from 'react-bootstrap'
import { Container, Nav, Navbar, NavDropdown } from 'react-bootstrap';

import { useNavigate } from 'react-router-dom'
import { MDBBtn, MDBCard, MDBCardBody, MDBCardImage, MDBCardText, MDBCol, MDBContainer, MDBFooter, MDBIcon, MDBInput, MDBRow, MDBTypography } from 'mdb-react-ui-kit'

const Homepage = () => {

    const navigate=useNavigate();

   const routeToLogin=()=>{
    navigate('/login')
   }

   const routeToSignup=()=>{
    navigate('/signup')
   }

  //  useEffect(() => {
  //   window.addEventListener('popstate', (e) => {
  //     window.history.go(1);
  //   });
  // }, []);




    return (
      
        <div className='bg-dark'>

      
          {/* Navigation Bar */}
          <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
      <Container fluid>
        <Navbar.Brand href="/"> 
        <img
              alt=""
              src="https://www.bing.com/th?id=OSK.afa3a68f24db08580c55a8cdbfddaa84&w=148&h=148&c=7&o=6&dpr=1.3&pid=SANGAM"
              width="30"
              height="30"
              className="d-inline-block align-top"
            />{' '} Natwest Foreign Exchange
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link onClick={routeToLogin}>Login</Nav.Link>
            <Nav.Link onClick={routeToSignup}>SignUp</Nav.Link>
            <NavDropdown title="Services" id="collasible-nav-dropdown">
              <NavDropdown.Item>Payments</NavDropdown.Item>
              <NavDropdown.Item>
                Support
              </NavDropdown.Item>
              <NavDropdown.Item >Contact Us</NavDropdown.Item> 
            </NavDropdown>
          </Nav>
          
        </Navbar.Collapse>
      </Container>
    </Navbar>
    

    {/* cards */}

    {/* card-1 */}
    <div class="row row-cols-1 row-cols-md-3 g-8" style={{ backgroundColor: '#401664' }} >
      <div class="col" >
        <div class="card h-100" >
          <img src="https://media.istockphoto.com/photos/report-charts-picture-id477018805?k=20&m=477018805&s=612x612&w=0&h=7Xp0uIECK2Cbrggs_x4M3dIfvQries10C8YrI2PSAVQ=" class="card-img-top" alt="..."/>
          <div class="card-body" ><br></br><br></br>
            <h6 class="card-title" >Today's latest NatWest exchange rates for 35 currencies that are in stock and ready to order online now. Indicative Exchange Rates for Electronic Transfers and Payments.</h6>
            <a class="btn btn-primary block" href="https://www.compareholidaymoney.com/companies/natwest-currency-exchange-rates.php" role="button">Click to know more</a>
          </div>
          <div class="card-footer">
            <small class="text-muted">Last updated 3 mins ago</small>
          </div>
        </div>
    </div>

      {/* card-2 */}
        <div class="col" >
          <div class="card h-100">
            <img src="https://media.istockphoto.com/photos/financial-growth-of-the-business-in-the-design-of-information-related-picture-id1325195220?k=20&m=1325195220&s=612x612&w=0&h=ZYK7YTvKU5XodpdjSN-tQSNJEn0qJBfK8XLUl_YJ25Q=" class="card-img-top" alt="..."/>
            <div class="card-body" ><br></br>
              <h6 class="card-title">NatWest Group brings together new Commercial & Institutional franchise.NatWest Markets and RBS International businesses to form a single franchise.</h6>      
              <a class="btn btn-primary block" href="https://www.natwestgroup.com/news/2022/01/natwest-group-brings-together-new-commercial-institutional-franchise.html" role="button">Click to know more</a>
            </div>
            <div class="card-footer">
              <small class="text-muted">Last updated 3 mins ago</small>
            </div>
          </div>
        </div>

      {/* card-3 */}
        <div class="col">
          <div class="card h-100">
            <img src="https://media.istockphoto.com/photos/mobile-finance-and-statistics-concept-picture-id179077258?k=20&m=179077258&s=612x612&w=0&h=AWTCPaG90GuJpmf5JnE966dOkrq1BWHqhpUJFaKGLYA=" class="card-img-top" alt="..."/>
            <div class="card-body">
              <h6 class="card-title" >NatWest Markets retains top spot as a Greenwich Quality Leader. NatWest Markets is confirmed as a ‘Greenwich Quality Leader’ for its foreign exchange (FX) service to UK corporates. </h6>
              <a class="btn btn-primary block" href="https://www.natwestgroup.com/news/2022/07/natwest-markets-retains-top-spot-as-a-greenwich-quality-leader.html" role="button">Click to know more</a>
            </div>
            <div class="card-footer">
              <small class="text-muted">Last updated 3 mins ago</small>
            </div>
          </div>
        </div>
      </div>

{/* Comments/Posts containers */}

    {/* Container 1 */}
<section className="vh-100" style={{ backgroundColor: '#401664' }}>
      <MDBContainer className="py-5 h-100" >
        <MDBRow className="justify-content-center align-items-center h-100">
          <MDBCol xl="10">
            <MDBCard className="mb-5" style={{ borderRadius: '15px' }}>
              <MDBCardBody className="p-4" >
                <MDBTypography tag='h3'>Best Payment Gateway in India - Natwestpay</MDBTypography>
                <MDBCardText className="small">
                  <MDBIcon far icon="star" size="lg" />
                  <span className="mx-2">|</span> Created by <strong>Natwest Reskiller</strong> on 22 September , 2022
                </MDBCardText>
                <hr className="my-4" />
                <div className="d-flex justify-content-start align-items-center">
                  <MDBCardText className="text-uppercase mb-0">
                    <MDBIcon fas icon="cog me-2" /> <span className="text-muted small">settings</span>
                  </MDBCardText>
                  <MDBCardText className="text-uppercase mb-0">
                    <MDBIcon fas icon="link ms-4 me-2" /> <span className="text-muted small">program link</span>
                  </MDBCardText>
                  <span className="ms-3 me-4">|</span>
                  <a href="#!">
                    <MDBCardImage
                      width="35"
                      src="https://mdbcdn.b-cdn.net/img/Photos/Avatars/avatar-2.webp"
                      alt="avatar"
                      className="rounded-circle me-3"
                      fluid />
                  </a>
                  
                </div>
              </MDBCardBody>
            </MDBCard>

    {/* Container 2 */}
            <MDBCard className="mb-5" style={{ borderRadius: '15px' }}>
              <MDBCardBody className="p-4">
                <MDBTypography tag='h3'>One brand story. Different ways to tell it</MDBTypography>
                <MDBCardText className="small">
                  <MDBIcon fas icon="star text-warning" size="lg" />
                  <span className="mx-2">|</span> Public <span className="mx-2">|</span> Updated by <strong>Natwest Reskiller</strong> on 22 September , 2022
                </MDBCardText>
                <hr className="my-4" />
                <div className="d-flex justify-content-start align-items-center">
                  <MDBCardText className="text-uppercase mb-0">
                    <MDBIcon fas icon="cog me-2" /> <span className="text-muted small">settings</span>
                  </MDBCardText>
                  <MDBCardText className="text-uppercase mb-0">
                    <MDBIcon fas icon="link ms-4 me-2" /> <span className="text-muted small">program link</span>
                  </MDBCardText>
                   <span className="ms-3 me-4">|</span>
                  <a href="#!">
                    <MDBCardImage width="35" src="https://mdbcdn.b-cdn.net/img/Photos/Avatars/avatar-2.webp" alt="avatar" className="rounded-circle me-1" fluid />
                    <MDBCardImage width="35" src="https://mdbcdn.b-cdn.net/img/Photos/Avatars/avatar-3.webp" alt="avatar" className="rounded-circle me-1" fluid />
                    <MDBCardImage width="35" src="https://mdbcdn.b-cdn.net/img/Photos/Avatars/avatar-4.webp" alt="avatar" className="rounded-circle me-1" fluid />
                    <MDBCardImage width="35" src="https://mdbcdn.b-cdn.net/img/Photos/Avatars/avatar-5.webp" alt="avatar" className="rounded-circle me-3" fluid />
                  </a>
                  
                </div>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
        </MDBRow>
      </MDBContainer>
    </section>

    {/* Footer */}
    <MDBFooter bgColor='dark' className='text-center text-white text-lg-left'>
      <MDBContainer className='p-4 pb-0'>
        <form action=''>
          <MDBRow className='d-flex justify-content-center'>
            <MDBCol size='auto' className='mb-4 mb-md-0'>
              <p className='pt-2'>
                <strong>Sign up for our newsletter</strong>
              </p>
            </MDBCol>

            <MDBCol md='5' size='12' className='mb-4 mb-md-0'>
              <MDBInput type='text' id='form5Example2' label='Email address' contrast />
            </MDBCol>

            <MDBCol size='auto' className='mb-4 mb-md-0'>
              <MDBBtn outline color='light' href='/'>
                Subscribe
              </MDBBtn>
            </MDBCol>
          </MDBRow>
        </form>
      </MDBContainer>
      <div className='text-center p-3' style={{ backgroundColor: 'rgba(0, 0, 0, 0.2)' }}>
        &copy; {new Date().getFullYear()} Copyright:{' '}
        <a className='text-white' href='https://www.natwest.com/'>
          NatwestReskilling
        </a>
      </div>
    </MDBFooter>

        </div>
    )
}

export default Homepage