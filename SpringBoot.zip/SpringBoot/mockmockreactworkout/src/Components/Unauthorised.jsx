import React from 'react'

const Unauthorised = () => {
  return (
    <div >
      <img 
        alt=""
        src="https://i.pinimg.com/originals/33/42/e4/3342e4ba684ff017acff7382cad86c7f.jpg"
        width="60%"
        height="60%"
        className="d-center-block align-center"
        />{' '}
    </div>
  ) 
}

export default Unauthorised 