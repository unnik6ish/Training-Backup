import { MDBCard, MDBCardBody, MDBCol, MDBContainer, MDBInput, MDBRow } from 'mdb-react-ui-kit';
import React, { useEffect } from 'react'
import { Button } from 'react-bootstrap'
import { useDispatch } from 'react-redux';
import { Route, useNavigate } from 'react-router-dom';
import { logout } from '../Features/userSlice';


const Dashboard = () => {

  const navigate = useNavigate();
  const dispatch=useDispatch();
  // const logout = () => {
  //   localStorage.removeItem("user");
  //   navigate("/login")
  //   window.location.reload();      

  // };

  useEffect(() => {
    window.addEventListener('popstate', (e) => {
      window.history.go(1);
    });
  }, []);

  const Logout = () => {

    navigate('/')
    // alert("You have been Logout")
    dispatch(logout(
        {
            id: "",
            username: "",
            loginStatus: false,
            component: <Route path='/dashboard' element={<Dashboard />} />
        }
    ))
}

  return (
    <div >

      {/* <Button onClick={logout} > Logout </Button> */}
      

      <MDBContainer
      className="py-5"
      fluid
      style={{
        backgroundImage:
          "url(https://mdbcdn.b-cdn.net/img/Photos/Others/background3.webp)", 
          
      }}
    >

      
      <MDBRow className=" d-flex justify-content-center" >
        <MDBCol md="10" lg="8" xl="5">
          <MDBCard className="rounded-3">
            <MDBCardBody className="p-4">
              <div className="text-center mb-4">
              <img
                            alt=""
                            src="https://www.bing.com/th?id=OSK.afa3a68f24db08580c55a8cdbfddaa84&w=148&h=148&c=7&o=6&dpr=1.3&pid=SANGAM"
                            width="30"
                            height="30"
                            className="d-inline-block align-top"
                            />{' '}<h3>Natwest Payment Wallet</h3>

              
              </div>
              <p className="fw-bold mb-4 pb-2">Saved cards:</p>
              <div className="d-flex flex-row align-items-center mb-4 pb-1">
                <img
                  className="img-fluid"
                  src="https://img.icons8.com/color/48/000000/mastercard-logo.png"
                />
                <div className="flex-fill mx-3">
                  <div className="form-outline">
                    <MDBInput
                      label="Card Number"
                      id="form1"
                      type="text"
                      size="lg"
                      value="**** **** **** 3193"
                    />
                  </div>
                </div>
                <a href="#!">Remove card</a>
              </div>
              <div className="d-flex flex-row align-items-center mb-4 pb-1">
                <img
                  className="img-fluid"
                  src="https://img.icons8.com/color/48/000000/visa.png"
                />
                <div className="flex-fill mx-3">
                  <div className="form-outline">
                    <MDBInput
                      label="Card Number"
                      id="form2"
                      type="text"
                      size="lg"
                      value="**** **** **** 4296"
                    />
                  </div>
                </div>
                <a href="#!">Remove card</a>
              </div>
              <p className="fw-bold mb-4">Add new card:</p>
              <MDBInput
                // label="Cardholder's Name"
                id="form3"
                type="text"
                size="lg"
                placeholder="Cardholder's Name"
              />
              <MDBRow className="my-4">
                <MDBCol size="7">
                  <MDBInput
                    // label="Card Number"
                    id="form4"
                    type="text"
                    size="lg"
                    placeholder="Card Number" /><br></br>
                </MDBCol>
                <MDBCol size="5">
                  <MDBInput
                    // label="Expire"
                    id="form5"
                    type="password"
                    size="lg"
                    placeholder="MM/YYYY(Expiry)"
                  />
                </MDBCol>
                <MDBCol size="4">
                  <MDBInput
                    // label="CVV"
                    id="form6"
                    type="password"
                    size="lg"
                    placeholder="CVV"
                  />
                </MDBCol>
              </MDBRow>
              <Button color="success" size="lg" >
                Add card
              </Button><br></br><br></br>
              <Button color="secondary"  size="lg" 
             onClick={Logout}>
                Logout
              </Button>
            </MDBCardBody>
          </MDBCard>
        </MDBCol>
      </MDBRow>
    </MDBContainer>
    </div>
  )
}

export default Dashboard
