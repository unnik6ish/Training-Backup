import { NavLink, Route, Routes } from "react-router-dom";
import ForgotPassword from "./Components/ForgotPassword";
import Homepage from "./Components/Homepage";
import Login from "./Components/Login";
import Signup from "./Components/Signup";
import { useEffect, useState } from "react";
import AuthService from './Auth/AuthService';
import { useSelector } from "react-redux";




function App() {

  const user = useSelector(state => state.user.value)
  var loginStatusValidation = user.loginStatus


  console.log(loginStatusValidation);

  const [currentUser, setCurrentUser] = useState(undefined);

  useEffect(() => {
    const user = AuthService.getCurrentUser();

    if (user) {
      setCurrentUser(user);
    }
  }, []);

  return (
    <div >
      
      <Routes>
      <Route path='/' element={<Homepage/>}/>
      <Route path='/login' element={<Login/>}/>
      <Route path='/signup' element={<Signup/>}/>
      <Route path='/forgotpassword' element={<ForgotPassword/>}/>
        {user.component}
      </Routes>
    </div>
  );
}

export default App;
