import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Button, Col, Container, FloatingLabel, Form, Row } from 'react-bootstrap'
import { useDispatch } from 'react-redux';
import { Link, Route, useNavigate } from 'react-router-dom'
import { login } from '../Features/userSlice'
import bcrypt from 'bcryptjs';
import Dashboard from './Dashboard';

const Login = () => {

    const [email, setEmail] = useState(``);
    const [password, setPassword] = useState(``);
    const [userDetails, setUserDetails] = useState([]);

    const [emailError, setEmailError] = useState(``)
    const [passwordError, setPasswordError] = useState(``)

    var db_name = ``;
    var db_email = ``;
    var emailid_exists = false;
    var db_encryptedpwd = ``;
    var loginValidationStatus = false;

    const dispatch = useDispatch();
    const navigate = useNavigate();

    const api = axios.create({
        baseURL: `http://localhost:8080`
    })

    useEffect(() => {

        axios.get(`http://localhost:8080/walletusers`)
            .then(res => setUserDetails(res.data))
            .catch(err => console.log(err))

    })
    for (let i = 0; i < userDetails.length; i++) {
        if (email.toLowerCase() === (userDetails[i].id).toLowerCase()) {

            db_name = userDetails[i].name;
            db_email = userDetails[i].id;
            db_encryptedpwd = userDetails[i].password;
            emailid_exists = true
        }
    }

    async function LoginCheck(event) {

        event.preventDefault();

        loginValidationStatus = await bcrypt.compare(password, db_encryptedpwd)



        if (email == "" || password == "") {
            alert(`Please fill all the details`)
        }
        else if (!emailid_exists) {
            setEmailError(`Email id doesn't exist. Please Sign Up`)
        }
        else if (!loginValidationStatus) {
            setPasswordError(`Password doesnt match our records`)

        }
        else if (loginValidationStatus) {

            let credentials = {

                "emailid": email,
                "password": password
            }

            api.post(`/login`, credentials)
                .then(response => console.log(response))
                .catch(err => console.log(err))

            alert("Logged in Successfully")
            dispatch(login(
                {
                    email: ``,
                    loginStatus: true,
                    component: <Route path='/dashboard' element={<Dashboard />} />
                }
            ))
            navigate("/dashboard")
        }

    }
    const RouteToHomePage = () => {
        navigate('/')
    }

    const RouteToSignPage = () => {
        navigate('/signup')
    }

    return (
        <div style={{ backgroundColor: '#401664' }} >
            <div className='container-fluid p-5'>
                <Row className="mt-5 pt-4 " >
                    <Col lg={4} md={6} sm={9} className="p-4 m-auto shadow-lg rounded-lg " style={{ backgroundColor: '#CF9FFF', borderRadius: '3%' }}  >
                        <Form style={{ backgroundColor: '#CF9FFF', borderColor: 'black' }}>
                            <h4 className='text-center' >Wallet Pay</h4>
                            <h6 className='mb-3 text-center'>Welecome! Login to Continue</h6>
                            <FloatingLabel controlId="floatingInput" label="Email" className="mb-3" autoComplete="off" >
                                <Form.Control type="text" placeholder="Email"
                                    onChange={(e) => {
                                        setEmail(e.target.value);
                                        setEmailError(``)
                                    }}
                                    isInvalid={!!emailError}
                                />
                                <Form.Control.Feedback type='invalid'>
                                    {emailError}
                                </Form.Control.Feedback>
                                <Form.Text className="text-muted">Enter your email address</Form.Text>
                            </FloatingLabel>
                            <FloatingLabel controlId="floatingPassword" label="Password" className="mb-3" autoComplete="off" >
                                <Form.Control type="password" placeholder="Password"
                                    onChange={(e) => {
                                        setPassword(e.target.value)
                                        setPasswordError(``)
                                    }}
                                    isInvalid={!!passwordError}
                                />
                                <Form.Control.Feedback type='invalid'>
                                    {passwordError}
                                </Form.Control.Feedback>
                                <Form.Text className="text-muted">Enter your password</Form.Text>
                            </FloatingLabel>
                            <div className='text-center span2'>
                                <Button type='submit' variant="outline-primary" className='mb-2 mt-2 m-2' onClick={LoginCheck}>Login</Button>
                                <Button type='reset' variant="outline-primary" className='mb-2 mt-2'>Reset</Button>
                            </div>
                            <div className='text-center mt-3'>
                                <h6>New User? Please Sign Up</h6>
                                <Button variant="outline-primary" className='m-2' onClick={RouteToSignPage} >Sign Up</Button>
                                <Button variant="outline-primary" onClick={RouteToHomePage} >Home</Button>
                            </div>
                        </Form>
                    </Col>
                </Row>

            </div>
        </div>
    )
}

export default Login
