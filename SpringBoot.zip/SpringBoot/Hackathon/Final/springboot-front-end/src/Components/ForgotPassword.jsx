import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Button, Col, Container, FloatingLabel, Form, Row } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom'
import bcrypt from 'bcryptjs';



const ForgotPassword = () => {
    const navigate = useNavigate()

    const RouteToSignUpPage = () => {
        navigate('/signup')
    }

    const RouteToHomePage = () => {
        navigate('/')
    }

    const RouteToLoginPage = () => {
        navigate('/login')
    }

    const [userEmail, setUserEmail] = useState(``)
    const [securePin, setSecurePin] = useState(``)
    const [newPwd, setNewPwd] = useState(``)
    const [userDetails, setUserDetails] = useState([]);


    const [emailIdError, setEmailIdError] = useState(``)
    const [pinError, setPinError] = useState(``)
    const [passwordError, setPasswordError] = useState(``)



    var userExist = ``
    var index = 0
    var db_encryptedpwd = ``
    var oldPwdMatch = false
    var regExPwd = /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#%^&])(?!.* ).{8,20}$/
    const api = axios.create({
        baseURL: `http://localhost:8080/walletusers`
    })

    useEffect(() => {

        api.get(`/`)
            .then(res => setUserDetails(res.data))
            .catch(err => console.log(err))

    })

    for (let i = 0; i < userDetails.length; i++) {
        if (userEmail === userDetails[i].email) {
            userExist = `yes`
            index = i
            db_encryptedpwd = userDetails[i].password

        }
    }



    async function changePwd(event) {
        event.preventDefault();
        oldPwdMatch = await bcrypt.compare(newPwd, db_encryptedpwd)

        if (!(userExist === `yes`)) {
            setEmailIdError(`Email ID doesn't exist.`)
        }
        else if (!(securePin === `1234`)) {
            setPinError(`Incorrect PIN`)
        }
        else if (newPwd === "") {
            setPasswordError(`Password field should not be empty`)
        }
        else if (!regExPwd.test(newPwd)) {
            setPasswordError(`Please Create a strong password`)
        }
        else if (oldPwdMatch) {
            setPasswordError(`New Password should not be your old password`)
        }
        else {

            let newPwdUpdate = {
                "email": userDetails[index].email,
                "name": userDetails[index].name,
                "address": userDetails[index].address,
                "accountNo": userDetails[index].accno,
                "mobileNo": userDetails[index].mobno,
                "password": newPwd
            }

            api.put(`/`, newPwdUpdate)
                .then(res => console.log(res))
                .catch(err => console.log(err))
            alert(`Dear ${userDetails[index].name} your passoword is now updated. 
              Navigating you to login page...`)
            navigate('/login')

        }

    }




    return (
        <Container fluid >
            <Row className="pt-4 ">
                <Col lg={4} md={6} sm={9} className="p-3 m-auto shadow-lg rounded-lg bg-light">
                    <Form className='bg-light'>
                        <h4 className='mb-3 text-center' >Password Reset</h4>

                        <FloatingLabel controlId="floatingInput" label="Useremail" className="mb-3" autoComplete="off" >
                            <Form.Control type="email" placeholder="name@example.com"
                                onChange={(e) => {
                                    setUserEmail(e.target.value);
                                    setEmailIdError(``)
                                }}
                                isInvalid={!!emailIdError}
                            />
                            <Form.Control.Feedback type='invalid'>
                                {emailIdError}
                            </Form.Control.Feedback>

                        </FloatingLabel>


                        <FloatingLabel controlId="floatingPassword" label="Secure PIN" className="mb-3" autoComplete="off" >
                            <Form.Control type="password" placeholder="Secure PIN"
                                onChange={(e) => {
                                    setSecurePin(e.target.value)
                                    setPinError(``)
                                }}
                                isInvalid={!!pinError}
                            />
                            <Form.Control.Feedback type='invalid'>
                                {pinError}
                            </Form.Control.Feedback>
                        </FloatingLabel>


                        <FloatingLabel controlId="floatingPassword" label="New Password" className="mb-3" autoComplete="off" >
                            <Form.Control type="password" placeholder="New Password"
                                onChange={(e) => {
                                    setNewPwd(e.target.value)
                                    setPasswordError(``)
                                }}
                                isInvalid={!!passwordError}
                            />

                            <Form.Control.Feedback type='invalid'>
                                {passwordError}
                            </Form.Control.Feedback>
                        </FloatingLabel>

                        <div className='text-center span2'>
                            <Button type='submit' variant="primary" className='mb-2 mt-2 m-3 btn-block' onClick={changePwd} >Change Password</Button>
                            <Button type='reset' variant="warning" className='mb-2 mt-2 btn-block' >Reset</Button>
                        </div>
                        <div className='text-center mt-2 '>
                            <Button variant="secondary" className='mb-3' onClick={RouteToSignUpPage} >Sign Up</Button>
                        </div>
                        <div className='text-center mt-2 '>
                            <Button variant="primary" className='mb-3' onClick={RouteToLoginPage} >Login</Button>
                        </div>
                        <div className='text-center'>

                            <Button variant="success" className='mb-3' onClick={RouteToHomePage} >Back to Home</Button>
                        </div>
                    </Form>
                </Col>
            </Row>

        </Container>
    )

}

export default ForgotPassword