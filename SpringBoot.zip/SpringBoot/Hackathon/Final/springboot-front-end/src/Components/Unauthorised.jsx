import React from 'react'

const Unauthorised = () => {
  return (
    <div>
      <img 
        alt=""
        src="https://i.pinimg.com/originals/33/42/e4/3342e4ba684ff017acff7382cad86c7f.jpg"
        width="50%"
        height="50%"
        className="d-inline-block align-top"
        />{' '}
    </div>
  ) 
}

export default Unauthorised 