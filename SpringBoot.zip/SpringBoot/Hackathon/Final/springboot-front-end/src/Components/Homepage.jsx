import { Carousel, Container, Nav, Navbar} from 'react-bootstrap';
import { useNavigate } from 'react-router-dom'
const Homepage = () => {

  const navigate = useNavigate();

  const routeToLogin = () => {
    navigate('/login')
  }

  const routeToSignup = () => {
    navigate('/signup')
  }
  return (
    <div className='bg-dark'>
      <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
        <Container fluid>
          <Navbar.Brand href="/">Foreign Exchange</Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav">
            <Nav className="me-auto">
              <Nav.Link onClick={routeToLogin}>Login</Nav.Link>
              <Nav.Link onClick={routeToSignup}>SignUp</Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
      <Carousel>
      <Carousel.Item>
        <img
          className="d-block"
          src="https://images.pexels.com/photos/8370389/pexels-photo-8370389.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
          alt="First slide"
        />
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block"
          src="https://images.pexels.com/photos/8370330/pexels-photo-8370330.jpeg?auto=compress&cs=tinysrgb&w=600&lazy=load"
          alt="Second slide"
        />
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block"
          src="https://images.pexels.com/photos/8370757/pexels-photo-8370757.jpeg?auto=compress&cs=tinysrgb&w=600&lazy=load"
          alt="Third slide"
        />
      </Carousel.Item>
    </Carousel>
      </div>
  )
}

export default Homepage