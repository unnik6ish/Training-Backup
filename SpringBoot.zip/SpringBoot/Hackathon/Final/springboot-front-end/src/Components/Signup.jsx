import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Button, Col, Container, FloatingLabel, Form, Row } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom'

const Signup = () => {

    const [name, setName] = useState(``);
    const [email, setEmail] = useState(``);
    const [mobNo, setMobNo] = useState(``);
    const [accno, setAccno] = useState(``);
    const [address, setAddress] = useState(``);
    const [password, setPassword] = useState(``);

    const navigate = useNavigate();

    const RoutToLoginPage = () => {
        navigate('/login')
    }

    const RoutToHomePage = () => {
        navigate('/')
    }

    var [walletUsers, setWalletUsers] = useState([]);

    var name_exists;
    var email_exist;


    //Regex Variable to compare
    var regExEmail = /^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,3}$/
    var regexUsername = /[A-Za-z0-9]{3,30}/
    var regexName = /[A-Za-z]{3,30}/
    var regex10digits = /^[0-9]\d{09}$/ // to validate phone no 
    var regexAddress = /^[a-zA-Z0-9(?:_*.\-\\,\s)?]{10,100}$/
    var regExPwd = /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#%^&])(?!.* ).{8,20}$/

    //setting up base url for request
    const api = axios.create({
        baseURL: `http://localhost:8080/`
    })

    useEffect(() => {

        api.get(`http://localhost:8080/walletusers`)
            .then(res => setWalletUsers(res.data))
            .catch(err => console.log(err))

    })


    for (let i = 0; i < walletUsers.length; i++) {
        if (email === walletUsers[i].id) {

            email_exist = true
        }

    }

    for (let i = 0; i < walletUsers.length; i++) {
        if (name === walletUsers[i].name) {

            name_exists = true

        }

    }

    const SignUp = (event) => {
        // async function SignUp(event){
        event.preventDefault()
        if (!regexUsername.test(name)) {
            alert(`Userame length must be between 3 -20 characters, Only Alpha-numeric allowed`)
        }

        else if (name_exists) {
            alert(`Username already exist. Please use a different a username to continue`)
        }

        else if (!regexName.test(name)) {
            alert(`Please enter a valid name use only alphabets`)

        }

        else if (!regExEmail.test(email)) {
            alert(`Please enter a valid email id`)

        }
        else if (!regexAddress.test(address)) {
            alert(`Address length must be between 10 -100 characters`)
        }
        else if (email_exist) {
            alert(`Email ID already exist. Please use a different email id to continue or Login`)
        }
        else if (!regex10digits.test(mobNo)) {
            alert(`Please Enter a valid 10 digit mobile number`)
        }
        else if (!regExPwd.test(password)) {
            alert(`Please create a strong password`)
        }



        else {

            var newUser = {
                "id": email,
                "name": name,
                "mobno": mobNo,
                "accno": accno,
                "address": address,
                "password": password
            }


            axios.post(`http://localhost:8080/walletusers`, newUser)
                .then(response => console.log(response))
                .catch(err => console.log(err))

            navigate("/login")
            alert("Signed in Successfully")
        }

    }



    return (
        <div style={{ backgroundColor: '#401664' }}>
            <Container fluid   >
                <Row className="pt-3 rounded">
                    <Col lg={4} md={6} sm={9} className="p-4 m-auto shadow-lg rounded-lg" style={{ backgroundColor: '#CF9FFF', borderRadius: '3%' }}>
                        <Form style={{ backgroundColor: '#CF9FFF' }} >
                            <h3 className='text-center mb-2'>Wallet Pay</h3>
                            <FloatingLabel
                                controlId="floatingInput" label="UserName" className="mb-3">
                                <Form.Control type="text" placeholder="Name" autoComplete='off'
                                    onChange={(e) => setName(e.target.value)} required={true} />
                                <Form.Text className="text-muted">Only alpha-numeric allowed with length of 3 -20 characters</Form.Text>
                            </FloatingLabel>
                            <FloatingLabel
                                controlId="floatingInput" label="Address" className="mb-3">
                                <Form.Control type="text" placeholder="Address"
                                    onChange={(e) => setAddress(e.target.value)} required={true} />
                                <Form.Text className="text-muted">Please enter your address</Form.Text>
                            </FloatingLabel>
                            <FloatingLabel
                                controlId="floatingInput" label="Account No" className="mb-3">
                                <Form.Control type="number" placeholder="Account N0" required onChange={(e) => setAccno(e.target.value)} />
                                <Form.Text className="text-muted">Please enter your account number</Form.Text>
                            </FloatingLabel>
                            <FloatingLabel
                                controlId="floatingInput" label="Email address" className="mb-3">
                                <Form.Control type="email" placeholder="name@example.com" required onChange={(e) => setEmail(e.target.value)} />
                                <Form.Text className="text-muted">Please enter a valid email id(xxx@xx.com)</Form.Text>
                            </FloatingLabel>
                            <FloatingLabel
                                controlId="floatingInput" label="Phone Number" className="mb-3">
                                <Form.Control type="number" placeholder="Phone Number" required onChange={(e) => setMobNo(e.target.value)} />
                                <Form.Text className="text-muted">Please Enter Your 10 digit mobile number</Form.Text>

                            </FloatingLabel>
                            <FloatingLabel controlId="floatingPassword" label="Password">
                                <Form.Control type="password" placeholder="Password" required onChange={(e) => setPassword(e.target.value)} />
                                <Form.Text className="text-muted">
                                    Password must contain atleast 8 characters includes an uppercase, lowercase, numeric and symbols ( @ # % ^ & - _ )
                                </Form.Text>

                            </FloatingLabel>
                            <div className='text-center span2'>
                                <Button type='submit' variant="outline-primary" className='mb-2 mt-2 m-2' onClick={SignUp} >Sign Up</Button>
                                <Button type='reset' variant="outline-primary" className='mb-2 mt-2' >Reset</Button>
                            </div>
                            <div className='text-center mt-1'>
                                <h6>Already have an account?</h6>
                                <Button variant="outline-primary" className='m-2' onClick={RoutToLoginPage} >Login</Button>
                                <Button variant="outline-primary" onClick={RoutToHomePage}>Home</Button>
                            </div>
                        </Form>
                    </Col>
                </Row>
            </Container>
        </div>
    )
}

export default Signup