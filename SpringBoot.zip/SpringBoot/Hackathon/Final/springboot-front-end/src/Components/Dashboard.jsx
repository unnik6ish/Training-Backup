import React, { useEffect } from 'react'
import { Card, Container, Nav, Navbar } from 'react-bootstrap'
import { useDispatch } from 'react-redux';
import { Route, useNavigate } from 'react-router-dom';
import { logout } from '../Features/userSlice';


const Dashboard = () => {

  const navigate = useNavigate();
  const dispatch=useDispatch();

  useEffect(() => {
    window.addEventListener('popstate', (e) => {
      window.history.go(1);
    });
  }, []);

  const Logout = () => {

    navigate('/')
    dispatch(logout(
        {
            id: "",
            username: "",
            loginStatus: false,
            component: <Route path='/dashboard' element={<Dashboard />} />
        }
    ))
}
  return (
    <div >
      <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
        <Container fluid>
          <Navbar.Brand href="/">Foreign Exchange</Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav">
            <Nav className="me-auto">
              <Nav.Link onClick={Logout}>Logout</Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
      <Card>
        <Card.Body>
          <Card.Text>Welcome to your Dashboard</Card.Text>
        </Card.Body>
        <Card.Img variant="bottom" src="https://images.pexels.com/photos/768472/pexels-photo-768472.jpeg?auto=compress&cs=tinysrgb&w=600" />
      </Card>
    </div>
  )
}

export default Dashboard
