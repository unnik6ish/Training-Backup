package com.example.demo.model;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;


@Entity
public class WalletUsers {
	
	@Id
	@Column(name = "emailid")
	String id;
	String name;
	String address;
	Long accno;
	Long mobno;
	String password;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Long getAccno() {
		return accno;
	}

	public void setAccno(Long accno) {
		this.accno = accno;
	}

	public Long getMobno() {
		return mobno;
	}

	public void setMobno(Long mobno) {
		this.mobno = mobno;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		
		BCryptPasswordEncoder pwdEncoder = new BCryptPasswordEncoder();
		String encryptedPwd = pwdEncoder.encode(password);
		this.password = encryptedPwd;
		
	}

	public WalletUsers(String id, String name, String address, Long accno, Long mobno, String password) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.accno = accno;
		this.mobno = mobno;
		this.password = password;
	}

	public WalletUsers() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "WalletUsers [id=" + id + ", name=" + name + ", address=" + address + ", accno=" + accno + ", mobno="
				+ mobno + ", password=" + password + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(accno, address, id, mobno, name, password);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WalletUsers other = (WalletUsers) obj;
		return Objects.equals(accno, other.accno) && Objects.equals(address, other.address)
				&& Objects.equals(id, other.id) && Objects.equals(mobno, other.mobno)
				&& Objects.equals(name, other.name) && Objects.equals(password, other.password);
	}
	
}