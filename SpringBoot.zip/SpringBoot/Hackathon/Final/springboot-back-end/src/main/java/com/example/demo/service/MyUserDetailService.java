package com.example.demo.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.demo.model.WalletUsers;
import com.example.demo.repository.WalletUserRepo;

@Service
public class MyUserDetailService implements UserDetailsService {

	
	@Autowired
	WalletUserRepo walletUserRepo; 
	
	@Override
	public UserDetails loadUserByUsername(String emailId) throws UsernameNotFoundException {
		
		 WalletUsers walletUser = walletUserRepo.findById(emailId).get();
		 
		return new User(walletUser.getId(), walletUser.getPassword(), new ArrayList<>()) ;
	}

}
