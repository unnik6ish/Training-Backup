package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.UserAlreadyExistException;
import com.example.demo.exception.UserNotFoundException;
import com.example.demo.model.WalletUsers;
import com.example.demo.repository.WalletUserRepo;

@Service
public class WalletUserServiceImpl implements WalletUserService {
	
	@Autowired
	WalletUserRepo walletRepo;
	
	@Override
	public WalletUsers registerUser(WalletUsers walletUser) throws UserAlreadyExistException {
		return walletRepo.save(walletUser);
	}

	@Override
	public WalletUsers findUserbyId(String emailid) throws UserNotFoundException {
		return walletRepo.findById(emailid).get();
	}

	@Override
	public List<WalletUsers> getAllUser() {
		return walletRepo.findAll();
	}

	@Override
	public WalletUsers deleteAUser(String emailid) {
		WalletUsers deletedWalletUser = null;
		
		Optional optional = walletRepo.findById(emailid);
		
		if(optional.isPresent()) {
			deletedWalletUser = walletRepo.findById(emailid).get();
		walletRepo.deleteById(emailid);
		}
		
		return deletedWalletUser;
	}

	@Override
	public WalletUsers updateAUser(WalletUsers walletUser) {
		WalletUsers updatedWalletUser = null;
		
		Optional optional = walletRepo.findById(walletUser.getId());
		
		if (optional.isPresent()) {
			WalletUsers getUser = walletRepo.findById(walletUser.getId()).get();
			getUser.setName(walletUser.getName());
			getUser.setAddress(walletUser.getAddress());
			getUser.setAccno(walletUser.getAccno());
			getUser.setMobno(walletUser.getMobno());
			getUser.setPassword(walletUser.getPassword());
			
			updatedWalletUser = walletRepo.save(getUser);
		}
		
		return updatedWalletUser;
	}

	
	
}
