package com.example.demo.service;

import java.util.List;

import com.example.demo.exception.UserAlreadyExistException;
import com.example.demo.exception.UserNotFoundException;
import com.example.demo.model.WalletUsers;

public interface WalletUserService {

	public WalletUsers registerUser(WalletUsers netflixUser) throws UserAlreadyExistException; //post request - save a user record
	public WalletUsers findUserbyId(String username) throws UserNotFoundException; // get request - retrieve a record
	public List<WalletUsers> getAllUser(); //get request - to retrieve all records
	public WalletUsers deleteAUser(String username); //delete request
	public WalletUsers updateAUser(WalletUsers netflixUser); // PUT - PATCH request
	
	
	
	
	
	
	
	
	
}
