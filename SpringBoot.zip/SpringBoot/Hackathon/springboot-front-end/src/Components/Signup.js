import { Box, Button, TextField, Typography } from '@mui/material'
import React, { useState } from 'react'
import axios from 'axios';
import { useNavigate } from 'react-router-dom'
import { useEffect } from 'react';

const Signup = () => {

    const[userEmail, setUserEmail]=useState(``);
    const[userName, setUserName]=useState(``);
    const[userAddress, setUserAddress]=useState(``);
    const[userAccNo, setUserAccNo]=useState(0);
    const[userMobNo, setUserMobNo]=useState(0)    
    const[userPassword, setUserPassword]=useState(``)

    const api = axios.create({
        baseURL:`http://localhost:8080/walletusers`
    })
     
    var [walletUsers, setWalletUsers] = useState([]);
    var name_exists;
    var email_exist;

    useEffect(() => {

        api.get(`http://localhost:8080/walletusers`)
            .then(res => setWalletUsers(res.data))
            .catch(err => console.log(err))

    })

    for (let i = 0; i < walletUsers.length; i++) {
        if (userEmail === walletUsers[i].id ) {
            email_exist = true
        }
    }

    for (let i = 0; i < walletUsers.length; i++) {
        if (userName === walletUsers[i].userName ) {
            name_exists = true
        }
    }

    const navToLogin = useNavigate()
    const routeToLogin =()=>{
        
        navToLogin("/login")
    }

    const validEmail = /^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,3}$/
    const validName = /^[a-zA-Z]{3,}$/
    const validMobNo = /^[0-9]\d{09}$/
    const validAccNo = /^[0-9]\d{07}$/
    const validPassword = /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#%^&])(?!.* ).{8,20}$/

    const submitDetails=(event)=>{
        event.preventDefault()

    if ( !validEmail.test(userEmail) )
        {
            alert(`Enter a valid email id`)
        }
     else if (email_exist) 
        {
            alert(`Email ID already exist. Please use a different email id to continue or Login`)
        }
    else if ( !validName.test(userName) )
        {
            alert(`Name must contain 3 characters only alphabets`)
        }
    else if (name_exists) 
        {
            alert(`Username already exist. Please use a different a username to continue`)
        }
    else if ( !validAccNo.test(userAccNo) )
        {
        alert(`Enter your 8 digit roll no`)
        }
    else if ( !validMobNo.test(userMobNo) )
        {
            alert(`Enter your 10 digit mobile number`)
        }
    else if ( !validPassword.test(userPassword) )
        {
            alert(`Choose a strong password`)
        }

    else
    {
        const inputDetails = {
            "id":userEmail,
            "name":userName,
            "address":userAddress,
            "accnumber":userAccNo,
            "mobnumber":userMobNo,
            "password":userPassword
        }

        axios.post(`http://localhost:8080/walletusers`, inputDetails)
                .then(response => console.log(response))
                .catch(err => console.log(err))

        alert("sign up success")
        navToLogin("/login")
    }
}

    const inputUserEmail = (event) =>{
        setUserEmail(event.target.value)
        console.log(event.target.value);
    }
    const inputUserName = (event) =>{
        setUserName(event.target.value)
        console.log(event.target.value);
    }
    const inputUserAddress = (event) =>{
        setUserAddress(event.target.value)
        console.log(event.target.value);
    }
    const inputUserAccNo = (event) =>{
        setUserAccNo(event.target.value)
        console.log(event.target.value);
    }
    const inputUserMobNo = (event) =>{
        setUserMobNo(event.target.value)
        console.log(event.target.value);
    }
    const inputUserPassword = (event) =>{
        setUserPassword(event.target.value)
        console.log(event.target.value);
    }
  return (
        <form>
            <Box
                  display="flex" 
                  flexDirection="column" 
                  maxWidth={400} 
                  alignItems="center" 
                  justifyContent={"center"} 
                  margin="auto"
                  marginTop={5}
                  padding={3}
                  borderRadius={5}
                  boxShadow={"5px 5px 10px #401664"}
                  sx={{
                      ":hover": {
                        boxShadow:"10px 10px 20px #401664"
                      }
                  }}
                >
                <Typography variant='h5' padding={3} textAlign="center">Signup</Typography>
                <TextField 
                    name ="email" 
                    margin='normal' 
                    type="email" 
                    variant='outlined' 
                    placeholder='Email' 
                    onChange={inputUserEmail}
                    />
                <TextField 
                    name = "name" 
                    margin='normal' 
                    type="text" 
                    variant='outlined' 
                    placeholder='Name' 
                    onChange={inputUserName}
                    />
                <TextField 
                    name ="address" 
                    margin='normal' 
                    type="text" 
                    variant='outlined' 
                    placeholder='Address' 
                    onChange={inputUserAddress}
                    />
                <TextField 
                    name = "accountno" 
                    margin='normal' 
                    type="number" 
                    variant='outlined' 
                    placeholder='Account No' 
                    onChange={inputUserAccNo}
                    />
                <TextField 
                    name ="mobno" 
                    margin='normal' 
                    type="number" 
                    variant='outlined' 
                    placeholder='Mob Number' 
                    onChange={inputUserMobNo}
                    />
                <TextField 
                    name = "password" 
                    margin='normal' 
                    type="password" 
                    variant='outlined' 
                    placeholder='Password' 
                    onChange={inputUserPassword}
                    />
                <Button 
                    variant='contained' 
                    type='submit'
                    sx={{ marginTop:3 , borderRadius: 3 }} 
                    onClick={submitDetails}>
                        Signup
                    </Button>
                    <br/>
                <Typography 
                    variant='h7' 
                    margin='normal' 
                    textAlign="center">
                        Already have an account?
                    </Typography>
                <Button 
                    variant='contained' 
                    type='submit'
                    sx={{ marginTop:3 , borderRadius: 3 }} 
                    onClick={routeToLogin}>
                        Login
                    </Button>
            </Box>
        </form>
  )
}

export default Signup