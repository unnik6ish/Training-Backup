import { AppBar, Button, Container, Toolbar, Typography } from '@mui/material'
import React from 'react'
import { Link } from 'react-router-dom'

const Dashboard = () => {
  return (
    <div>
        <AppBar position = "relative">
        <Toolbar>
                <Typography style={{marginLeft :'16px'}} variant='h6'>Welcome to your dashboard{}</Typography>
                <Button variant="h6" color="inherit"><Link to='/'>Logout</Link></Button>
        </Toolbar>
    </AppBar>
    <Container style={{ marginTop:'65px' }} maxWidth='sm'>
        <Typography color="textPrimary" variant='h2' align='center' gutterBottom>
            Welcome
        </Typography>
        <Typography color="textSecondary" variant='h5' align='center'>
            Lorem ipsum dolor sit amet. Qui voluptas omnis ut molestiae reprehenderit ut veritatis dolores qui quam officia et officia illo non minus repudiandae? Aut nostrum voluptas ab deserunt dolorem a officiis dolor. Numquam dolor sit autem voluptas et sint earum.
        </Typography>
        <Typography color="textPrimary" variant='h6' align='center' gutterBottom></Typography>
    </Container>
    </div>
  )
}

export default Dashboard