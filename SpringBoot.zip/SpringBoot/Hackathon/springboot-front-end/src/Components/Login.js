import { Box, Button, TextField, Typography } from '@mui/material'
import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { Route, useNavigate } from 'react-router-dom'


const Login = () => {

    const [loginEmail, setLoginEmail]= useState(``)
    const [loginPassword, setLoginPassword] =useState(``)
    const [customerDetails, setCustomerDetails] = useState([])

    const [emailError, setEmailError] = useState(``)
    const [passwordError, setPasswordError] = useState(``)

    const dispatch = useDispatch();
    const navigate = useNavigate();

    var db_name = ``;
    var db_email = ``;
    var emailid_exists = false;
    var db_encryptedpwd = ``;
    var loginValidationStatus = false;

    // const api = axios.create({
    //     baseURL:`http://localhost:3000/registeredDetails`
    // })

    const navToSignup = useNavigate()
    const routeToSignup =()=>
    {
        navToSignup("/signup")
    }

    useEffect(()=>{
        axios.get(`http://localhost:8080/walletusers`)
        .then(res=>setCustomerDetails(res.data))
        .catch(err=>console.log(err))
    })
    for (let i = 0; i < customerDetails.length; i++) {
        if (loginEmail.toLowerCase() === (customerDetails[i].id).toLowerCase()) {

            db_name = customerDetails[i].name;
            db_email = customerDetails[i].id;
            db_encryptedpwd = customerDetails[i].password;
            emailid_exists = true
        }
    }

    async function LoginCheck(event) {
        event.preventDefault();
        loginValidationStatus = await bcrypt.compare(password, db_encryptedpwd)

        if ( email == "" || password == "" ) {
            alert(`Please fill all the details`)
        }
        else if ( !emailid_exists ){
            setEmailError(`Email id doesn't exist. Please Sign Up`)
        }
        else if (!loginValidationStatus){
            setPasswordError(`Password doesnt match our records`)
        }
        else if (loginValidationStatus) {

            axios.post(`http://localhost:8080/login`, { email, password })
                .then(response => {
                    return response.data
                })
                .catch(err => console.log(err))
            alert("login success. Navigating to dashboard...")
            dispatch(login(
                {
                    email: ``,
                    loginStatus: true,
                    component: <Route path='/dashboard' element={<Dashboard />} />
                }
    
            ))    
                navigate("/dashboard")  
            }

    }

    const inputLoginEmail=(event)=>{
        setLoginEmail(event.target.value)
        console.log(event.target.value);
    }
    
    const inputLoginPassword=(event)=>{
        setLoginPassword(event.target.value)
        console.log(event.target.value);
    }

    const loginDetails =(event)=>
    {
        event.preventDefault();

        if(loginEmail === "" || loginPassword === ""){
            alert("Fill the login details")
            
        }

        var validationStatus = ""

        for (let i = 0; i < customerDetails.length; i++) 
        {
            if (loginEmail === customerDetails[i].id && loginPassword === customerDetails[i].password)
                {
                    validationStatus = "passed"
                } 
        }
            if(validationStatus === "passed")
                {
                    alert("Login successful")
                    navToSignup("/dashboard")
                }
            else
                {
                    alert("User details not found in database")
                }
    }
  return (
             <Box
                  display="flex" 
                  flexDirection="column" 
                  maxWidth={400} 
                  alignItems="center" 
                  justifyContent={"center"} 
                  margin="auto"
                  marginTop={5}
                  padding={3}
                  borderRadius={5}
                  boxShadow={"5px 5px 10px #401664"}
                  sx={{
                      ":hover": {
                        boxShadow:"10px 10px 20px #401664"
                      }
                  }}
                >
                <Typography variant='h5' padding={3} textAlign="center">Login</Typography>
                <TextField name ="email" margin='normal' type="email" variant='outlined' placeholder='Email' onChange={inputLoginEmail}/>
                <TextField name = "password" margin='normal' type="password" variant='outlined' placeholder='Password' onChange={inputLoginPassword}/>
                <Button variant='contained' type='submit'sx={{ marginTop:3 , borderRadius: 3 }} onClick={loginDetails}>Login</Button><br/>
                <Typography variant='h7' margin='normal' textAlign="center">New User? Sign Up</Typography>
                <Button variant='contained' type='submit'sx={{ marginTop:3 , borderRadius: 3 }} onClick={routeToSignup}>Sign Up</Button>
            </Box>
  )
}

export default Login