package com.selenium.web.driver.SeleniumWebDriver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class GoogleTest {
	
	/*Launch Chrome Browsers
	 * Navigate to
			Google "https://www.google.com"
			Validate the current url
	 */
	public static WebDriver driver;
	@Test
	public void navigateToGoogle() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Unnikrishnan\\Desktop\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://www.google.com");
		String expectedUrl ="https://www.google.com/";
		String actualUrl = driver.getCurrentUrl();
		System.out.println(actualUrl);
		Assert.assertEquals(expectedUrl, actualUrl, "Test This URL");
		
		
	}
	
	
	
	
}

