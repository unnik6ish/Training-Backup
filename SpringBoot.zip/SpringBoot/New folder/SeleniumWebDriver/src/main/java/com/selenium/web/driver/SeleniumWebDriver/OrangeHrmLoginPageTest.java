package com.selenium.web.driver.SeleniumWebDriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class OrangeHrmLoginPageTest {
	
	public String uname="Admin";
	public String pwd ="admin123";
	
	public static WebDriver driver;
	
	@Test
	private void loginTest() {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Unnikrishnan\\Desktop\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		System.out.println("OrangeHR System has been launched");
		
		System.out.println("Username has been entered");
		WebElement username = driver.findElement(By.xpath("//input[@name='username']"));
		username.clear();
		username.sendKeys(uname);
		
		System.out.println("Password has been entered");
		WebElement password = driver.findElement(By.xpath("//input[@name='password']"));
		password.clear();
		password.sendKeys(pwd);
		
		WebElement login = driver.findElement(By.xpath("//button[@type='submit']"));
		login.click();
		
		String title = driver.getTitle();
		System.out.println(title);
		Assert.assertEquals(title, "OrangeHRM");
		driver.close();
	}
}
