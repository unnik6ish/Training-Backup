package com.selenium.web.driver.SeleniumWebDriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class PetStoreTest {

	public static WebDriver driver;
	
	@Test
	private void searchTest() {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Unnikrishnan\\Desktop\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		driver.get("https://petstore.octoperf.com/actions/Catalog.action");
		System.out.println("PetStrore application has been launched");
		
		WebElement searchInput = driver.findElement(By.xpath("//input[@name='keyword']"));
		searchInput.clear();
		searchInput.sendKeys("fish");
		System.out.println("Pet name has been entered");
		
		WebElement searchButton = driver.findElement(By.xpath("//input[@name='searchProducts']"));
		searchButton.click();
		System.out.println("Search begin for the pet");
		
		WebElement typeOfPet = driver.findElement(By.linkText("Fresh Water fish from China"));
		typeOfPet.click();
		System.out.println("Pet has been selected");
		
		WebElement petAddToCart = driver.findElement(By.cssSelector("tr:nth-child(2) .Button"));
		petAddToCart.click();
		System.out.println("Added to cart");
		
		WebElement price = driver.findElement(By.cssSelector("td:nth-child(6)"));
		String petPrice = price.getText();
		
		WebElement petType = driver.findElement(By.cssSelector("td:nth-child(3)"));
		
		Assert.assertEquals(petPrice, "$5.50");
		Assert.assertEquals(petType.getText(), "Adult Male Goldfish");
		
		driver.close();
	}
}
