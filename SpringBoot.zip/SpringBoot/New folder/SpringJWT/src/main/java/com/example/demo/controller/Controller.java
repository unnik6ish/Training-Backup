package com.example.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
	
	@GetMapping("/emp")
	public String findAnEmployee() {
		return "Name: Unni, Location: Kerala, Department: HR";	
	}
}
