import React from 'react'

const products = [
    {id:1, name:"Laptop", brand:"Dell", qty:1},
    {id:2, name:"Laptop", brand:"HP", qty:1},
    {id:3, name:"Laptop", brand:"Asus", qty:1}
]


const Keys = () => {
  return (
    <div>
        {products.map((product) => (
            <div key={product.id}>
                <h1>{product.name}</h1>
                <h2>Brand : {product.brand}</h2>
                <h2>Quantity: {product.qty}</h2>
                <button>+</button>
            </div>
        ))}
        
    </div>
  )
}

export default Keys