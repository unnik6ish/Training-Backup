import React, { useState } from 'react'

const Header = () => {

    // let color = "Red";

    // const changeColor = () =>{

    //     color = "Green";
    //     console.log("Green");

    // }

   const[color, setColor] = useState("Red")
   const[count, setCount] = useState(0)

   const changeColor = () =>{
     setColor("Green")
   }

   const increment = () =>{
    setCount (count+1)
  }

  const decrement = () =>{
    setCount (count-1)
  }


  return (
    <div>
        <h1>Hello! I'm back!!!</h1>
        <h2>I like {color}</h2>
        <button onClick={changeColor}>Change Color</button><br/><br/>
        <h2>Counter = {count}</h2>
        <button onClick={increment}>+</button>
        <button onClick={decrement}>-</button>

    </div>
  )
}

export default Header