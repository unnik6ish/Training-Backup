package com.selflearn.fullstackbackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.selflearn.fullstackbackend.model.User;

public interface UserRepository extends JpaRepository<User, Integer>{

}
