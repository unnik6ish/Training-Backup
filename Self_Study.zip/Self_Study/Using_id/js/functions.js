function printMyname(){
    console.log("Unnikrishnan")
}
printMyname()

function findSum(a, b){
    let sum = a + b;
    console.log("Sum :"+sum);
}       
findSum(5,6)    

function myAddress(){
    return "Unnikrishnan"
}
console.log(myAddress());

function findProduct(a,b){
    return a*b 
}
console.log("Product = "+findProduct(8,9));