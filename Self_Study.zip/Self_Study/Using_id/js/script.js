function changeContent(){
    let content = document.getElementById("content")
    console.log("Old content : "+content.innerText);
    content.innerText = "You are doing good at this topic"
    console.log("Old content : "+content.innerText);
}
showAlert = () =>{
    let content = document.getElementById("content")
    alert("you double clicked on "+content.innerText)
}

validate = () =>{
    let username = document.getElementById("userName")
    let password = document.getElementById("passWord")

    if (username.value == "Unni" && password.value == "Unni") {
        alert("Login Sucess");
    } else {
        alert("Login Failed!"); 
    }
}