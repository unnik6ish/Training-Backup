function validation(){
    var username =document.getElementById("customername")
    var email =document.getElementById("email")
    var address =document.getElementById("address")
    var accnumber =document.getElementById("accnumber")
    var mobnumber =document.getElementById('mobnumber')
    var password =document.getElementById("password")
    var cpassword =document.getElementById("cpassword")

    if (username.value == ""){
        alert("Please enter user name")
        document.form.username.focus()
        return false
    }
    if (email.value == ""){
        alert("Please enter user email")
        document.form.email.focus()
        return false
    }
    if (address.value == ""){
        alert("Please enter your address")
        document.form.address.focus()
        return false
    }
    if (accnumber.value == ""){
        alert("Please enter your account number")
        document.form.accnumber.focus()
        return false
    }
    if (mobnumber.value == ""){
        alert("Please enter your name")
        document.form.mobnumber.focus()
        return false
    }
    if (password.value == ""){
        alert("Please enter your password")
        document.form.password.focus()
        return false
    }
    if (cpassword.value == ""){
        alert("Please confirm your password")
        document.form.cpassword.focus()
        return false
    }
    if (cpassword.value!=password.value){
        alert("Please confirm correct password")
        document.form.cpassword.focus()
        return false
    }
    return true 



}