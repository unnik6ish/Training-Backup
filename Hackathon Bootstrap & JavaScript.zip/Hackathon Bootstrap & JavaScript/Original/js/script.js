var form = document.getElementById("form")
var fname = document.getElementById("fname")
var lname = document.getElementById("lname")
var email = document.getElementById("email")
var accnumber = document.getElementById("accnumber")
var accpwd = document.getElementById("accpwd")

form.addEventListener()
{
    if (fname == ""){
        alert("Please enter the first name")
    }
    if (lname == ""){
        alert("Please enter the first name")
    }
}