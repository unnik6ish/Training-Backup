
# Responsive-Webpage for Online Book Store

1. This webpage contains Header, Navbar, Main and Footer section.

2. The Hero section contains the author's name and coverpage of his new book. An instant buying option has been given to help the customer.

3. In the first section a detailed discription about the author has been given.

4. In the second section a varity of option has been provided to buy different formats of book as PDF, Hard Copy and E-book.

5. In the thrird section a detailed discription of the upcoming release with its genre.

6. Footer section contains with social links and site links.



