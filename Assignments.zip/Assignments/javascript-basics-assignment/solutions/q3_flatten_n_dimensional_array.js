/* Write a Program to Flatten a given n-dimensional array */

const flatten = () => {
	
var myArray = [1, [2, 3], [[4], [5]]]

myArray.flat();
console.log(myArray.flat(2));

};
flatten()


/* For example,
INPUT - flatten([1, [2, 3], [[4], [5]])
OUTPUT - [ 1, 2, 3, 4, 5 ]

*/

module.exports = flatten;
