/* Write a program to build a `Pyramid of stars` of given height */

const buildPyramid = () => 
{
    let height = 6 
    let stars = ""
    for(i=0; i<height; i++)
   {
        for(k=0; k<(height-i); k++)
        {
            stars += " "
        }
            for(j=0; j<=i; j++)
            {
                stars += " *"
            }
                stars += " \n";
   }
   console.log(stars);
};
buildPyramid()


/* For example,
INPUT - buildPyramid(6)
OUTPUT -
     *
    * *
   * * *
  * * * *
 * * * * *
* * * * * *

*/

module.exports = buildPyramid;
