// /* Write a Program to convert an array of objects to an object
// 	based on a given key */
// Spread Operator to Convert an Array to an Object in JavaScript

const convert = () => {

    const arrayName = [{id: 1, value: 'abc'}, {id: 2, value: 'xyz'}, {id: 3, value: 'pqr'}]

    const objectName = {...arrayName};

    console.log(objectName);

};

convert()

module.exports = convert;

/* For example,
INPUT - convert([{id: 1, value: 'abc'}, {id: 2, value: 'xyz'}], 'id')
OUTPUT - {
			'1': {id: 1, value: 'abc'},
			'2': {id: 2, value: 'xyz'}
		 }


*/

