# Linux Assignment

Steps: 

1. Please refer to the below link.

https://stackbooks.stackroute.in/course/IT-Fundamentals-And-Programming-Logic-And-Techniques/02-1-session

2. Fork this repo and clone it

3. Attach your solution to the local cloned repo

4. Push the solution and share the link of your repo

