import axios from 'axios'
import React, { useEffect, useState } from 'react'
import DisplayCard from './DisplayCard'

const Dashboard = () => {

    const [articles, setArticles] = useState([])
    const[savedNewsdb,setSavedNewsdb] = useState([]);
    
    useEffect(() => {
        axios.get(`https://newsapi.org/v2/top-headlines?country=in&apiKey=6e39dd6c131e4efe9c956648205bd79a`)
            .then(response =>
                setArticles(response.data.articles)
            )
            .catch(error => console.log(error.message))
    })
    const savedNews = (newCard) => {

        axios.post(`http://localhost:3000/savedNews`,  
                newCard, { headers: { 'Content-Type': 'application/json' }})
             .then((response)=>{
                if (response.status === 201) {
                    setSavedNewsdb([...savedNewsdb, response.data]);
                  }
                     })
             .catch((err)=>{
                console.log(err);
             })
    }
    return (
        <div className="container">
            <div className="row">
                {
                    articles.map((article) => (
                        <div className='col-sm-6 col-md-4' key={article.url}>
                            <DisplayCard
                                author={article.author}
                                authorex={article.source.name}
                                title={article.title}
                                description={article.description}
                                url={article.url}
                                urlToImage={article.urlToImage}
                                content={article.content}
                                readLater = {savedNews}
                            />
                        </div>
                    ))
                }
            </div>
        </div>
    )
}

export default Dashboard