import Footer from '../Components/footer/Footer';
describe('Testing sum', () => {
 

    it('should equal 4',()=>{
       expect(2+2).toBe(4);
      })

});
export default Footer;