import Dashboard from '../Components/dashboad/Dashboard';
describe('Testing sum', () => {


    it('should equal 3',()=>{
       expect(1+2).toBe(3);
      })

});

export default Dashboard;