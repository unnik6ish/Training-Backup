
import Card from '../Components/card/Card';

describe('Testing card', () => {  
    it('should equal 5',()=>{
        expect(2+3).toBe(5);
       })
  
 
 });

export default Card;