import React from 'react';

export default function Footer()
{
    return <h6 className="footer" > 
        Copyright &copy; Online News Service 2022
    </h6>
};