
Steps:

1. Read the problem statement specified in the below link 

https://stackbooks.stackroute.in/course/IT-Fundamentals-And-Programming-Logic-And-Techniques/05-session

2. Fork the repository

3. Clone it to the localrepo

4. Add the solution to your cloned repo

5. Push the repo to gitlab

6. Share the link to your assignment to the google sheet shared

7. Give reporter access (in the member section of the project) to the mentor 
