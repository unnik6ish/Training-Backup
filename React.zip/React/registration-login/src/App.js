import Login from './Login';
import Registration from './Registration';

function App() {
  return (
    <div className="App">
      {/* <Registration/> */}
      <Login/>
    </div>
  );
}

export default App;
