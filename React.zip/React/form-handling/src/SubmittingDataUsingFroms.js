import React, { useState } from 'react'

function SubmittingDataUsingFroms() {
  
  let [deptId, setdeptId] = useState(0)
  let [deptName, setdepName] = useState("")
  let [location, setlocation] = useState("")
  
  let deptIdChanged = (event) =>{
    setdeptId(event.target.value)
  }
  let deptNameChanged = (event) =>{
    setdepName(event.target.value)
  }
  let locationChanged = (event) =>{
    setlocation(event.target.value)
  }

  let submitted = (event) =>{
    event.preventDefault()
    alert(`${deptId} : ${deptName} : ${location}`);
  }
    return (
    <div>
        <form onSubmit={submitted}>
            <h4>Form Submission</h4>
            <input type="number" name ="deptId" value={deptId} placeholder="Department ID" onChange={deptIdChanged} /> <br/>
            <input type="text" name ="deptName" value={deptName} placeholder="Department Name" onChange={deptNameChanged} /> <br/>
            <input type="text" name ="location" value={location} placeholder="Department Location" onChange={locationChanged} /> <br/>
            <input type="submit" value="Submit" />
        </form>
    </div>
  )
}

export default SubmittingDataUsingFroms