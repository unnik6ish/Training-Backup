import './App.css';
import SubmittingDataUsingFroms from './SubmittingDataUsingFroms';

function App() {
  return (
    <div className="App">
      <SubmittingDataUsingFroms />
    </div>
  );
}

export default App;
