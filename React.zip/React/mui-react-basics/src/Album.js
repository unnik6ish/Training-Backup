import React from 'react'
import CssBaseline from '@mui/material/CssBaseline';
import AppBar from '@mui/material/AppBar';
import { PhotoCamera } from '@mui/icons-material';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import { Container } from '@mui/system';
import Button from '@mui/material/Button';

const Album = () => {
  return (
    <div>
        <CssBaseline />
        <AppBar position = "relative">
        <Toolbar>
            <PhotoCamera/>
                <Typography style={{marginLeft :'16px'}} variant='h6'>
                    Album Layout
                </Typography>
                <Button variant="h6" color="inherit">Signup</Button>
                <Button variant="h6" color="inherit">Login</Button>
        </Toolbar>
    </AppBar>
    <Container style={{ marginTop:'65px' }} maxWidth='sm'>
        <Typography color="textPrimary" variant='h2' align='center' gutterBottom>
            Album Layout
        </Typography>
        <Typography color="textSecondary" variant='h5' align='center'>
        Something short and leading about the collection below—its contents, the creator, etc. Make it short and sweet, but not too short so folks don't simply skip over it entirely.
        </Typography>
        <div align='center' style={{marginTop:'47px'}}>
            <Button variant='contained' style={{marginRight:'15px'}}>MAIN CALL TO ACTION</Button>
            <Button variant='outlined' >SECONDARY ACTION</Button> 
        </div>
    </Container>
    </div>
  )
}

export default Album