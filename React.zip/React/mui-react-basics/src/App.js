import './App.css';
import { Typography } from '@mui/material';
import Button from '@mui/material/Button';

function App() {
  return (
    <div className="App">

      <Typography variant='h1'>Heading 1</Typography>
      <Typography variant='h2'>Heading 2</Typography>
      <Typography variant='h3'>Heading 3</Typography>
      <Typography variant='h4'>Heading 4</Typography>
      <Typography variant='h5'>Heading 5</Typography>
      <Typography variant='h6'>Heading 6</Typography>
      <Button variant="text">Text</Button>
      <Button variant="contained">Contained</Button>
      <Button variant="outlined">Outlined</Button>
      <Button variant="disabled">Disabled</Button><br/><br/>
      <Button color='primary' variant="contained">primary color</Button>
      <Button color='secondary' variant="contained">secondary color</Button>
      <Button color='success' variant="contained">success color</Button>
      <Button color='info' variant="contained">info color</Button>
      <Button color='warning' variant="contained">warning color</Button><br/><br/>
      <Button style={{ backgroundColor :  '#401664', color :"white", padding:'20px'}}>custom color</Button><br/><br/>
      <Typography variant='h6' style={{backgroundColor :  '#401664', color :"white", padding:'20px'}}>NatWest</Typography>
    </div>
  );
}

export default App;
