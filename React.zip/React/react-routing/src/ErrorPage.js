import React from 'react'

function ErrorPage() {
  return (
    <h1>404 Error - Page not found</h1>
  )
}

export default ErrorPage