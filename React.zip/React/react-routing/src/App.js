import './App.css';
import Home from './Home';
import AboutUs from './AboutUs';
import ContactUs from './ContactUs';
import Dashboard from './Dashboard';
import {BrowserRouter as Router, Routes, Route, Link} from 'react-router-dom';
import ErrorPage from './ErrorPage';
function App() {
  return (
    <div className="App">
      <Router>
          <Link to='/'>Home</Link><br></br>
          <Link to="/AboutUs">AboutUs</Link><br></br>
          <Link to="/ContactUs">ContactUs</Link><br></br>
          <Link to="/Dashboard">Dashboard</Link><br></br>
        <Routes>
          <Route path='/' element={<Home/>}/>
          <Route path='/AboutUs' element={<AboutUs/>}/>
          <Route path='/ContactUs' element={<ContactUs/>}/>
          <Route path='/Dashboard' element={<Dashboard/>}/>
          <Route path='*' element={<ErrorPage/>}/>
        </Routes>
      </Router>
    </div>
  );
}
export default App;









