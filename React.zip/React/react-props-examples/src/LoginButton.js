import React from 'react'

function LoginButton(props) {
  return (
    <button onClick={props.clickFunction}>LoginButton</button>
  )
}

export default LoginButton