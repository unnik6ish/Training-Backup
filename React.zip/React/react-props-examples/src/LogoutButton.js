import React from 'react'

function LogoutButton(props) {
  return (
    <button onClick={props.clickFunction}>LogoutButton</button>
  )
}

export default LogoutButton