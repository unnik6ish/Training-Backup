import React, { Component } from 'react'

class ClickableClassComponent extends Component {
    
    constructor(props) {
      super(props)
    
      this.state = {
         message:"Hello World"
      }
      this.changeTextEventHandler = this.changeTextEventHandler.bind(this)
    }

// showAlert(){

//     alert("you called me in class based component!")
// }

changeTextEventHandler(){
    this.setState({
        message: "Welcome to Natwest!"
    })
}
  render() {
    return (
      <div>
        <p>{this.state.message}</p>
        {/* <button onClick={this.changeTextEventHandler.bind(this)}>Click me!</button> */}
        {/* <button onClick={()=>{this.changeTextEventHandler()}}>Click me!</button> */}
        <button onClick={this.changeTextEventHandler}>Click me!</button>
      </div>
    )
  }
}

export default ClickableClassComponent