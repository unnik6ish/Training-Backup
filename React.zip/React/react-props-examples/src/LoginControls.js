import React, { Component } from 'react'
import Greetings from './Greetings'
import LoginButton from './LoginButton'
import LogoutButton from './LogoutButton'

export class LoginControls extends Component {
  
  constructor(props) {
    super(props)

    this.state = {
        isLoggedin:false
    }
  }

  handleLoginClick = () =>{
    this.setState({
        isLoggedin:true
    })
  }

  handleLogoutClick = () =>{
    this.setState({
        isLoggedOut:false
    })
  }
  
    render() {
        let isLoggedIn = this.isLoggedIn
        let button
        if (isLoggedIn) {
            button = <LogoutButton clickFunction = {this.handleLogoutClick} />
        } 
        else {
            button = <LoginButton clickFunction = {this.handleLoginClick} />
        }
    return (
      <div>
        <Greetings isLoggedIn={isLoggedIn}/>
        {button}
        </div>
    )
  }
}
