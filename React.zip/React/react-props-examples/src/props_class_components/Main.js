import React, { Component } from 'react'

export class Main extends Component {
  render() {
    return (
      <div>
        <h1>{this.props.appName}</h1>
        <h2>Version : {this.props.version}</h2>
      </div>

    )
  }
}

export default Main