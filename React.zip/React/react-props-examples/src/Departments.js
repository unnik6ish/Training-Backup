import React, { useState } from 'react'

function Departments() {

    let insertNewDepartment =()=>{

        setDepartments(departments=> [...departments,
        {
            "id":1234,
        "deptName":"Digitial Marketing",
        "location":"Kochi"

        }])
    }


    let depts = [{
        "id":1234,
        "deptName":"HR",
        "location":"Chennai"
    },
    {
        "id":5678,
        "deptName":"Finance",
        "location":"Chennai"    
    },
    {
        "id":9012,
        "deptName":"IT",
        "location":"Chennai"
    },
    {
        "id":1314,
        "deptName":"Infra",
        "location":"Chennai"
    },
    {
        "id":1516,
        "deptName":"Logistics",
        "location":"Chennai"
    }]

    let[departments, setDepartments] = useState(depts)
    return (                                         
       <div>
        <button onClick={insertNewDepartment}>Insert new data!</button>
         <table border="1">
                <th>Department ID</th>
                <th>Department Name</th>
                <th>Department Location</th>
        {
            departments.map((department)=>(
                <tr key = {department}>
                    <td>{department.id}</td>
                    <td>{department.deptName}</td>
                    <td>{department.location}</td>
                </tr>
            ))
        }
    </table>
       </div>
  )
}

export default Departments