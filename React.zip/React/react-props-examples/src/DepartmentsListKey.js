import React, { useState } from 'react'
import DisplayDepartment from './DisplayDepartment'

function Departments() {
  
    let [departments, setDepartments] = useState(["Admin", "Finance", "HR"])
  
    return (
    <div>
        {
            departments.map((department, index)=>(

                <DisplayDepartment key ={index} value={department} />
            ))
        }
    </div>
  )
}

export default Departments