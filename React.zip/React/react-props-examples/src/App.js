import './App.css';
import { MyPost } from './state_in_class/MyPost';
// import Main from './props_class_components/Main';
// import DepartmentsListKey from './DepartmentsListKey';
// import ReviewComments from './ReviewComments';
// import { LoginControls } from './LoginControls';

// import ClickableClassComponent from './ClickableClassComponent';
// import ClickableFunctionalComponents from './ClickableFunctionalComponets';
// import Departments from './Departments';
// import Employee from './Employee';
// import Header from './props_function_components/Header';
// import MainSection from './props_function_components/MainSection';
// import UserInputForm from './UserInputForm';
// import FunctionalComponentWithState from './FunctionalComponentWithState';
// import LikeCalculator from './LikeCalculator';


function App() {
  return (
    <div className="App">
      {/* <ClickableFunctionalComponents />
      <ClickableClassComponent />
      <FunctionalComponentWithState />
      <LikeCalculator /> */}
      {/* <Departments /> */}
      {/* <UserInputForm /> */}
      {/* <Employee /> */}
      {/* <LoginControls /> */}
      {/* <ReviewComments /> */}
      {/* <DepartmentsListKey /> */}
      {/* <Header appName="This is my first react App" version ="2.0" author="Unnikrishnan"/>
      <MainSection/> */}
      {/* <Main appName="My first class based react App" version ="2.0"/> */}
      <MyPost newMessage = "This message is from App component"/>
    </div>
  );
}

export default App;
