import React, { useState } from 'react'
import axios from 'axios'

function Employees() {

//Setting up the base url for making requests  
    const api = axios.create({
        baseURL:"http://localhost:3000/employee"
    })

//employee state to hold the employee records in a centralized place

 let getAllRecords = () =>{
    api.get(`/`).then(res=>{
        console.log(res);
        setEmployees((employees)=>res.data)
    })
 }

    let insertARecord = () =>{
    let recordToInsert = {
            "id": empId,
            "empName": empName,
            "location": empLocation
          }
    
    api.post(`/`, recordToInsert)
    .then(res=>console.log(res))
    .catch(err=>console.log(err))
     getAllRecords()

    }   

    let deleteARecord = () =>{
            api.delete(`${empId}`)
            .then(res=>{
                alert(`A record has been deleted`)
            })
            .catch(err=>
            {
                console.log(err);
            })
            getAllRecords()
    }

    let amendARecord = () =>{
        let recordToAmend = {
                "id": empId,
                "empName": empName,
                "location": empLocation
              }
        
        api.patch(`/${empId}`, recordToAmend)
        .then(res=>alert(`Record with id :${recordToAmend.id}has been updated`))
        getAllRecords() 
        
        }

    const [employees, setEmployees] = useState([])  
    const [empId, setEmpId] = useState(``)
    const [empName, setEmpName] = useState(``)
    const [empLocation, setEmpLocation] = useState(``)

    let updateEmpId = (event) =>{
        setEmpId(event.target.value)
    }
    let updateEmpName = (event) =>{
        setEmpName(event.target.value)
    }
    let updateEmpLocation = (event) =>{
        setEmpLocation(event.target.value)
    }

  return (
    <div>
        <input type ="number" placeholder="Enter your employee ID here" onChange={updateEmpId}/><br/>
        <input type ="text" placeholder="Enter your name here" onChange={updateEmpName}/><br/>
        <input type ="text" placeholder="Enter your location here" onChange={updateEmpLocation}/><br/>

        <table border="1">
            <thead>
                <tr>
                    <th>Employee ID</th>
                    <th>Employee Name</th>
                    <th>Employee Location</th>
                </tr>
            </thead>
            <tbody>
                {
                    employees.map((employee)=>(
                        <tr key={employee.id}>
                            <td>{employee.id}</td>
                            <td>{employee.empName}</td>
                            <td>{employee.location}</td>
                        </tr>
                    ))
                }
            </tbody>
        </table>
        <br />
        <button onClick={getAllRecords}>Click to Refresh</button>
        <button onClick={insertARecord}>Insert Data</button>
        <button onClick={deleteARecord}>Delete Data</button>
        <button onClick={amendARecord}>Amend Data</button>
    </div>
  )
}

export default Employees