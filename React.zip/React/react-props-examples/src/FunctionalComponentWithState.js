import React, { useState } from 'react'

function FunctionalComponentWithState() {

    let [message, setMessage] = useState(()=>'Default message from functional components!')
    let [name, setName] = useState (()=>"Unni")
    let [balance, setBalance] = useState (()=>15000)

    let changeMessage = () =>{
        setMessage("Welcome to NatWest! Functional components are awesome")
    }

    let changeName = () =>{
        setName("Krishakumar")
    }

    let changeBalance = () =>{
        setBalance((b)=> b+1)
    }


  return (
    <div>
        <p>{message} , {name} , A/C Balance :${balance}</p>
        <button onClick={changeMessage}>Change Message</button>
        <button onClick={changeName}>Change Name</button> 
        <button onClick={changeBalance}>Change Balance</button> 
    </div>
  )
}

export default FunctionalComponentWithState