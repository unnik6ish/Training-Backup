import React from 'react'

const SubComponent = (props) => {
  return (
    <div>
        <h3>This is the SubComponent of MainSection</h3>
        <p><b>Value : </b>{props.value}</p>
        <p>Another Value : {props.anotherValue}</p>
    </div>
  )
}

export default SubComponent