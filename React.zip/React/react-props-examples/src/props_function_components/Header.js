import React from 'react'

const Header = (props) => {
  return (
    <div>
        <h1>{props.appName}</h1>
        <p>Author Name: {props.author}</p>
        <p>App Version: {props.version}</p>
    </div>
  )
}

export default Header