import React from 'react'
import SubComponent from './SubComponent'

const MainSection = () => {
  return (
    <div>
        <h2>This is the main Section</h2>
        <SubComponent value = "passing value to sub component" anotherValue = "another value passed through props"/>
    </div>
  )
}

export default MainSection