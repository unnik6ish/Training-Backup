import React from 'react'

function UserGreeting() {
  return (
    <div><h1>Welcome back!</h1></div>
  )
}

export default UserGreeting