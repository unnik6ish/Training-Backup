import React, { useState } from 'react'

function LikeCalculator() {

    let [likes, setLikes] = useState(()=> 0)

    let increaseLike = () =>{
        if(likes<10)
        setLikes((likes)=>likes+1)
    }
    let decreaseLike = () =>{
        if(likes>0)
        setLikes((likes)=>likes-1)  
    }

  return (
    <div>
        <p>Likes :{likes}</p>
        <button onClick={increaseLike}>Like</button>
        <button onClick={decreaseLike}>Dislike</button>
    </div>
  )
}

export default LikeCalculator