import React from 'react'
import GuestGreeting from './GuestGreeting'
import UserGreeting from './UserGreeting'

function Greetings(props) {
  
    let isLoggedIn = props.isLoggedIn

     if (isLoggedIn) {

        return<UserGreeting />
        
     } else 
     {
        return<GuestGreeting />
     }
}

export default Greetings