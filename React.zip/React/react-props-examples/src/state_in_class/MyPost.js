import React, { Component } from 'react'

export class MyPost extends Component {

  constructor(props) {
    super(props)
  
    this.state = {
       message:"Hi World",
       likes:0
    }
  }

  changeMessgae = () => {
    this.setState({
      message:"Hi you changed the world in a button click"
    })
  }

  increaseLikes = () => {
    this.setState({
      likes: this.state.likes+1 
    })
  }

  decreaseLikes = () => {
    this.setState({
      likes:this.state.likes-1
    })
  }

  render() {
    return (
      <div>
        <p>Post 1</p>
        <p>Descrption of post 1</p>
        <p>Message: {this.state.message}</p>
        <p>Likes : {this.state.likes}</p>
        <p>New Message : {this.props.newMessage}</p>
        <button onClick={this.changeMessgae}>Change Message</button>
        <button onClick={this.increaseLikes}>increase Likes</button>
        <button onClick={this.decreaseLikes}>decrease Likes</button>
      </div>
    )
  }
}

export default MyPost