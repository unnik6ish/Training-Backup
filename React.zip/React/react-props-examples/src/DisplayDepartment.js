import React from 'react'

function DisplayDepartment(props) {
  return (
    <div>{props.value}</div>
  )
}

export default DisplayDepartment