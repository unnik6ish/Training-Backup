import React, { useState } from 'react'

function UserInputForm() {
 
  const [name, setName] = useState()
  const [message, setMessage] = useState()
  const [updatedName, setUpdatedName] = useState("")
  const [updatedMessage, setUpdatedMessage] = useState("")
  
  let nameChanged = (event) =>{
    setName(name =>event.target.value)
  }

  let messageChanged = (event) =>{
    setMessage(message =>event.target.value)
  }
  let updateNameAndMessage = () =>{
    setUpdatedName(name)
    setUpdatedMessage(message)
  }  
    return (
    <div>
        {updatedName} <br/>
        <input type="text" placeholder='Input your name' onChange={nameChanged}></input><br/>
        {updatedMessage} <br/>
        <input type="text" placeholder='Input your message' onChange={messageChanged}></input><br/>
        <button onClick={updateNameAndMessage}>Click Me!</button>
    </div>
  )
}

export default UserInputForm