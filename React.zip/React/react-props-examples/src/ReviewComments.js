import React, { useState } from 'react'
import axios from 'axios'
function ReviewComments() {

  const api = axios.create({
    baseURL:"http://localhost:3000/employee"
})

  function inputComments(){
  let commentsToInsert = {
    "author": authName,
    "comments": authComments
  }
  api.post(`/`, commentsToInsert)
}
const [authName, setauthName] = useState(``)
const [authComments, setauthComment] = useState(``)

let updateName = (event) => {
  setauthName(event.target.value)
}
  let updateComments = (event) =>{
    setauthComment(event.target.value)
}
  return (
    <div>
        <input type="text" placeholder='enter your name' onChange={updateName}></input><br/>
        <input type="text" placeholder='enter your comments' onChange={updateComments}></input><br/>
        <button onClick={inputComments}>Post</button>
    </div>
  )
}

export default ReviewComments