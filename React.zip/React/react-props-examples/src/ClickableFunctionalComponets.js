import React from 'react'


function ClickableFunctionalComponents() {

  function showAlert (){

  alert("youcalledme!")

}

  return (
    <div>
        <button onClick={showAlert}>Click me!</button>
    </div>
  )
}

export default ClickableFunctionalComponents