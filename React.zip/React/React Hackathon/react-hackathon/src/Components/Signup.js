import { Box, Button, TextField, Typography } from '@mui/material'
import React, { useState } from 'react'
import axios from 'axios';
import { useNavigate } from 'react-router-dom'

const Signup = () => {

    const api = axios.create({
        baseURL:`http://localhost:3000/registeredDetails`
    })
     
    const navToLogin = useNavigate()
    const routeToLogin =()=>{
        
        navToLogin("/login")
    }

    const[userEmail, setUserEmail]=useState(``);
    const[userName, setUserName]=useState(``);
    const[userAddress, setUserAddress]=useState(``);
    const[userAccNo, setUserAccNo]=useState(0);
    const[userMobNo, setUserMobNo]=useState(0)    
    const[userPassword, setUserPassword]=useState(``)

    const validEmail = /^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,3}$/
    const validName = /^[a-zA-Z]{3,}$/
    const validMobNo = /^[0-9]\d{09}$/
    const validAccNo = /^[0-9]\d{07}$/
    const validPassword = /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#%^&])(?!.* ).{8,20}$/

    const submitDetails=(event)=>{
        event.preventDefault()

    if ( !validEmail.test(userEmail) )
        {
            alert(`Enter a valid email id`)
        }
    else if ( !validName.test(userName) )
        {
            alert(`Name must contain 3 characters only alphabets`)
        }
    else if ( !validAccNo.test(userAccNo) )
        {
        alert(`Enter your 8 digit roll no`)
        }
    else if ( !validMobNo.test(userMobNo) )
        {
            alert(`Enter your 10 digit mobile number`)
        }
    else if ( !validPassword.test(userPassword) )
        {
            alert(`Choose a strong password`)
        }

    else
    {
        const inputDetails = {
            "id":userEmail,
            "name":userName,
            "address":userAddress,
            "accnumber":userAccNo,
            "mobnumber":userMobNo,
            "password":userPassword
        }
        api.post(`/`,inputDetails)
        .then(res=>console.log(res))
        .catch(err=>console.log(err))
        console.log(inputDetails);
        alert("sign up success")
        navToLogin("/login")
    }
}

    const inputUserEmail = (event) =>{
        setUserEmail(event.target.value)
        console.log(event.target.value);
    }
    const inputUserName = (event) =>{
        setUserName(event.target.value)
        console.log(event.target.value);
    }
    const inputUserAddress = (event) =>{
        setUserAddress(event.target.value)
        console.log(event.target.value);
    }
    const inputUserAccNo = (event) =>{
        setUserAccNo(event.target.value)
        console.log(event.target.value);
    }
    const inputUserMobNo = (event) =>{
        setUserMobNo(event.target.value)
        console.log(event.target.value);
    }
    const inputUserPassword = (event) =>{
        setUserPassword(event.target.value)
        console.log(event.target.value);
    }
  return (
        <form>
            <Box
                  display="flex" 
                  flexDirection="column" 
                  maxWidth={400} 
                  alignItems="center" 
                  justifyContent={"center"} 
                  margin="auto"
                  marginTop={5}
                  padding={3}
                  borderRadius={5}
                  boxShadow={"5px 5px 10px #401664"}
                  sx={{
                      ":hover": {
                        boxShadow:"10px 10px 20px #401664"
                      }
                  }}
                >
                <Typography variant='h5' padding={3} textAlign="center">Signup</Typography>
                <TextField name ="email" margin='normal' type="email" variant='outlined' placeholder='Email' onChange={inputUserEmail}/>
                <TextField name = "name" margin='normal' type="text" variant='outlined' placeholder='Name' onChange={inputUserName}/>
                <TextField name ="address" margin='normal' type="text" variant='outlined' placeholder='Address' onChange={inputUserAddress}/>
                <TextField name = "accountno" margin='normal' type="number" variant='outlined' placeholder='Account No' onChange={inputUserAccNo}/>
                <TextField name ="mobno" margin='normal' type="number" variant='outlined' placeholder='Mob Number' onChange={inputUserMobNo}/>
                <TextField name = "password" margin='normal' type="password" variant='outlined' placeholder='Password' onChange={inputUserPassword}/>
                <Button variant='contained' type='submit'sx={{ marginTop:3 , borderRadius: 3 }} onClick={submitDetails}>Signup</Button><br/>
                <Typography variant='h7' margin='normal' textAlign="center">Already have an account?</Typography>
                <Button variant='contained' type='submit'sx={{ marginTop:3 , borderRadius: 3 }} onClick={routeToLogin}>Login</Button>
            </Box>
        </form>
  )
}

export default Signup