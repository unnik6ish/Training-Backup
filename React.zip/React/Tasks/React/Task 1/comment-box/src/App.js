import CommentBoxForReview from './CommentBoxForReview'
import './App.css';

function App() {
  return (
    <div className="App">
      <CommentBoxForReview />
    </div>
  );
}

export default App;
