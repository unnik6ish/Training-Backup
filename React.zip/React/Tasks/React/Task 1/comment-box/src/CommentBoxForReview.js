import React, {useState} from 'react'
import axios from 'axios'

function CommentBoxForReview() {

    const api = axios.create({
        baseURL:`http://localhost:3000/ReviewCommentBox`
    })

    let getComments = () =>{
        api.get('/').then(res=>{
            console.log(res);
            setCommentBox((ReviewCommentBox))
        })
    }

    let insertComment = () =>{
        let commentToInsert = {            
            "author":authorName,
            "comments":authorComments
        }

        api.post(`/`, commentToInsert)
        .then(res=>console.log(res)).catch(err=>console.log(err))
        console.log(commentToInsert);

    }

    const [ReviewCommentBox, setCommentBox] = useState([])
    const [authorComments, SetAuthorComments] = useState('')
    const [authorName, SetAuthorName] = useState('')

    let inputAuthorName = (event)=>{
        SetAuthorName(event.target.value)
        console.log(authorComments);
    }
    let inputAuthorComments= (event)=>{
        SetAuthorComments(event.target.value)
        console.log(authorName);
    }

  return (
    <div>
        <h4>Comment Box</h4>
        <b>Author : </b><input type ="text" placeholder = "Input your name here" onChange={inputAuthorName}/> <br/>
        <b>Comments : </b><input type ="text" placeholder = "Input your comments"onChange={inputAuthorComments}/> <br/>
        <table border ="1">
            <thead>
                <tr>
                    <th>Author Name</th>
                    <th>Comments</th> 
                </tr>
            </thead>
            <tbody>
                    {
                        ReviewCommentBox.map((reviewCom)=>(
                            <tr key={reviewCom.id}>
                                <td>{reviewCom.author}</td>
                                <td>{reviewCom.comments}</td>
                            </tr>
                        ))
                    }
            </tbody>
        </table> 
            <button onClick={getComments}>Refresh</button>
            <button onClick={insertComment}>Post Comments</button>  
    </div>
  )
}

export default CommentBoxForReview