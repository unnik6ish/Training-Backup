
Daily Task - 1

Please do the following task:
Create a react app with the comment section that contains two input fields and a button. The comment section must get input for the "author name" & "Comment message". Clicking the "Post comment" in the comment component or pressing the enter key must make a post request to the backend to push the comment into the db.json file. The newly inserted comment must be automatically rendered below the comment section along with the existing comments
