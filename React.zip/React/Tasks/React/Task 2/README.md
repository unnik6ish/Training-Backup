
Daily Task - 2

Create a component named Todo and create an array of Todo objects [{}, {}, {}]. Each todo object must contain {id, taskName }.
Render the todos and display them with another component named "DisplayTodo" using map function. Identify and assign the key for each todo display

