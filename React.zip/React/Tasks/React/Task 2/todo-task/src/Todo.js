import React, { useState } from 'react'
import DisplayTodo from './DisplayTodo'

function Todo () {

    let [todos, setTodo] = useState ([

        {"id":123,
         "taskName":"Task1"
        },
    
        {"id":456,
        "taskName":"Task2"
        },    
        {
            "id":789,
         "taskName":"Task3"
        },
    
        {
            "id":1011,
         "taskName":"Task4"
        }
        ])  
  return ( 
    <div>
        <table border="1">
          <thead>
            <tr>
              <th>Task ID</th>
              <th>Task Name</th>
            </tr>
          </thead>
          <tbody>
                { 
                  todos.map(todo =>(
                    <DisplayTodo key ={todo.id} value={todo}/>
                  ))                 
                }
        </tbody>
      </table>
    </div>
  )
}
export default Todo