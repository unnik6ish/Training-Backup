import React from 'react'

function DisplayTodo(props) {
  return (
    <tr>
      <td>{props.value.id}</td>
      <td>{props.value.taskName}</td>
    </tr>
  )
}

export default DisplayTodo