import './App.css';
import { BrowserRouter as Router, Routes, Route, Link} from 'react-router-dom';
import Teachers from './Teachers';
import Students from './Students';
function App() {
  return (
    <div className="App">
      <Router >
        <Link to = '/teacher'>Teachers</Link>
        <Link to = '/student'>Students</Link>
        <Routes>
          <Route path ='/teacher' element={<Teachers/>} />
          <Route path ='/student' element={<Students/>} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
