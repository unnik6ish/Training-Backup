import React,{useState} from 'react'
import axios from 'axios'
function Teachers() {

    let[teachers, setTeachers] = useState([])

    let api = axios.create({
        baseURL : 'http://localhost:3000/teacher/'
    })

    let getTeach =()=>{

            api.get('/').then(res=>{
                setTeachers(res.data)
            })
            .catch(err=>console.log("Error"))
        }       

  return (
    <div className="App">
        <table border="1">
            <thead>
                <tr>
                    <th>Teacher ID</th>
                    <th>Teacher Name</th>
                    <th>Subject</th>
                </tr>
            </thead>
            <tbody>
            {
                teachers.map(teacher => (
                    <tr key={teacher.id}>
                    <td>{teacher.id}</td>
                    <td>{teacher.name}</td>
                    <td>{teacher.subject}</td>
                </tr>
                ))
            }  
            </tbody>
        </table>
        <button onClick={getTeach}>Get details</button>
    </div>
  )
}

export default Teachers