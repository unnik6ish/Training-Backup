import React,{useState} from 'react'
import axios from 'axios'
function Students() {

    let[students, setStudents] = useState([])

    let api = axios.create({
        baseURL : 'http://localhost:3000/student/'
    })

    let getTeach =()=>{

            api.get('/').then(res=>{
                setStudents(res.data)
            })
            .catch(err=>console.log("Error"))
        }       

  return (
    <div className="App">
        <table border="1">
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Student Name</th>
                    <th>Branch</th>
                </tr>
            </thead>
            <tbody>
            {
                students.map(student => (
                    <tr key={student.id}>
                    <td>{student.id}</td>
                    <td>{student.name}</td>
                    <td>{student.branch}</td>
                </tr>
                ))
            }  
            </tbody>
        </table>
        <button onClick={getTeach}>Get details</button>
    </div>
  )
}

export default Students