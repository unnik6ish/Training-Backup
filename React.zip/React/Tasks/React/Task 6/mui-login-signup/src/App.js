import './App.css';
import LoginSignup from './LoginSignup';

function App() {
  return (
    <div className="App">
      <LoginSignup/>
    </div>
  );
}

export default App;
