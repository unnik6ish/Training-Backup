import { Visibility, VisibilityOff } from '@mui/icons-material';
import { Button, Container, Grid, IconButton, InputAdornment, Paper, TextField, Typography } from '@mui/material'
import React, { useState } from 'react'

const Login = () => {

  const [values, setValues] = useState({
    email: "",
    pass: "",
    showPass: false,
  });
  
  const handlePassVisibilty = () => {
    setValues({
      ...values,
      showPass: !values.showPass,
    });
  };

  return (
    <div>
      <Container maxWidth="xs">
          <Grid container spacing={2} direction="column" justifyContent="center" style={{ minHeight : "100vh"}}>
              <Paper elevation={12} sx={{padding:5}}>
                <Grid container spacing={2} direction="column">
                    <Typography variant='h5' style={{backgroundColor :  '#401664', color :"white", padding:'40px', borderRadius:'5px'}}>Log In</Typography>
                  <Grid item>
                    <TextField
                            type="email"
                            fullWidth
                            label="Enter your email"
                            placeholder="Email Address"
                            variant="outlined"
                            required
                          />
                  </Grid>
                  <Grid item>
                    <TextField
                            type={values.showPass ? "text" : "password"}
                            fullWidth
                            label="Enter your password"
                            placeholder="Password"
                            variant="outlined"
                            required
                            InputProps={{
                              endAdornment: (
                                <InputAdornment position="end">
                                  <IconButton
                                    onClick={handlePassVisibilty}
                                    aria-label="toggle password"
                                    edge="end"
                                  >
                                    {values.showPass ? <VisibilityOff/> : <Visibility />}
                                  </IconButton>
                                </InputAdornment>
                              ),
                            }}
                          />
                  </Grid>
                  <Grid item>
                    <Button variant="contained" style={{marginRight:'15px', backgroundColor : '#401664', color :"white"}}>Sign In</Button>
                    <Button variant="contained" style={{backgroundColor : '#401664', color :"white"}}>Clear</Button>
                  </Grid>
                </Grid>
              </Paper>
          </Grid>
      </Container>
    </div>
  )
}

export default Login