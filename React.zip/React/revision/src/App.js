import './App.css';
import Header from './Header'
import MyPost from './MyPost';

function App() {
  return (
    <div className="App">
      {/* <Header message="You have a message from the parent class" keyCode= "First four letter of your name"/> */}
      <MyPost newMessage = "message from the top"/>
    </div>
  );
}

export default App;
