import React from 'react'

const Header = (fromParent) => {
  return (
    <div>
        <h3>Hi World</h3>
        <p>{fromParent.message}</p>
        <p>{fromParent.keyCode}</p>
    </div>
  )
}

export default Header