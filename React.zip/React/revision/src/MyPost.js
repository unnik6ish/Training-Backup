import React, { Component } from 'react'

export default class MyPost extends Component {

    constructor(props) {
      super(props)
    
      this.state = {
         likes:0,
         message:"display here"
      }
    }
    likeButton = () =>{
      this.setState({
        likes: this.state.likes+1
      })
    }
    dislikeButton = () =>{
      this.setState({
        likes: this.state.likes-1
      })
    }
    displayMessage =(p)=>{
      this.setState({
        message:p.newMessage
      })
    }
  render() {
    return (
      <div>
        <h2>Counter</h2>
        <h3>No of likes: {this.state.likes}</h3>
        <h4>Message: {this.state.message}</h4>
        <button onClick={this.likeButton}>like</button>
        <button onClick={this.dislikeButton}>dislike</button>
        <button onClick={this.displayMessage}>Message</button>
      </div>
    )
  }
}
