import React from 'react'

function Header(props) {
  return (
    <div>
        <h1 >{props.usingProps} --- Write header here!</h1>         
    </div>
  )
}

export default Header