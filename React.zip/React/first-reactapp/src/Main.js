import React, { Component } from 'react'

export default class Main extends Component {
  render() {
    return (
      <div>
        <h1>{this.props.appName}</h1>
        <p>{this.props.title}</p>
        
      </div>
    )
  }
}
