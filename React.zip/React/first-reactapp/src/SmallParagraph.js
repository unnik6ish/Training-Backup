import React from 'react'

function SmallParagraph(props) {
  return (
    <div>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maxime ex, autem odit beatae architecto cumque quis velit quam, nulla molestiae assumenda repellendus recusandae commodi ipsam ducimus in dolorum itaque quisquam? Rem laudantium aliquid eos ipsam excepturi eaque. Sed vitae itaque beatae qui impedit rerum, iure dolorem ut aperiam debitis suscipit.</p>
        <h4>Is anything here? {props.toSmallpara}</h4>
    </div>
  )
}

export default SmallParagraph