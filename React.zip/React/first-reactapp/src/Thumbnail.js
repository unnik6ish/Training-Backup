import React from 'react'

function Thumbnail() {
  return (
    <div>
        <ul>
            <li>Thumbnail 1</li>
            <li>Thumbnail 2</li>
            <li>Thumbnail 3</li>
            <li>Thumbnail 4</li>
            <li>Thumbnail 5</li>
        </ul>
    </div>
  )
}

export default Thumbnail