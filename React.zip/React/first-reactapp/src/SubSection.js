import React from 'react'
import SmallParagraph from './SmallParagraph'

function SubSection(props) {
  return (
    <div>
        <h3>Sub Section</h3>
        <p>{props.toSub}, {props.toSub} --- Sub section contents will be available here!</p>
        <SmallParagraph toSmallpara = "this is for small" />
    </div>
  )
}

export default SubSection