import React, { Component } from 'react'

class Aside extends Component {
  render() {
    return (
      <div>
        <h4>Advertisement goes here!</h4>
        <p>Ad 1</p>
        <p>Ad 2</p>
        <p>Ad 3</p>
      </div>
    )
  }
}

export default Aside
