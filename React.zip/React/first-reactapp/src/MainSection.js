import React from 'react'
import SubSection from './SubSection'

function MainSection(props) {
  return (
    <div>
        <h2>Main Section</h2>
        <p>Type all your main section content here!</p>
        <p>{props.toMain}</p>
        <SubSection toSub = "this is form Main Section to Sub"/>
    </div>
  )
}

export default MainSection