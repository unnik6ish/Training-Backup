import React, { Component } from 'react'

export class MyPost extends Component {

    constructor(props) {
      super(props)
    
      this.state = {
         likes:0,
        //  message : "Welcome"
      }
    }

    increaseLike = () =>{
        this.setState({
            // message : "Hello"
            likes : this.state.likes+1
        })
    }
    decreaseLike = () =>{
        this.setState({
            likes : this.state.likes-1
        })
    }
    

  render() {
    return (
      <div>
        <p>Post 1</p>
        <p>Description of Post 1</p>
        <p>No of likes: {this.state.likes}</p>
        <p>Message : {this.props.message}</p>
        <button onClick={this.increaseLike}>Like</button>
        <button onClick={this.decreaseLike}>Dislike</button>
      </div>
    )
  }
}
