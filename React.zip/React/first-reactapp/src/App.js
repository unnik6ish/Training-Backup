import './App.css';
import Aside from './Aside';
import Footer from './Footer';
import Header from './Header';
import Main from './Main';
import MainSection from './MainSection';
import { MyPost } from './MyPost';
import Thumbnail from './Thumbnail';

function App() {
  return (
    <div className="App">
      {/* <Header usingProps = "using props to render value from App to it's children"/>
      <MainSection toMain ="props for this session"/>
      <Thumbnail />
      <Aside />
      <Footer />
      <Main appName = "App Name : This is props using class components" title = "This is an experiment"/> */
      }
      <MyPost message = "Customer Name"/>

    </div>
  );
}

export default App;
