import React, { Component } from 'react'

class Footer extends Component {
  render() {
    return (
      <div>
        <h4>Copyright Information!</h4>
        <p>All copyright Information recerved to me</p>
      </div>
    )
  }
}

export default Footer