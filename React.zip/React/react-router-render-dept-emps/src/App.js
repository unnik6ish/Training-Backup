import './App.css';
import {BrowserRouter as Router, Routes, Route, Link} from 'react-router-dom';
import Employee from './Employee';
import Departments from './Departments';

function App() {
  return (
    <div className="App">
        <Router>
          <Link to ='/employees'>Employees</Link>
          <Link to ='/departments'>Departments</Link>
          <Routes>
            <Route path='/employees' element ={<Employee/>} />
            <Route path='/departments' element ={<Departments/>} />
          </Routes>
        </Router>
    </div>
  );
}

export default App;
