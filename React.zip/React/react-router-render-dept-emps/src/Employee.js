import React, { useState } from 'react'
import axios from 'axios'

function Employee() {

  let [employees, setEmployees] = useState([])

  let api = axios.create({
    baseURL: "http://localhost:3000/employees"
  })
   
  let getEmp = () =>{
    api.get('/').then(res=>{
      setEmployees(res.data)
    })
    .catch (err=>console.log("Error"))
  }

  return (
    <div>
      <button onClick={getEmp}>Get Employees</button>
      <table border="1">
        <thead>
          <tr>
            <th>Employee ID</th>
            <th>Employee Name</th>
            <th>Salary</th>
          </tr>
        </thead>
        <tbody>
          {
            employees.map(employees=>(
              <tr key={employees.id}>
                <td>{employees.id}</td>
                <td>{employees.empName}</td>
                <td>{employees.salary}</td>
              </tr>
            ))

          }
        </tbody>
      </table>
    </div>
  )
}

export default Employee