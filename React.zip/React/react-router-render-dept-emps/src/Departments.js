import React, { useState } from 'react'
import axios from 'axios'

function Departments() {

    let[departments, setDepartments] = useState([])

    let api = axios.create({
        baseURL : "http://localhost:3000/departments"
    })

    let getDepart = () =>{
        api.get('/').then(res=>{
            setDepartments(res.data)
        })
        .catch(err => console.log("Error"))
    }

  return (
    <div>
        <button onClick={getDepart}>Get Departments</button>
        <table border="1">
            <thead>
                <tr>
                    <th>Department ID</th>
                    <th>Department Name</th>
                    <th>LoCation</th>
                </tr>
            </thead>
            <tbody>
        {
            departments.map(departments => (
                <tr key={departments.id}>
                    <td>{departments.id}</td>
                    <td>{departments.depName}</td>
                    <td>{departments.location}</td>
                </tr>
            ))
        }
        </tbody>
        </table>
    </div>
  )
}

export default Departments