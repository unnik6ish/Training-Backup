import {  Card, CardContent, Typography } from '@mui/material'
import React from 'react'

const Dashboard = () => {
  return (
    <Card sx={{ maxWidth: 345 }}>
      <CardContent height="140">
        <Typography variant="h4">Student Name</Typography><br/>
        <Typography variant="h5">Academic Performance</Typography>
        <Typography>Grade:A+</Typography>
        <Typography>Class:10th</Typography>
        <Typography>Extra-curriculars Activities:</Typography>
      </CardContent>
    </Card>
  )
}

export default Dashboard