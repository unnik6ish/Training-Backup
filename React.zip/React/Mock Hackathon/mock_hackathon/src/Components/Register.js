import React, { useState } from 'react'
import axios from "axios"

const Register = () => {

const api = axios.create({
    baseURL:`http://localhost:3000/students`
})

const[firstName, setFirstName]=useState('');
const[lastName, setLastName]=useState('');
const[email, setEmail]=useState('');
const[number, setNumber]=useState(0);
const[rollNumber, setRollNumber]=useState(0);
const[address, setAddress]=useState('');
const[password, setPassword]=useState('')    



const submitDetails =()=>{
    const inputDetails = {
        "fname":firstName,
        "lname":lastName,
        "email":email,
        "number":number,
        "rnumber":rollNumber,
        "address":address,
        "password":password
    }
    
    api.post(`/`,inputDetails)
    .then(res=>console.log(res))
    .catch(err=>console.log(err))
    console.log(inputDetails);

}

const inputFirstName = (event) =>{
    setFirstName(event.target.value)
}
const inputLastName = (event) =>{
    setLastName(event.target.value)
}
const inputEmail = (event) =>{
    setEmail(event.target.value)
}
const inputNumber = (event) =>{
    setNumber(event.target.value)
}
const inputRollNumber = (event) =>{
    setRollNumber(event.target.value)
}
const inputAddress = (event) =>{
    setAddress(event.target.value)
}
const inputPassword = (event) =>{
    setPassword(event.target.value)
}
  return (
    <>
        <h3>Registration</h3>
        <input type="text" placeholder='enter your first name' onChange={inputFirstName}/><br/>
        <input type="text" placeholder='enter your first name' onChange={inputLastName}/><br/>
        <input type="email" placeholder='enter your email' onChange={inputEmail}/><br/>
        <input type="number" placeholder='enter your mob number' onChange={inputNumber}/><br/>
        <input type="number" placeholder='enter your roll number' onChange={inputRollNumber}/><br/>
        <input className='inputbox' type="text" placeholder='enter your address' onChange={inputAddress}/><br/>
        <input type="password" placeholder='enter your password' onChange={inputPassword}/><br/>
        <button onClick={submitDetails}>Submit </button>
    </>
  )
}

export default Register