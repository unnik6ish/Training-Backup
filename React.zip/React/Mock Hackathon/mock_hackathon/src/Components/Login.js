import React from 'react'

const Login = () => {

  return (
    <div>
        <h3>Login</h3>
        <input type="email" placeholder='enter your email'/><br/>
        <input type="password" placeholder='enter your password'/><br/>
        <button>Submit</button>
    </div>
  )
}

export default Login