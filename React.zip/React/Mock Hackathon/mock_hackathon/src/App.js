import './App.css';
import { BrowserRouter, Link, Route, Routes } from 'react-router-dom'; 
import Register from './Components/Register';
import Home from './Components/Home';
import Login from './Components/Login';
function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Link to='/'>Home</Link>
        <Link to='/registration'>Registration</Link>
        <Link to='/login'>Login</Link>
        <Routes>
          <Route path='/' element={<Home/>}/>
          <Route path='/registration' element={<Register/>}/>
          <Route path='/login' element={<Login/>}/>
        </Routes>
        </BrowserRouter>
    </div>
  );
}

export default App;
