import React, { useState } from 'react'
import { useDispatch } from 'react-redux'
import { login, logout } from './features/user'
const Login = () => {

    const [name, setName] = useState("")
    const [age, setAge] = useState(0)
    const [company, setCompany] = useState("")

    const dispatch = useDispatch()
    let loginClick = () =>{
        dispatch(login(
          {
            name,
            age,
            company
          }
        ))
    }

    let logoutClick = () =>{
      dispatch(logout(
      ))
    }

  return (
    <div>
      <input type="text" placeholder='Name' onChange={(e)=> setName(e.target.value)}/> <br/>
      <input type="number" placeholder='Age' onChange={(e)=> setAge(e.target.value)}/> <br/>
      <input type="text" placeholder='Company' onChange={(e)=> setCompany(e.target.value)}/> <br/>

      <button onClick={loginClick}>Login</button>
      <button onClick={logoutClick}>Logout</button>
    </div>
  )
}

export default Login