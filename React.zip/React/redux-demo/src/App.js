import './App.css';
import Profile from './Profile';
import Login from './Login';
import Welcome from './Welcome';

function App() {
  return (
    <div className="App">
     <Profile/>
     <Login/>
     <Welcome/>
    </div>
  );
}

export default App;
