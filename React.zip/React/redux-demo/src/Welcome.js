import React from 'react'
import { useSelector } from 'react-redux'

const Welcome = () => {

    const user = useSelector(state => state.user.value)

  return (
    <div>
        <p>Welcome : {user.name}</p>
        <p>Your company : {user.company}</p>
    </div>
  )
}

export default Welcome