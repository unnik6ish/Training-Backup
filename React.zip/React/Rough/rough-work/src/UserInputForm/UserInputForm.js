import React, { useState } from 'react'

const UserInputForm = () => {

    let[name, setName]=useState()
    let[message, setMessage]=useState()

    let[updatename, setUpdatename]=useState()
    let[updatemessage, setUpdatemessage]=useState()

    const inputName =(event)=>{
        // console.log(event.target.value);
        setName(()=>event.target.value)
    }

    const inputMessage =(event)=>{
        // console.log(event.target.value);
        setMessage(()=>event.target.value)
    }

    const updateDetails = () =>{
        setUpdatename(name)
        setUpdatemessage(message)
    }


  return (
    <div>
        <h5>Name: {updatename}</h5>
        <h5>Message: {updatemessage}</h5>
        <input type= {"text"} lab placeholder="enter your name"  onChange={inputName}/><br/>
        <input className='inputbox' type={"comments"} placeholder="enter your comments"onChange={inputMessage}/><br/>
        <button onClick={updateDetails}>Submit</button>
    </div>
  )
}

export default UserInputForm