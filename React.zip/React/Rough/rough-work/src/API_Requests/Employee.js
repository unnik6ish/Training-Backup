import React, { useState } from 'react'
import axios from 'axios'

const Employee = () => {

const api = axios.create({
    baseURL:`http://localhost:3000/employees`
})

const [employees, setEmployees]=useState([])

const getDetails=()=>{
    api.get(`/`).then(res=>{
        console.log(res.data);
        setEmployees((employees)=>res.data)
    })
}

  return (
    <>
        <table border="1">
            <thead>
                <tr>
                    <th>Employee ID</th>
                    <th>Employee Name</th>
                    <th>Location</th>
                </tr>
            </thead>
            <tbody>
            {
                employees.map((employee)=>(
                    <tr key={employee.id}>
                        <td>{employee.id}</td>
                        <td>{employee.name}</td>
                        <td>{employee.location}</td>
                    </tr>              
                ))
            }
            </tbody>
        </table>
        <button onClick={getDetails}>Refresh</button>
    </>
  )
}

export default Employee