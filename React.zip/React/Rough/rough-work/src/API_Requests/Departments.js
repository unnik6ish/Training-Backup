import React, { useState } from 'react'

const Departments = () => {

    

    let depts = [
        {
            "id":1,
            "deptName":"HR",
            "location":"Chennai"
        },
        {
            "id":2,
            "deptName":"Finanace",
            "location":"Delhi"
        },
        {
            "id":3,
            "deptName":"Operations",
            "location":"Kochi"
        },
        {
            "id":4,
            "deptName":"Marketing",
            "location":"Banglore"
        }
    ]

    let [departments, setDepartments] = useState(()=>depts)

    const newRecord = () =>{
        setDepartments(departments=>[...departments, {
            "id":5,
            "deptName":"Risk",
            "location":"Mumbai"
        }])
    }
  return (
    <>
    <button onClick={newRecord}>Insert new record</button>
    <table border="1">
        <thead>
            <th>ID</th>
            <th>Name</th>
            <th>Location</th>
        </thead>
         {
            departments.map((department)=>(
                    <tbody>     
                        <tr key={department.id}>
                            <td>{department.id}</td>
                            <td>{department.deptName}</td>
                            <td>{department.location}</td>
                        </tr>
                    </tbody>
            ))
        }
    </table>
    </>
  )
}

export default Departments