
import { BrowserRouter, Link, Route, Routes } from 'react-router-dom';
import './App.css';
import Home from './RegistrationAndLogin/Home';
import Login from './RegistrationAndLogin/Login';
import Registration from './RegistrationAndLogin/Registration';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Link to='/'>Home</Link>
      <Link to='/registration'>Registration</Link>
      <Link to='/login'>Login</Link>
        <Routes>
          <Route path='/' element={<Home/>}/>
          <Route path='/registration' element={ <Registration/>}/>
          <Route path='/login' element={<Login/>}/>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
