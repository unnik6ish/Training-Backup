import React, { Component } from 'react'

export class ClickableClassComponent extends Component {

    constructor(props) {
      super(props)
    
      this.state = {
         message:"Initial Message"
      }
    }

    // changeMessage(){
    //     this.setState({
    //         message:"Message Changed!"
    //     })
    // }

    //Using arrow function here
    //Arrow function itself contains the bind method

    changeMessage=()=>{
        this.setState({
            message:"Message Changed!"
        })
    }

    clickMe() {
        alert("You clicked  in class based component")
    } 

  render() {
    return (
      <div>
        {/* <button onClick={this.clickMe}>Click Me</button> */}
        <h1>{this.state.message}</h1>
        {/* <button onClick={this.changeMessage.bind(this)}>Click to Change Message</button> */}
        {/* We can use arrow function to avoid bind keyword when we call event handler*/}
        {/* <button onClick={()=>{this.changeMessage()}}>Click to Change Message</button> */}
        <button onClick={this.changeMessage}>Click to Change Message</button>
      </div>
    )
  }
}

export default ClickableClassComponent