import React, { Component } from 'react'

export class MainClassForState extends Component 
{
    //rconst is the short kay for creating a constructor
    constructor(props) {
      super(props)
    
      this.state = {
         like:0
      }
    }

    increaseLikes = () =>{
        this.setState({
            like: this.state.like+1
        })
    }
     

  render() 
  {
    return (
      <div>
        <h1>Posts</h1>
        <p>No of Likes : {this.state.like}</p>
        <button onClick={this.increaseLikes}>Like</button>
      </div>
    )
  }
}

export default MainClassForState