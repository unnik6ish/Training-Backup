import React from 'react'

const SubSubSection = (props) => {
  return (
    <div>
        <h1>This is SubSubSection</h1>
        <h2>In Sub Sub : {props.messageFromAppJs}</h2>
    </div>
  )
}

export default SubSubSection