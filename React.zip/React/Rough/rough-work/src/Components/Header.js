import React from 'react'
import SubSection from './SubSection'

const Header = (props) => {
  return (
    <div>
        <h1>Header</h1>
        <SubSection messageFromAppJs = {props.messageFromAppJs}/>
        <h2>In Header : {props.messageFromAppJs}</h2>
    </div>
  )
}

export default Header