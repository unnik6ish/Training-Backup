import React from 'react'
import Header from './Header'

const Main = (props) => {
  return (
    <div>
        <h1>Main</h1>
        <Header messageFromAppJs = {props.messageFromAppJs}/>
        <h2>In Main : {props.messageFromAppJs}</h2>
    </div>
  )
}

export default Main