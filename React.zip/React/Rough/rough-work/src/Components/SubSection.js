import React from 'react'
import SubSubSection from './SubSubSection'

const SubSection = (props) => {
  return (
    <div>
        <h1>SubSection</h1>
        <SubSubSection messageFromAppJs = {props.messageFromAppJs}/>
        <h2>In Sub : {props.messageFromAppJs}</h2>
    </div>
  )
}

export default SubSection