import axios from 'axios';
import React, { useState } from 'react'

const Registration = () => {

const api = axios.create({
    baseURL:`http://localhost:3000/employees`
})

const[name, setName]=useState('');
const[email, setEmail]=useState('');
const[number, setNumber]=useState(0);
const[address, setAddress]=useState('');
const[password, setPassword]=useState('')    

const inputName = (event) =>{
    setName(event.target.value)
}

const submitDetails =()=>{
    const inputDetails = {
        "name":name,
        "email":email,
        "number":number,
        "address":address,
        "password":password
    }
    
    api.post(`/`,inputDetails)
    .then(res=>console.log(res))
    .catch(err=>console.log(err))
    console.log(inputDetails);

}

const inputEmail = (event) =>{
    setEmail(event.target.value)
}
const inputNumber = (event) =>{
    setNumber(event.target.value)
}
const inputAddress = (event) =>{
    setAddress(event.target.value)
}
const inputPassword = (event) =>{
    setPassword(event.target.value)
}

return (
    
    <>
        <h3>Registration</h3>
        <input type="text" placeholder='enter your name' onChange={inputName}/><br/>
        <input type="email" placeholder='enter your email' onChange={inputEmail}/><br/>
        <input type="number" placeholder='enter your number' onChange={inputNumber}/><br/>
        <input className='inputbox' type="text" placeholder='enter your address' onChange={inputAddress}/><br/>
        <input type="password" placeholder='enter your password' onChange={inputPassword}/><br/>
        <button onClick={submitDetails}>Submit </button>
        
    </>
  )
}

export default Registration