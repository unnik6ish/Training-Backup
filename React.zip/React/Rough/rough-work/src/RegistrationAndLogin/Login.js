import axios from 'axios'
import React, { useState } from 'react'

const Login = () => {
    const api = axios.create({
        baseURL:`http://localhost:3000/employees`
    })


const [userDetails, setUserDetails] = useState([])
const [loginEmail, setLoginEmail]= useState("")
const [loginPassword, setLoginPassword] =useState("")

const matchLogin=()=>{

    api.get(`/`).then(res=>{
        console.log(res.data);
        setUserDetails((ud)=>res.data)
    })
    for (let i = 0; i < employees.length; i++) {
        if (inputLoginEmail === employees[i].email && inputLoginPassword === employees[i].password) 
        {
            alert("Login successful")
        }
        else
        {
        alert("User details not found in database")
        }
    }

const inputLoginEmail=(event)=>{
    setLoginEmail(event.target.value)
    console.log(event.target.value);
}

const inputLoginPassword=(event)=>{
    setLoginPassword(event.target.value)
    console.log(event.target.value);
}

  return (
    <div>
        <h3>Login</h3>
        <input type="email" placeholder='enter your email' onChange={inputLoginEmail}/><br/>
        <input type="password" placeholder='enter your password' onChange={inputLoginPassword}/><br/>
        <button onClick={matchLogin}>Submit</button>
    </div>
  )
}
}
export default Login