import React, { useState } from 'react'

const LikesCounter = () => {

    let [likes, setLikes] = useState(()=>0)

    const increaseLikes =()=>{
        setLikes((likes)=>likes+1)
    }

    const decreaseLikes =()=>{
        if(likes>0){
            setLikes((likes)=> likes-1)
        }
    }

  return (
    <div>
        <h2>Likes Counter</h2>
        <h3>Likes : {likes}</h3>
        <button onClick={increaseLikes}>Like</button>
        <button onClick={decreaseLikes}>DisLike</button>
    </div>
  )
}

export default LikesCounter