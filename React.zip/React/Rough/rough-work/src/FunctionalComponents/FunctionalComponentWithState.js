import React, { useState } from 'react'

const FunctionalComponentWithState = () => {

    let [message, setmessage] = useState(()=>"I feel like i made the")
    let [decision, setDecision] = useState(()=>" wrong decision")

    const checkDecision = () =>{
        setDecision (()=>" right decision")
    }

    let [balance, seBalance] = useState(()=>"$2000")

    const updateBalalce = () =>{
        seBalance (()=>"$3000")
    }

  return (
    <div>
        <h3>{message}{decision}</h3>
        <h2>Current balance : {balance}</h2>
        <button onClick={checkDecision}>Check your decision!</button>
        <button onClick={updateBalalce}>Update!</button>
    </div>
  )
}

export default FunctionalComponentWithState