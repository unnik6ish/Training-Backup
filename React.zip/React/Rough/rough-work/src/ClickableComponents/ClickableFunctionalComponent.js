import React from 'react'

function ClickableFunctionalComponent() {

    const clickFunction = () =>{
        alert("You clicked in functional based component")
    }

  return (
    <div>
        <button onClick={clickFunction}>Click Me</button>
    </div>
  )
}

export default ClickableFunctionalComponent