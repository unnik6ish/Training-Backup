console.log("Do while loop:");

let counter = 0
do{
    console.log("Hello world");
    counter++
}while(counter>10);


console.log("While loop");
let counter2 = 0
while(counter2>10){
    console.log("Hello world");
    counter2++
}
