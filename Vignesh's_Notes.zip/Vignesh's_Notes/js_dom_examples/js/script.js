let loginMessage=""
let flag = 0

function changeText(){
    let myPara = document.getElementById("para")
    myPara.innerText = "New Content"
}

function submitData(){
    let username = document.getElementById("username").value
    let password = document.getElementById("pwd").value
    let loginStatus = document.getElementById("loginStatus")
    if(username==password){
        loginMessage = "Login Success"       
    }
    else{
        loginMessage = "Login failed"
    }

    loginStatus.innerText = loginMessage
}

function changeLike(){
    let paraText = document.all[7].children[0].children[2].innerText

    if(paraText=="Like"){
        document.all[7].children[0].children[2].innerText = "DisLike"
    }
    else{
        document.all[7].children[0].children[2].innerText = "Like"
    }
}

function changeCourse(){
    if(flag==0){
        document.all[7].children[0].children[0].innerText = "Java Script FSD"
        document.all[7].children[0].children[1].children[1].innerText = "Github"
        document.all[7].children[0].children[1].children[2].innerText = "Nodejs"
        flag = 1
    }
    else{
        document.all[7].children[0].children[0].innerText = "Java FSD"
        document.all[7].children[0].children[1].children[1].innerText = "Gitlab"
        document.all[7].children[0].children[1].children[2].innerText = "Java Backend"
        flag = 0
    }
}

function insertMenu(){
    let newCode = `
        <ul>
            <li>Idly</li>
            <li>Dosa</li>
            <li>Chapati</li>
            <li>Biriyani</li>
        </ul>
    `

    let container = document.getElementById("container")

    container.innerHTML = newCode
}