let comments  = [
    "Good Product",
    "Average",
    "Best buy",
    "Cheap price"
]

function waitAndGreet(){
    setTimeout(()=>{
        console.log("Hello and welcome!");
        comments.forEach((comment)=>{
            console.log(comment);
        })
    }, 2000)
}
waitAndGreet()