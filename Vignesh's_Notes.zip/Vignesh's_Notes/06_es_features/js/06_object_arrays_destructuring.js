function printStudentDetail(stud){
    let {sid: studentId, department: myDepartment} = stud

    console.log(`Student id: ${studentId}`);
    console.log(`Student department: ${myDepartment}`);
}

function extractMarks(marks){
    // let [mark1, mark2,,,,, mark7] = marks 
    // console.log(`Mark 1: ${mark1}`);
    // console.log(`Mark 2: ${mark2}`);
    // console.log(`Mark 3: ${mark3}`);
    // console.log(`Mark 4: ${mark4}`);
    // console.log(`Mark 5: ${mark7}`);

    let [mark1, mark2, ...others] = marks
    console.log(`Mark 1: ${mark1}`);
    console.log(`Mark 2: ${mark2}`);
    console.log(`Other Marks: ${others}`);
}

let student = {
    sid:123,
    sname:"Vijay", 
    department: "CSE"
}

let marksArr = [95, 99, 65, 89,90, 76, 87]

printStudentDetail(student)
extractMarks(marksArr)
