function generateOtp(cb){
    setTimeout(function(){
        console.log("OTP has been generated");
        cb()
    }, 4000)
}

function inputOtp(){
    setTimeout(function(){
        console.log("OTP Entered");
    }, 2000)
}

generateOtp(inputOtp)
