var country = "US"
var country = "UK"

function printingVariable(){
    var country = "Australia"
    console.log("Inside the function : ",country);
}

console.log("Outside the function : ",country);
printingVariable()
console.log("Outside the function after function call: ",country);

