async function plan1 (){
    setTimeout(()=>{
        console.log("Plan 1 completed");
        return new Promise((res,rej )=>{
            res("Promise completed")
        })
    }, 3000)
}

async function plan2() {
    setTimeout(()=>{
        console.log("Lets continue with plan 2");
    }, 1000)
}

async function executePlans(){
    await plan1()
    plan2()
}

executePlans()