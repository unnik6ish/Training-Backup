function printStudent(stud){
    console.log(`Student id: ${stud.sid}`);
    console.log(`Student Name: ${stud.sname}`);
    console.log(`Student Country: ${stud.country}`);

}

// function printStudentDetails(stud){
//     let student = {
//         sid: stud.sid,
//         sname: stud.sname,
//         country: stud.country
//     }

//     console.log(`Student id: ${student.sid}`);
//     console.log(`Student Name: ${student.sname}`);
//     console.log(`Student Country: ${student.country}`);
// }

function printStudentDetails({sid, sname, country}){
    let vignesh = {
       studentid:sid,
       country,
       sname
    }

    console.log(`Student id: ${vignesh.studentid}`);
    console.log(`Student Name: ${vignesh.sname}`);
    console.log(`Student Country: ${vignesh.country}`);
}

let student = {
    sid:1234,
    sname:"Vignesh",
    country:"India"
}

// printStudent(student)
printStudentDetails(student)