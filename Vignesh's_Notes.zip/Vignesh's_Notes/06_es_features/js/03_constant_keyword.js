const country = "US"
// country = "India"


function printingVariable(){
    country = "Japan"
    // country = "Peru"
    console.log("Inside the function : ",country);
}

console.log("Outside the function : ",country);
printingVariable()
console.log("Outside the function after function call: ",country);
