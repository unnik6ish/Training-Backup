function receiveRequest(){
    setTimeout(function(){
        console.log("Receive the chellan");
        console.log("Verify the details");
        console.log("Receive money from the customer");
        console.log("Deposit money to another account");
        console.log("Request Handled...");
    }, 3000)

    // Since setTimeout function is an async function it won't wait for it to complete the execution
    // Instead it immediately moved to the next line
    console.log("Next person approaching to the counter");
}

// function handlerFunction(){
//     console.log("Request handled...");
// }

receiveRequest()