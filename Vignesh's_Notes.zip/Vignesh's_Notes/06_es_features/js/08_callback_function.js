function test(name){
    console.log("Hello world");
    console.log(name);
}

function test2(action){
    action("Dinesh")
}

// test("Bharath")

test2(test)