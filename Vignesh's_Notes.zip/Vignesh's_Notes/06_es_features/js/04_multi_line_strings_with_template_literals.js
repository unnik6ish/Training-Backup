let message = "Welcome to stackroute's programming"
let author = 'You are about to "learn Java FSD"'
let completeMessage = "Welcome to stackroute's Programming You are about to \"learn Java FSD\""

let multiLineStringOldWay = "Courses covered: \nFrond end\nBackend\nDevops" 

let courseDuration = 10
let multiLineStringES6 = `
    Front end:
        1. Html
        2. Css
        3. JS
        4. React

        Total Duration ${courseDuration} Hrs
        Welcome Message ${courseDuration}
        Author's Message ${author}
`
console.log(message);
console.log(author);
console.log(completeMessage);

console.log(multiLineStringOldWay);
console.log(multiLineStringES6);