let marks = [43,34,56,76,39,40,55]
let studentDetails = [
    {
        "sid":123,
        "sname":"Vijay",
        "age":25
    },
    {
        "sid":125,
        "sname":"Ajay",
        "age":27
    }
];

// for of loop

// for(let mark of marks){
//     console.log(mark);
// }

//for in loop

// for(let index in marks){
//     console.log(marks[index]);
// }

// Regular for loop

// for(let i=0; i<marks.length-1; i++){
//     console.log(marks[i]);
// }

// forEach loop
marks.forEach(
    function(i){
        console.log(i);
    }
)

studentDetails.forEach(
    function(student){
        console.log(student);
    }
)