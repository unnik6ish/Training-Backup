let marks = [98, 99, 78, 90, 55, 65, 87]
function iterateMarks(m){
    console.log(m);
}

marks.forEach(iterateMarks)