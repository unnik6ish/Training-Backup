let allGood = false


function goingToMovieTheatre(){
    let dineshPromise = new Promise((resolve, reject)=>{
        if(allGood){
            resolve("Dinesh has reached to the beach at 5.30pm")
        }
        else{
            reject("Dinesh has some issue reaching at the beach, informs Amutheshwaran")
        }
    })   
    return dineshPromise
}

let promise = goingToMovieTheatre()
promise.then(function(result){
    console.log(result);
    console.log("Dinesh kept his promise lets start from the house!");
})
.catch(function(errorMsg){
    console.log(errorMsg);
    console.log("Call Dinesh to check if he is good!");
})
