let country = "US"
//let country = "UK"  // Variables created with ket keyword can't be recreated
country = "India"

function printingVariable(){
    let country = "Australia"
    country = "Newzealand" // Can't be redeclared if in the same scope

    console.log("Inside the function : ",country);
}

console.log("Outside the function : ",country);
printingVariable()
console.log("Outside the function after function call: ",country);
