let comments  = [
    "Good Product",
    "Average",
    "Best buy",
    "Cheap price"
]

function getAllComments(){
    let content=''
    setTimeout(function(){
        comments.forEach(function(comment){
            content = content+ `<p> ${comment} </p>`
        })
        let container = document.getElementById('container')
        container.innerHTML = content
        console.log(content);
        // console.log(container);
    }, 1000)
}

function postANewComment(cb){
    let newComment = document.getElementById("newComment").value
  
    setTimeout(function(){
        comments.push(newComment)
        console.log("Comment posted");
        cb()
    }, 3000)
}

function postAndRetrieveComments(){
    postANewComment(getAllComments)
    // getAllComments()
}

// getAllComments()