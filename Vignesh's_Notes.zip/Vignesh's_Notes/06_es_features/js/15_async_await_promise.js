let allGood = true


async function goingToMovieTheatre(){
    let dineshPromise = new Promise((resolve, reject)=>{
        setTimeout(()=>{
            if(allGood){
                resolve("Dinesh has reached to the beach at 5.30pm")
            }
            else{
                reject("Dinesh has some issue reaching at the beach, informs Amutheshwaran")
            }
        }, 4000)
        
    })   
    return dineshPromise
}

async function amutheshwaranPlan(){
    let promise = await goingToMovieTheatre()
    console.log("Finalising to start from house");
}

amutheshwaranPlan()