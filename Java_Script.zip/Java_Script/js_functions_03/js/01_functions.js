function doSomethin(){
    console.log("Hello World");
    console.log("Welcome to JS functions");
    console.log("The End");
}

doSomethin()

// ****************************************************

function addNumbersAndDisplay(num1, num2) {
    let result = num1+num2
    console.log("Sum = "+result);
}

addNumbersAndDisplay(100, 567)

// ****************************************************

function getName() {
    console.log("Hello")
    return "Unnikrishnan"
}

console.log(getName());

// ****************************************************

function getNameLength(yourName) 
{
    return yourName.length
}

console.log("Your name length: "+(getNameLength("Unnikrishnan")));