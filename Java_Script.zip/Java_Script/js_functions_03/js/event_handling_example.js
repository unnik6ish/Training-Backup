function connect_para_with_event() {
    let myPara = document.getElementById("myPara")
    myPara.innerText = "I'm a super human now!. Click me!"
    myPara.addEventListener("click",showMessage)
}

function showMessage() {
    alert("I got super powers to display the alert box!")
    
}