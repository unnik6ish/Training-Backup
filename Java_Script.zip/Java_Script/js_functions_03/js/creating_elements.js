function createNewElements() {
    let container = document.getElementById("container")
}

let newAnchorTag = document.createElement('a')
newAnchorTag.href = "https://www.google.com"
newAnchorTag.innerText = "Click me to go to google"
newAnchorTag
newAnchorTag




let ul = document.createElement("ul")

let li1 = document.createElement("li")
li1.innerText = "Idly"
let li2 = document.createElement("li")
li2.innerText = "Dosa"
let li3 = document.createElement("li")
li3.innerText = "Chapati"
let li4 = document.createElement("li")
li4.innerText = "Roti"

li1.addEventListener("Click", test)

ul.appendChild(li1)
ul.appendChild(li2)
ul.appendChild(li3)
ul.appendChild(li4)

container.appendChild(newAnchorTag)
container.appendChild(ul)

}

function test(e) {
    alert("You have orderd Idly", e)  
}