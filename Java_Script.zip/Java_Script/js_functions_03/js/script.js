function changeText(){
    let firstPara = document.getElementById("firstPara")
    console.log("Old Text: "+firstPara.innerText);
    firstPara.innerText = "New Text!!!"
    console.log("New Text: "+firstPara.innerText);
}

function showAlert(){
    let firstPara = document.getElementById("firstPara")
    alert(firstPara.innerText)
}

function validate()
{
    let userName = document.getElementById("userName")
    let password = document.getElementById("password")

    // console.log(userName.value);
    // console.log(password.value);

    // if(userName.value=="Unni" && password.value == "Unni"){
    //     alert("Login Success")
    // }
    // else{
    //     alert("Login failed!")
    // }

    if (userName.value==password.value) 
        alert("Login Success")
    else 
        alert("Login failed!")
    
}

let result = ""
let num1=0, num2=0
function add(){
    num1 = parseInt(document.getElementById("num1").value)
    num2 = parseInt(document.getElementById("num2").value)

    result = "Sum = "+(num1+num2)

    let output = document.getElementById("output")
    output.innerText = result

}
function sub(){
    num1 = parseInt(document.getElementById("num1").value)
    num2 = parseInt(document.getElementById("num2").value)

    result = "Difference = "+(num1-num2)

    let output = document.getElementById("output")
    output.innerText = result

}
function mul(){
    num1 = parseInt(document.getElementById("num1").value)
    num2 = parseInt(document.getElementById("num2").value)

    result = "Product = "+(num1*num2)

    let output = document.getElementById("output")
    output.innerText = result

}
function div(){
    num1 = parseInt(document.getElementById("num1").value)
    num2 = parseInt(document.getElementById("num2").value)

    result = "Quotient = "+(num1/num2)

    let output = document.getElementById("output")
    output.innerText = result

}
function mod(){
    num1 = parseInt(document.getElementById("num1").value)
    num2 = parseInt(document.getElementById("num2").value)

    result = "Remainder = "+(num1%num2)

    let output = document.getElementById("output")
    output.innerText = result

}