let flag = 0

function changeDiv1(){
    let div1 = document.getElementsByClassName("myclass")[0]

    div1.innerHTML = `
        <ul>
            <li onclick="markCompleted(0)">Menu item1</li>
            <li onclick="markCompleted(1)">Menu item2</li>
            <li onclick="markCompleted(2)">Menu item3</li>
            <li onclick="markCompleted(3)">Menu item4</li>
        </ul>
    `

}

function changeDiv2(){
    let div1 = document.getElementsByClassName("myclass")[1]

    div1.innerHTML = `
        <ul>
            <li>Idly</li>
            <li>Dosa</li>
            <li>Channa</li>
            <li>Veg rice</li>
        </ul>
    `

}

function changeTheme(){
    let myStyle = document.all[6].style

    if(flag == 0){
        // document.all[6].style.backgroundColor="black"
        // document.all[6].style.color = "white"
        myStyle.backgroundColor = "black"
        myStyle.color = "white"
        myStyle.textDecoration = "none"
        flag = 1
    }
    else{
        // document.all[6].style.backgroundColor="white"
        // document.all[6].style.color = "black"
        
        myStyle.backgroundColor = "white"
        myStyle.color = "black"
        myStyle.fontWeight = "bold"
        myStyle.textDecoration = "underline"
        flag = 0
    }
}

function addAClass(){
    let container = document.getElementsByClassName("container")[0]
    container.classList.add("container-style1", "container-style2")
}

function removeBorderClass(){
    let container = document.getElementsByClassName("container")[0]
    container.classList.remove("container", "container-style2")
}

function markCompleted(index){
    index = parseInt(index)
    console.log(index);
    let div1 = document.getElementsByClassName("myclass")[0]
    div1.children[index].style.textDecoration = "line-through"
}