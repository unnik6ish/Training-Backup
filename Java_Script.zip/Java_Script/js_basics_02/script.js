var student1 = {
    "sid":12345,
    "sname":"Unni",
    "average":99.5,
    "section" : "A",
    "address":{
        "doorno":05,
        "street":"V V Kovil",
        "city":"Chennai",
        "pin":600125
        },
    "courses":[
            {
                "course_id":2000,
                "course_name":"Science",
                "dept":"Science"
            },
            {
                "course_id":2001,
                "course_name":"History",
                "dept":"Social Science"
            },
            {
                "course_id":2002,
                "course_name":"Science",
                "dept":"Science"
            },
            {
                "course_id":2003,
                "course_name":"Science",
                "dept":"Science"
            }
          ]

}
// for(i=0; i>(student1.courses.length); i++)
// {
    console.log(student1.courses[(student1.courses.length-1)])
// }
