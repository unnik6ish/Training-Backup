for(var counter = 1; counter <10; counter++)
{
    console.log(counter);
}

console.log("Loop Ended!");
console.log("***********************************");

let marks = [20, 30, 55, 67, 98, 102]

for(let counter=1; counter<=10;counter++)
{
    console.log(counter);
}
console.log("***********************************");

for(let index = 0; index<marks.length; index++)
{
    console.log(marks[index]);
}
console.log("***********************************");
for(let mark of marks)
{
    console.log(mark)
}
console.log("***********************************");