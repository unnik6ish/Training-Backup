let counter = 1

while(counter<=50)
{
    console.log(counter);
    counter++
    
}

// counter = 50
// while (counter>=0) 
// {
//     console.log(counter);
//     counter-=2
// }

// let userinput = 123456

// let sum = 0

// while (userinput>0) {
//     sum = sum + userinput % 10
//     userinput = parseInt(userinput / 10)
// }
// console.log(sum);


// while (userinput>0) {
//     sum = sum + userinput % 10
//     userinput = parseInt(userinput / 10)

// }
// console.log(sum);