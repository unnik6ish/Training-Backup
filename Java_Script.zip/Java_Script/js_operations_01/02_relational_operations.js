var bankBalance = 10000
var minimumBalance = 12000

console.log("Bank Balance is equal to minimum Balance "+(bankBalance == minimumBalance));
console.log("Bank Balance is not equal to minimum Balance "+(bankBalance != minimumBalance));
console.log("Bank Balance is less than minimum Balance "+(bankBalance < minimumBalance));
console.log("Bank Balance is greater than minimum Balance "+(bankBalance > minimumBalance));
console.log("Bank Balance is greater than or equal to minimum Balance "+(bankBalance >= minimumBalance));
console.log("Bank Balance is less than or equal to minimum Balance "+(bankBalance <= minimumBalance));