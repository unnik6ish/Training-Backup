var a = 56, b = 98, c = 76

//if (a>b){
//    
//    console.log("A is the biggest");
//
//}
//else
//{ 
//
//   console.log("B is the boggest");
//    
//}

if(a>b){
    if(a>c){
        console.log("A is the biggest");
    }
    else
    {
        console.log("C is the boggest");
    }
}
else{
    if(b>c){
        console.log("B is the biggest");
    }
    else{
        console.log("C is the boggest");
    }
}