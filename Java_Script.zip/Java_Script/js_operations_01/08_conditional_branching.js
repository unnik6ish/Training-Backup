var age = 16;

if(age>=18)
{
    console.log("you are eligible to vote");
}
else{
    console.log("you are not eligible to vote!!!");
}