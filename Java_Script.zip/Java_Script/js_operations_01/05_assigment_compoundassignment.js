var marks = 80

console.log(++marks);
console.log(marks);

var coins = 0
coins+=5
console.log("Coins = "+coins);

coins+=5
console.log("Coins = "+coins);

coins*=10
console.log("Coins = "+coins);

coins/=2
console.log("Coins = "+coins);

coins%=3
console.log("Coins = "+coins);