var empID = 12345
var empName = "Unnikrishnan"
var empAge = 27
var state = null
var qualified = true


console.log(empID)
console.log(empName)
console.log(empAge)
console.log(state)
console.log(qualified)