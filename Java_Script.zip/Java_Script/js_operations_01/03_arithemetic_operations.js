var num1 = 97, num2 = 5, result

result = num1+num2
console.log("Sum ="+result);

result = num1-num2
console.log("Difference ="+result);

result = num1*num2
console.log("Product ="+result);

result = num1/num2
console.log("Quotient ="+result);

result = num1%num2
console.log("Remainder ="+result);