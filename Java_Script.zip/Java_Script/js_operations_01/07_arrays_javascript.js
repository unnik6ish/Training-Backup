var marks =[12, 15, 75, 100, 150, 175]

var mixdArray = [143, "Unni", 3.14, true]

// You can also create an array, and then provide the elements:
var myDetails = [];
myDetails[0] = "Unnikrishnan";
myDetails[1] = "Software Engineer";
myDetails[3] = 12345;
myDetails[2] = "Kerala";

var cars = new Array("Saab", "Volvo", "BMW");
// changes the value of the first element in array cars
cars[0] = "TaTa"

// Looping Array Elements

const fruits = ["Banana", "Orange", "Apple", "Mango"];
let fLen = fruits.length;

let text = " ";
for (let i = 0; i < fLen; i++) {
  text += fruits[i] + '<br />';
}

console.log("Second Element in Array: "+marks[1]);
console.log("Second last Element in Array: "+marks[marks.length-2]);
console.log("Middle Element in Array: "+marks[Math.floor(marks.length/2)]);
console.log("Last Element in Array: "+marks[Math.floor(marks.length-1/2)]);

console.log(marks);
console.log(mixdArray);
console.log(myDetails);
console.log(cars);
console.log(text);