var employee = {
    "eid":123456,
    "ename":"Unnikrishnan",
    "country":"India",
    "salary":200000,
    "result":true,
}

console.log(employee);
// console.log("Employee ID = "+employee.eid);
// console.log("Employee Name = "+employee.ename);
console.log("Employee Country = "+employee.country);
console.log("Employee Salary = "+employee.salary);
console.log("Employee Result = "+employee.result);

console.log("Employee ID = "+employee["eid"]);
console.log("Employee Name = "+employee["ename"])