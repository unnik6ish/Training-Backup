var unit = 50, amount

if(unit>500)
    amount = unit*7
else if(unit>400)
     amount = unit*6
else if(unit>=300)
    amount = unit*5.5
else
     amount = unit*4.5

console.log("Amount to be paid = "+amount);

