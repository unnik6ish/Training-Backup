var a=10,b=20,c=30
console.log("A=10,B=20,C=30");


console.log("A is greater than B and A is greater than C : "+ ((a>b)&&(a>c)) );
console.log("B is greater than A and B is greater than C : "+ ((b>a)&&(b>c)) );
console.log("C is greater than A and C is greater than B : "+ ((c>a)&&(c>b)) );

console.log("A is greater than B or A is greater than C : "+ ((a>b)||(a>c)) );
console.log("B is greater than A or B is greater than C : "+ ((b>a)||(b>c)) );
console.log("C is greater than A or C is greater than B : "+ ((c>a)||(c>b)) );

console.log(!false);
console.log(!true);