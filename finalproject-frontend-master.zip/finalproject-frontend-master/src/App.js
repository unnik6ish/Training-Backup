import { Route, Routes } from 'react-router-dom';
import AboutPage from './Components/AboutPage/AboutPage';
import PrivateRoute from './Components/Auth/PrivateRoute';
import ContactPage from './Components/ContactPage/ContactPage';
import AdminDashboard from './Components/Dashboard/AdminDashboard';
import ApplicationTable from './Components/Dashboard/ApplicationTable';
import CustomerTable from './Components/Dashboard/CustomerTable';
import Dashboard from './Components/Dashboard/Dashboard';
import HomePage from './Components/HomePage/HomePage';
import LoanApplication from './Components/LoanApplication/LoanApplication';
import AdminLogin from './Components/Login/AdminLogin';
import Login from './Components/Login/Login';
import FailedMessage from './Components/Messages/FailedMessage';
import SuccessMessage from './Components/Messages/SuccessMessage';
import Registration from './Components/Registration/Registration';

function App() {
  return (
    <div>
      <Routes>
        <Route path='/' element={<HomePage />} />
        <Route path='/login' element={<Login />} />
        <Route path='/signup' element={<Registration />} />
        <Route path='/adminlogin' element={<AdminLogin />} />
        <Route path='/admindashboard' element={<AdminDashboard />} />
        <Route path='/cusDetails' element={<CustomerTable />} />
        <Route path='/dashboard' element={<Dashboard />} />
        <Route path='/contactus' element={<ContactPage />} />
        <Route path='/aboutus' element={<AboutPage />} />
        <Route element={<PrivateRoute />} >
          <Route path='/loanapplication' element={<LoanApplication />} />
          <Route path='/failed' element={<FailedMessage />} />
          <Route path='/success' element={<SuccessMessage />} />
          <Route path='/applicationtable' element={<ApplicationTable />} />
        </Route>
      </Routes>
    </div>
  );
}

export default App;
