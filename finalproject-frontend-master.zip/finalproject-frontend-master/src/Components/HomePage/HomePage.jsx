import React from 'react'
import Footer from '../Footer/Footer'
import HomeBodyPart1 from '../HomeBody/HomeBodyPart1'
import HomeBodyPart2 from '../HomeBody/HomeBodyPart2'
import HomeBodyPart3 from '../HomeBody/HomeBodyPart3'
import HomeBodyPart4 from '../HomeBody/HomeBodyPart4'
import NavBar from '../NavBar/NavBar'
const HomePage = () => {

    return (
        <div>
            <NavBar />
            <HomeBodyPart1 />
            <HomeBodyPart2 />
            <HomeBodyPart3 />
            <HomeBodyPart4 />
            <Footer />
        </div>
    )
}

export default HomePage