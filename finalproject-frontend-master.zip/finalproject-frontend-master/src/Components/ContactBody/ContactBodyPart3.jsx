import React from 'react'
import { Col, Container, Row } from 'react-bootstrap'

const ContactBodyPart3 = () => {
    return (
        <div style={{backgroundColor:"#5a287d"}}>
            <Container class='container'>
                <Row>
                    <Col sm={6}>
                        <h1 class='heading1'style={{color:"white"}}>More information</h1>
                        <ul>
                            <li style={{padding:"10px", color:"white"}}><a class='h1link' href='#!' style={{color:"white"}}>Supplying goods & services</a></li>
                            <li style={{padding:"10px", color:"white"}}><a class='h1link' href='#!' style={{color:"white"}}>How to complain</a></li>
                            <li style={{padding:"10px", color:"white"}}><a class='h1link' href='#!' style={{color:"white"}}>FAQs</a></li>
                        </ul>
                    </Col>
                </Row>
            </Container>
        </div>
    )
}

export default ContactBodyPart3