import React from 'react'
import { Col, Container, Row } from 'react-bootstrap'
import '../HomeBody/HomeBodyPart1.css'
import contactImg1 from '../../images/contactImg1.jpg'
import contactImg2 from '../../images/contactImg2.jpg'

const ContactBodyPart1 = () => {
    return (
        <div style={{ backgroundColor: '#f4f0e8' }}>
            <Container class='container'>
                <Row>
                    <Col style={{ backgroundColor: 'white' }} sm={8}>
                        <div>
                            <h1 class='heading1'>Contact Us</h1>
                            <p class='para1'>We’re here to help – get in touch with us using the contact details below.</p>
                        </div>
                    </Col>
                    <Col sm={4}><img
                        className="d-block w-100"
                        src={contactImg1}
                        alt='contact1'
                    /></Col>
                </Row>
                <Row>
                    <Col sm={8}>
                        <img
                            className="d-block w-100"
                            src={contactImg2}
                            alt='home2'
                        />
                    </Col>
                    <Col style={{ backgroundColor: 'white' }} sm={4}></Col>
                </Row>
            </Container>
        </div>
    )
}

export default ContactBodyPart1