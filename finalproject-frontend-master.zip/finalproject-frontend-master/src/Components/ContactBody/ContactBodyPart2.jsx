import React from 'react'
import { Col, Container, Row } from 'react-bootstrap'
import '../HomeBody/HomeBodyPart2.css'
import contactImg3 from '../../images/contactImg3.jpg'

const ContactBodyPart2 = () => {
    return (
        <div>
            <Container class='container'>
                <Row>
                    <Col sm={6}>
                        <img
                            className="d-block w-100"
                            src={contactImg3}
                            alt='contact3' />
                    </Col>
                    <Col sm={6}>
                        <h1 title='Header1' class='heading1' style={{padding:"10px"}}>Get in touch</h1>
                        <ul>
                            <li style={{padding:"10px"}}><a class='h1link' href='#!'>Customer contacts</a></li>
                            <li style={{padding:"10px"}}><a class='h1link' href='#!'>Investor contacts</a></li>
                            <li style={{padding:"10px"}}><a class='h1link' href='#!'>Media contacts</a></li>
                            <li style={{padding:"10px"}}><a class='h1link' href='#!'>Sustainable banking contacts</a></li>
                        </ul>
                    </Col>
                </Row>
            </Container>
        </div>
    )
}

export default ContactBodyPart2