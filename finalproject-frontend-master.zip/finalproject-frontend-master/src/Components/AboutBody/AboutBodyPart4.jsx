import React from 'react'
import { Col, Container, Row } from 'react-bootstrap'
import '../HomeBody/HomeBodyPart2.css'
import aboutImg5 from '../../images/aboutImg5.jpg'

const AboutBodyPart4 = () => {
    return (
        <div style={{ backgroundColor: '#f4f0e8' }}>
            <Container class='container'>
                <Row>
                    <Col sm={6}>
                        <h1 title='Header1' class='heading1'>Our history</h1>
                        <p data-testid="para" class='para1'>Our history in Britain goes back for hundreds of years. NatWest Group has grown out of 200 individual businesses. As we look to the future, we build on strong foundations to meet new challenges. Each day, we work hard to build a stronger tomorrow.</p>
                        <a class='h1link' href='#!'>Read our story</a>
                    </Col>
                    <Col sm={6}>
                        <img
                            className="d-block w-100"
                            src={aboutImg5}
                            alt='home1' />
                    </Col>
                </Row>
            </Container>
        </div>
    )
}

export default AboutBodyPart4