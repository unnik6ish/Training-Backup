import React from 'react'
import { Col, Container, Row } from 'react-bootstrap'
import aboutImg3 from '../../images/aboutImg3.jpg'

const AboutBodyPart2 = () => {
    return (
        <div style={{backgroundColor:"#5a287d"}}>
            <Container class='container'>
                <Row>
                    <Col sm={6}>
                        <h1 class='heading1'style={{color:"white"}}>About NatWest Group</h1>
                        <p  class='para1' style={{color:"white"}}>NatWest Group is a relationship bank for a digital world. We champion potential; breaking down barriers and building financial confidence so the 19 million people, families and businesses we serve in communities throughout the UK and Ireland can rebuild and thrive. If our customers succeed, so will we.</p>
                        <a class='h1link' href='#!' style={{color:"white"}}>Learn more about NatWest Group</a>
                    </Col>
                    <Col sm={6}>
                        <img
                            className="d-block w-100"
                            src={aboutImg3}
                            alt='home1' />
                    </Col>
                </Row>
            </Container>
        </div>
    )
}

export default AboutBodyPart2