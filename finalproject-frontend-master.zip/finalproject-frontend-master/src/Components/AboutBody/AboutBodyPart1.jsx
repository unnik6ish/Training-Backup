import React from 'react'
import { Col, Container, Row } from 'react-bootstrap'
import '../HomeBody/HomeBodyPart1.css'
import aboutImg1 from '../../images/aboutImg1.jpg'
import aboutImg2 from '../../images/aboutImg2.jpg'

const AboutBodyPart1 = () => {
    return (
        <div style={{ backgroundColor: '#f4f0e8' }}>
            <Container class='container'>
                <Row>
                    <Col style={{ backgroundColor: 'white' }} sm={8}>
                        <div>
                            <h1 class='heading1'>At a glance</h1>
                            <p class='para1'>We champion potential, helping people, families and businesses to thrive.</p>
                        </div>
                    </Col>
                    <Col sm={4}><img
                        className="d-block w-100"
                        src={aboutImg1}
                        alt='contact1'
                    /></Col>
                </Row>
                <Row>
                    <Col sm={8}>
                        <img
                            className="d-block w-100"
                            src={aboutImg2}
                            alt='home2'
                        />
                    </Col>
                    <Col style={{ backgroundColor: 'white' }} sm={4}></Col>
                </Row>
            </Container>
        </div>
    )
}

export default AboutBodyPart1