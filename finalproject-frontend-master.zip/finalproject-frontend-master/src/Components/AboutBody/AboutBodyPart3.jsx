import React from 'react'
import { Col, Container, Row } from 'react-bootstrap'
import '../HomeBody/HomeBodyPart2.css'
import aboutImg4 from '../../images/aboutImg4.jpg'

const AboutBodyPart3 = () => {
    return (
        <div>
            <Container class='container'>
                <Row>
                    <Col sm={6}>
                        <img
                            className="d-block w-100"
                            src={aboutImg4}
                            alt='home1' />
                    </Col>
                    <Col sm={6}>
                        <h1 title='Header1' class='heading1'>Our values</h1>
                        <p data-testid="para" class='para1'>Our values guide and inspire us through everything we do. Find out more about them.</p>
                        <a class='h1link' href='#!'>Go to Our values</a>
                    </Col>
                </Row>
            </Container>
        </div>
    )
}

export default AboutBodyPart3