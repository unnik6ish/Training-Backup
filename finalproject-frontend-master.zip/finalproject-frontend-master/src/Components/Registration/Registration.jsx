import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Button, Col, Container, FloatingLabel, Form, Row } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { toast, ToastContainer } from 'react-toastify';
import "react-toastify/dist/ReactToastify.css";
import Footer from '../Footer/Footer';
import NavbarForOther from '../NavBar/NavbarForOther';
import './Registration.css'

const Registration = () => {
  // Getting all the userinputs as a variable    

  const [name, setName] = useState(``);
  const [email, setEmail] = useState(``);
  const [mobNo, setMobNo] = useState(``);
  const [accno, setAccno] = useState(``);
  const [address, setAddress] = useState(``);
  const [password, setPassword] = useState(``);


  const [emailError, setEmailError] = useState(``);
  const [usernameError, setUsernameError] = useState(``);
  const [addressError, setAddressError] = useState(``);
  const [accNoError, setAccNoError] = useState(``);
  const [mobNoError, setMobNoError] = useState(``);
  const [passwordError, setPasswordError] = useState(``);

  const navigate = useNavigate();

  var [loanUsers, setLoanUsers] = useState([]);

  var name_exists;
  var email_exist;

  //Regex Variable to compare
  var regExEmail = /^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,3}$/
  var regexUsername = /[A-Za-z0-9]{3,30}/
  var regexName = /[A-Za-z]{3,30}/
  var regex10digits = /^[0-9]\d{09}$/ // to validate phone no 
  var regexAddress = /^[a-zA-Z0-9(?:_*.\-\\,\s)?]{10,100}$/
  var regExPwd = /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#%^&])(?!.* ).{8,20}$/

  //setting up base url for request
  const api = axios.create({
    baseURL: `http://localhost:8080/loanusers`
  })

  useEffect(() => {

    api.get(`http://localhost:8080/loanusers`)
      .then(res => setLoanUsers(res.data))
      .catch(err => console.log(err))

  })


  for (let i = 0; i < loanUsers.length; i++) {
    if (email === loanUsers[i].id) {

      email_exist = true
    }

  }

  for (let i = 0; i < loanUsers.length; i++) {
    if (name === loanUsers[i].name) {

      name_exists = true
    }

  }

  const SignUp = (event) => {
    event.preventDefault()

    if (!regexUsername.test(name)) {
      setUsernameError(`Userame length must be between 3 -20 characters, use only alphabets. numbers & special charaters not allowed`)
    }

    else if (name_exists) {
      alert(`Username already exist. Please use a different a username to continue`)
    }

    else if (!regexName.test(name)) {
      alert(`Please enter a valid name use only alphabets`)

    }

    else if (!regexAddress.test(address)) {
      setAddressError(`Address length must be between 10 -100 characters`)
    }
    else if (!regex10digits.test(accno)) {
      setAccNoError(`Please enter a valid 10 digit account number`)
    }
    else if (!regExEmail.test(email)) {
      setEmailError(`Please enter a valid email id`)

    }
    else if (email_exist) {
      alert(`Email ID already exist. Please use a different email id to continue or Login`)
    }
    else if (!regex10digits.test(mobNo)) {
      setMobNoError(`Please Enter a valid 10 digit mobile number`)
    }

    else if (!regExPwd.test(password)) {

      setPasswordError(`Please create a strong password`)
    }

    else {

      var newUser = {
        "id": email,
        "name": name,
        "mobno": mobNo,
        "accno": accno,
        "address": address,
        "password": password
      }

      axios.post(`http://localhost:8080/loanusers`, newUser)
        .then((response) => {
          console.log(response.data)
          var userDetails = response.data;
          delete userDetails.password;
          localStorage.setItem('loggedDetails', JSON.stringify(userDetails));
        })
        .catch(err => console.log(err))

      setTimeout(() => {
        navigate("/login")
      }, 2000);

      toast.success("Successfully Signed in, Redirecting to Login", {
        position: 'top-center'
      });

    }

  }

  return (
    <div>
      <ToastContainer />
      <NavbarForOther />
      <div className='properties'>
        <Container fluid>
          <Row className="pt-5 rounded">
            <Col lg={4} md={6} sm={9} className="p-4 m-auto shadow-lg rounded-lg Col">
              <Form className='form' autoComplete="off">
                <h3 className='text-center mb-2'>Registration</h3>
                <FloatingLabel
                  controlId="floatingInput" label="Name" className="mb-3">
                  <Form.Control type="text" placeholder="Name" autoComplete='off'
                    onChange={(e) => {
                      setName(e.target.value);
                      setUsernameError(``)
                    }}
                    isInvalid={!!usernameError}
                    required={true}
                  />
                  <Form.Control.Feedback type='invalid'>
                    {usernameError}
                  </Form.Control.Feedback>

                </FloatingLabel>
                <FloatingLabel controlId="floatingInput" label="Address" className="mb-3">
                  <Form.Control type="text" placeholder="Address"
                    onChange={(e) => {
                      setAddress(e.target.value);
                      setAddressError(``)
                    }}
                    isInvalid={!!addressError}

                    required={true} />
                  <Form.Control.Feedback type='invalid'>
                    {addressError}
                  </Form.Control.Feedback>
                </FloatingLabel>

                <FloatingLabel
                  controlId="floatingInput" label="Account No" className="mb-3">
                  <Form.Control type="number" placeholder="Account N0" required
                    onChange={(e) => {
                      setAccno(e.target.value);
                      setAccNoError(``)
                    }}
                    isInvalid={!!accNoError}
                  />
                  <Form.Control.Feedback type='invalid'>
                    {accNoError}
                  </Form.Control.Feedback>

                </FloatingLabel>
                <FloatingLabel
                  controlId="floatingInput" label="Email address" className="mb-3">
                  <Form.Control type="email" placeholder="name@example.com" required
                    onChange={(e) => {
                      setEmail(e.target.value);
                      setEmailError(``)
                    }}
                    isInvalid={!!emailError}
                  />
                  <Form.Control.Feedback type='invalid'>
                    {emailError}
                  </Form.Control.Feedback>

                </FloatingLabel>
                <FloatingLabel
                  controlId="floatingInput" label="Phone Number">
                  <Form.Control type="number" placeholder="Phone Number" required
                    onChange={(e) => {
                      setMobNo(e.target.value);
                      setMobNoError(``)
                    }}
                    isInvalid={!!mobNoError}
                  />
                  <Form.Control.Feedback type='invalid'>
                    {mobNoError}
                  </Form.Control.Feedback>

                  <br></br>
                </FloatingLabel>
                <FloatingLabel controlId="floatingPassword" label="Password" className='mb-2'>
                  <Form.Control type="password" placeholder="Password" required
                    onChange={(e) => {
                      setPassword(e.target.value);
                      setPasswordError(``)

                    }}
                    isInvalid={!!passwordError}

                  />
                  <Form.Control.Feedback type='invalid'>
                    {passwordError}
                  </Form.Control.Feedback>

                </FloatingLabel>
                <Button style={{ backgroundColor: "#5B1F8E", borderColor: "#5B1F8E" }} className='Button btn-block' type='submit' onClick={SignUp} >Sign Up</Button>
                <Button style={{ backgroundColor: "#5B1F8E", borderColor: "#5B1F8E" }} className='Button' type='reset'>Reset</Button>
              </Form>
            </Col>
          </Row>
        </Container>
      </div>
      <Footer />
    </div>
  )
}

export default Registration