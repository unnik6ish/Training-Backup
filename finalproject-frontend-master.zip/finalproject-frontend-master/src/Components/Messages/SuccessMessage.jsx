import React from 'react'
import { Alert, Button, Container } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

const SuccessMessage = () => {

  const navigate = useNavigate();

  const loanappno = JSON.parse(localStorage.getItem("loanappno"))

  const routeToDashboard = (event) => {

    event.preventDefault()

    navigate('/dashboard')

  }


  return (
    <div>
      <Container>
        <Alert variant="success">
          <Alert.Heading>Congratulation! You have successfully submitted your loan application</Alert.Heading>
          <p>
            Your application number : {loanappno}
          </p>
          <p>
            Your request is pending for final approval and for any update please track it in your dashboard.
          </p>
          <hr />
          <div className="d-flex justify-content-end">
            <Button onClick={routeToDashboard} variant="outline-success">
              Close
            </Button>
          </div>
        </Alert>
      </Container>
    </div>
  )
}

export default SuccessMessage