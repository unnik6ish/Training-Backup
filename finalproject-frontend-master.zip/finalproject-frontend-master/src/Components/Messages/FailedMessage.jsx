import React from 'react'
import { Alert, Button, Container } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

const FailedMessage = () => {

  const navigate = useNavigate();

  const routeToDashboard = (event) => {

    event.preventDefault()

    navigate('/dashboard')

  }

  return (
    <div>
      <Container>
        <Alert variant="danger">
          <Alert.Heading>You have closed your loan application, please retry!</Alert.Heading>
          <p>
            Please fill all the necessary details and submit your application.
          </p>
          <hr />
          <div className="d-flex justify-content-end">
            <Button variant="outline-danger" onClick={routeToDashboard}>
              Close!
            </Button>
          </div>
        </Alert>
      </Container>
    </div>
  )
}

export default FailedMessage