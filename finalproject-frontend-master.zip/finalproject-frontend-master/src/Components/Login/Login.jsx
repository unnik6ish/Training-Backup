import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Button, Col, FloatingLabel, Form, Row } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import bcrypt from 'bcryptjs';
import './Login.css'
import Footer from '../Footer/Footer';
import NavbarForOther from '../NavBar/NavbarForOther';
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";


const Login = () => {

    const [email, setEmail] = useState(``);
    const [password, setPassword] = useState(``);
    const [userDetails, setUserDetails] = useState([]);

    const [emailError, setEmailError] = useState(``)
    const [passwordError, setPasswordError] = useState(``)

    var emailid_exists = false;
    var db_encryptedpwd = ``;
    var loginValidationStatus = false;

    const api = axios.create({
        baseURL: `http://localhost:8080`
    })

    useEffect(() => {

        axios.get(`http://localhost:8080/loanusers`)
            .then(res => setUserDetails(res.data))
            .catch(err => console.log(err))

    })
    for (let i = 0; i < userDetails.length; i++) {
        if (email.toLowerCase() === (userDetails[i].id).toLowerCase()) {

            db_encryptedpwd = userDetails[i].password;
            emailid_exists = true
        }
    }

    async function LoginCheck(event) {

        event.preventDefault();

        loginValidationStatus = await bcrypt.compare(password, db_encryptedpwd)

        if (email === "" || password === "") {

            toast.error("Please fill all the details",{
                position:'top-center',
                autoClose:1000
            })

        }
        else if (!emailid_exists) {
            setEmailError(`Email id doesn't exist. Please Sign Up`)
        }
        else if (!loginValidationStatus) {
            setPasswordError(`Password doesnt match our records`)

        }
        else if (loginValidationStatus) {

            let credentials = {

                "emailid": email,
                "password": password
            }

            api.post(`/login`, credentials)
                .then((response) => {
                    console.log(response.data.jwtToken)
                    var token = response.data.jwtToken;
                    localStorage.setItem('Token', token);
                })
                .catch(err => console.log(err))

            api.get(`/loanusers/${email}`)
                .then(res => {
                    console.log(res)
                    localStorage.setItem('loggedUser', JSON.stringify(res.data))
                })

            setTimeout(() => {
                navigate("/dashboard")
            }, 1000);

            toast.success("Successfully Loggedin",{
                position: 'top-center'
            });

        }
    }

    const navigate = useNavigate();

    return (
        <div>
            <ToastContainer />
            <NavbarForOther />
            <div class='properties'>
                <div className='container-fluid p-5'>
                    <Row className="mt-5 mb-5 pt-4 " >
                        <Col lg={4} md={6} sm={9} className="p-4 m-auto shadow-lg rounded-lg Col">
                            <Form autoComplete="off">
                                <h4 className='text-center'>Login</h4>
                                <h6 className='mb-3 text-center '>Please enter your credentials</h6>
                                <FloatingLabel controlId="floatingInput" label="Email" className="mb-3" autoComplete="off" >
                                    <Form.Control type="text" placeholder="Email"
                                        onChange={(e) => {
                                            setEmail(e.target.value);
                                            setEmailError(``)
                                        }}
                                        isInvalid={!!emailError}

                                    />

                                    <Form.Control.Feedback type='invalid'>
                                        {emailError}
                                    </Form.Control.Feedback>
                                    <Form.Text className="text-muted">
                                        Please enter your registered email address
                                    </Form.Text>
                                </FloatingLabel>

                                <FloatingLabel controlId="floatingPassword" label="Password" className="mb-3" autoComplete="off" >
                                    <Form.Control type="password" placeholder="Password"

                                        onChange={(e) => {
                                            setPassword(e.target.value)
                                            setPasswordError(``)
                                        }}
                                        isInvalid={!!passwordError}
                                    />

                                    <Form.Control.Feedback type='invalid'>
                                        {passwordError}
                                    </Form.Control.Feedback>
                                    <Form.Text className="text-muted">
                                        Please enter your password
                                    </Form.Text>
                                </FloatingLabel>
                                <div className='text-center span2'>
                                    <Button type='submit' className='Button' onClick={LoginCheck} style={{ backgroundColor: "#5B1F8E", borderColor: "#5B1F8E" }}>Login</Button>
                                    <Button type='reset' className='Button' style={{ backgroundColor: "#5B1F8E", borderColor: "#5B1F8E" }}>Reset</Button>
                                </div>
                            </Form>
                        </Col>
                    </Row>

                </div>
            </div>
            <Footer />
        </div>
    )
}

export default Login