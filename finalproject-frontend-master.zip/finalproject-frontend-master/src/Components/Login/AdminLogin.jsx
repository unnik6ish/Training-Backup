import React, { useState } from 'react'
import { Button, Col, FloatingLabel, Form, Row } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom';
import { toast, ToastContainer } from 'react-toastify';
import Footer from '../Footer/Footer';
import NavBarForAdminLogin from '../NavBar/NavBarForAdminLogin';
import './Login.css'
import "react-toastify/dist/ReactToastify.css";

const AdminLogin = () => {

    const navigate = useNavigate();

    const [username, setUsername] = useState(``);
    const [password, setPassword] = useState(``);

    const AdminLogin = () => {

        if (username === "Admin" && password === "Password") {
            
            setTimeout(() => {
                navigate("/admindashboard")
            }, 1000);

            toast.success("Successfully Loggedin",{
                position: 'top-center'
            });
        }
        else {
            toast.error("Please fill all the details or check username and password",{
                position:'top-center',
                autoClose:1000
            })
        }
    }

    return (
        <div>
            <ToastContainer />
            <NavBarForAdminLogin/>
            <div className='container-fluid p-5 properties'>
                <Row className="mt-5 mb-5 pt-4 " >
                    <Col lg={4} md={6} sm={9} className="p-4 m-auto shadow-lg rounded-lg Col">
                        <Form autoComplete="off">
                            <h4 className='text-center'>Admin Login</h4>
                            <h6 className='mb-3 text-center '>Please enter your credentials</h6>
                            <FloatingLabel controlId="floatingInput" label="Username" className="mb-3" autoComplete="off" >
                                <Form.Control type="text" placeholder="Username" onChange={(e) => {
                                    setUsername(e.target.value)
                                }} />
                                <Form.Text className="text-muted">
                                    Please enter the user name
                                </Form.Text>
                            </FloatingLabel>

                            <FloatingLabel controlId="floatingPassword" label="Password" className="mb-3" autoComplete="off" >
                                <Form.Control type="password" placeholder="Password" onChange={(e) => { setPassword(e.target.value) }} />
                                <Form.Text className="text-muted">
                                    Please enter your password
                                </Form.Text>
                            </FloatingLabel>
                            <div className='text-center span2'>
                                <Button className='Button' style={{backgroundColor:"#5B1F8E", borderColor:"#5B1F8E"}} onClick={AdminLogin}>Login</Button>
                                <Button className='Button' style={{backgroundColor:"#5B1F8E", borderColor:"#5B1F8E"}}>Reset</Button>
                            </div>
                        </Form>
                    </Col>
                </Row>
            </div>
            <Footer />
        </div>
    )
}

export default AdminLogin