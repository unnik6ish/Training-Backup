import React from 'react'
import AboutBodyPart1 from '../AboutBody/AboutBodyPart1'
import AboutBodyPart2 from '../AboutBody/AboutBodyPart2'
import AboutBodyPart3 from '../AboutBody/AboutBodyPart3'
import AboutBodyPart4 from '../AboutBody/AboutBodyPart4'
import NavbarForContact from '../ContactPage/NavbarForContact'
import Footer from '../Footer/Footer'

const AboutPage = () => {
    return (
        <div>
            <NavbarForContact />
            <AboutBodyPart1 />
            <AboutBodyPart2 />
            <AboutBodyPart3 />
            <AboutBodyPart4 />
            <Footer />
        </div>
    )
}

export default AboutPage