import axios from 'axios';
import React, { useState } from 'react'
import { Button, Col, Container, Form, FormControl, Row } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom';
import { toast, ToastContainer } from 'react-toastify';
import FooterForDash from '../Footer/FooterForDash';
import NavForLoanApp from './NavForLoanApp';
import "react-toastify/dist/ReactToastify.css";
// import '../Registration/Registration.css'

const LoanApplication = () => {

    let loggedUser = JSON.parse(localStorage.getItem('loggedUser'))

    const navigate = useNavigate();

    const [employment, setEmployment] = useState(``);
    const [business, setBusiness] = useState(``);
    const [experience, setExperience] = useState(``);
    const [income, setIncome] = useState(0);
    const [creditscore, setCreditScore] = useState(0);
    const [car, setCar] = useState(``);
    const [amount, setAmount] = useState(0);
    const [tenure, setTenure] = useState(``);

    // const [companyError, setCompanyError] = useState(``);
    // const [incomeError, setIncomeError] = useState(``);
    // const [creditsError, setCreditsError] = useState(``);
    // const [modelError, setModelError] = useState(``);
    // const [amountError, setAmountError] = useState(``);

    // var regexCompanyName = /^[a-zA-Z0-9(?:_*.\-\\,\s)?]{3,100}$/ // to validate company name
    // var regexIncome = /^[0-9]\d{09}$/ // to validate income
    // var regexCreditScore = /^[0-9]\d{02}$/ // to validate credit score
    // var regexCarModel = /^[a-zA-Z0-9(?:_*.\-\\,\s)?]{3,100}$/ // to validate car model
    // var regexLoanAmount = /^[0-9]\d{09}$/ // to validate loan amount

    const appSubmit = (event) => {
        event.preventDefault()

        // if (!regexCompanyName.test(business)) {
        //     setCompanyError(`Business/Company name must be between 3-100 characters`)
        // }
        // else if (!regexIncome.test(income)) {
        //     setIncomeError(`Please enter a valid income`)
        // }
        // else if (!regexCreditScore.test(creditscore)) {
        //     setCreditsError(`Please enter a valid credit score it must 3 digits`)
        // }
        // else if (!regexCarModel.test(car)) {
        //     setModelError(`Car model/name must be more that 3 charactors`)
        // }
        // else if (!regexLoanAmount.test(amount)) {
        //     setAmountError(`Please enter a valid loan amount`)
        // }
        // else {

            var loanDetails = {
                "employment": employment,
                "business": business,
                "experience": experience,
                "income": income,
                "creditscore": creditscore,
                "carmodel": car,
                "amount": amount,
                "tenure": tenure,
                "status": "Pending",
                "accno": loggedUser.accno
            }

            axios.post(`http://localhost:8080/loandetails`, loanDetails)
                .then(response => {
                    console.log(response)
                    console.log(response.data.loanappno);
                    localStorage.setItem("loanappno", JSON.stringify(response.data.loanappno))
                })
                .catch(err => console.log(err))


            setTimeout(() => {
                navigate("/success")
            }, 3000);

            toast.success("Loan application submitted successfully", {
                position: 'top-center'
            });



        // }
    }


    return (
        <div>
            <ToastContainer />
            <NavForLoanApp />
            <Container fluid style={{ backgroundColor: '#f4f0e8' }}>
                <Row className="pt-5 pb-5 rounded">
                    <Col lg={7} md={6} sm={9} className="p-4 m-auto shadow-lg rounded-lg Col">
                        <Form>
                            <h3 className='text-center p-3'>Loan Application</h3>
                            <Row className="g-2 mb-3">
                                <Col md>
                                    <Form.Label>Name</Form.Label>
                                    <Form.Control type="text" placeholder={loggedUser.name} disabled readOnly />
                                </Col>
                                <Col md>
                                    <Form.Label>Email</Form.Label>
                                    <Form.Control type="email" placeholder={loggedUser.id} disabled readOnly />
                                </Col>
                            </Row>
                            <Row className="g-2 mb-3">
                                <Col md>
                                    <Form.Label>Address</Form.Label>
                                    <Form.Control type="text" placeholder={loggedUser.address} disabled readOnly />
                                </Col>
                                <Col md>
                                    <Form.Label>Mobile No</Form.Label>
                                    <Form.Control type="number" placeholder={loggedUser.mobno} disabled readOnly />
                                </Col>
                            </Row>

                            <Row className="g-2 mb-3">
                                <Col md>
                                    <Form.Label>Type of employment</Form.Label>
                                    <Form.Select aria-label="Default select example" onChange={(e) => setEmployment(e.target.value)} >
                                        <option>Select</option>
                                        <option value="Salaried">Salaried</option>
                                        <option value="Self Employed">Self Employed</option>
                                    </Form.Select>

                                </Col>
                                <Col md>
                                    <Form.Label>Company/Business Name</Form.Label>
                                    <Form.Control type="text"
                                        placeholder="Company/Business Name"
                                        onChange={(e) =>{
                                            setBusiness(e.target.value)
                                            // setCompanyError(``) 
                                        }}/>
                                    {/* // isInvalid={!!companyError}
                                    // required={true} */}
                                    {/* <FormControl.Feedback type='invalid'>
                                        {companyError}
                                    </FormControl.Feedback> */}
                                    
                                </Col>
                            </Row>

                            <Row className="g-2 mb-3">
                                <Col md>
                                    <Form.Label>Total work experience</Form.Label>
                                    <Form.Select aria-label="Default select example" onChange={(e) => setExperience(e.target.value)}>
                                        <option>Select</option>
                                        <option value="0-5 Years">0-5 Years</option>
                                        <option value="5-10 Years">5-10 Years</option>
                                        <option value="above 10 Years">above 10 Years</option>
                                        <option value="Not Applicable - Self Employed">Not Applicable - Self Employed</option>
                                    </Form.Select>

                                </Col>
                                <Col md>
                                    <Form.Label>Annual Income</Form.Label>
                                    <Form.Control type="number" onWheel={() => document.activeElement.blur()} placeholder="Annual Income" onChange={(e) => setIncome(e.target.value)} />
                                </Col>
                            </Row>

                            <Row className="g-2 mb-3">
                                <Col md>
                                    <Form.Label>Credit Score</Form.Label>
                                    <Form.Control type="number" onWheel={() => document.activeElement.blur()} placeholder="Credit Score" onChange={(e) => setCreditScore(e.target.value)} />
                                </Col>
                                <Col md>
                                    <Form.Label>Model/Name of the Car</Form.Label>
                                    <Form.Control type="text" placeholder="Model/Name of the Car" onChange={(e) => setCar(e.target.value)} required />
                                </Col>
                            </Row>

                            <Row className="g-2 mb-3">
                                <Col md>
                                    <Form.Label>Required loan amount</Form.Label>
                                    <Form.Control type="number" onWheel={() => document.activeElement.blur()} placeholder="Loan amount" onChange={(e) => setAmount(e.target.value)} required />
                                </Col>
                                <Col md>
                                    <Form.Label>Tenure in Years</Form.Label>
                                    <Form.Select aria-label="Default select example" onChange={(e) => setTenure(e.target.value)} required>
                                        <option>Select</option>
                                        <option value="1 year">1</option>
                                        <option value="2 year">2</option>
                                        <option value="3 year">3</option>
                                        <option value="4 year">4</option>
                                        <option value="5 year">5</option>
                                    </Form.Select>
                                </Col>
                            </Row>


                            <div className='pt-3 col text-center'>
                                <Button style={{ backgroundColor: "#401664", borderColor: "#401664", width: "30%" }} type="submit" onClick={appSubmit}>
                                    Submit
                                </Button>
                                <Button className='m-2 btn' style={{ backgroundColor: "#401664", borderColor: "#401664", width: "30%" }} type="reset">
                                    Reset
                                </Button>
                                <Button style={{ backgroundColor: "#401664", borderColor: "#401664", width: "30%" }} type="cancel" onClick={() => navigate('/failed')}>
                                    Cancel
                                </Button>
                            </div>
                        </Form>
                    </Col>
                </Row>
            </Container>
            <FooterForDash />
        </div>
    )
}

export default LoanApplication