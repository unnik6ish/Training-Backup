import React from 'react'
import { Col, Container, Row } from 'react-bootstrap'
import './HomeBodyPart2.css'
import homeImg4 from '../../images/homeImg4.png'

const HomeBodyPart3 = () => {
    return (
        <div style={{ backgroundColor: '#f4f0e8' }}>
            <Container class='container'>
                <Row>
                    <Col sm={6}>
                        <img
                            className="d-block w-100"
                            src={homeImg4}
                            alt='home1' />
                    </Col>
                    <Col sm={6}>
                        <h1 title='Header1' class='heading1'>Our commitments to racial equality – two years on</h1>
                        <p data-testid="para" class='para1'>Take a look at progress made on our commitments for our colleagues, customers and communities.</p>
                        <a class='h1link' href='#!'>Find out more and read our report</a>
                    </Col>
                </Row>
            </Container>
        </div>
    )
}

export default HomeBodyPart3