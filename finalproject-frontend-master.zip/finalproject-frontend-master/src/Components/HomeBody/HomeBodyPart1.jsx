import React from 'react'
import { Col, Container, Row } from 'react-bootstrap'
import './HomeBodyPart1.css'
import homeImg1 from '../../images/homeImg1.jpg'
import homeImg2 from '../../images/homeImg2.jpg'

const HomeBodyPart1 = () => {
    return (
        <div style={{ backgroundColor: '#f4f0e8' }}>
            <Container class='container'>
                <Row>
                    <Col style={{ backgroundColor: 'white' }} sm={8}>
                        <div>
                            <h1 title='Header1' class='heading1'>Welcome to our Online Services</h1>
                            <h1 class='heading1'>Thank you for choosing us</h1>
                            <h1 class='heading2'>Who we are</h1>
                            <p data-testid="para" class='para1'>NatWest Group is a relationship bank for a digital world. We champion potential; breaking down barriers and building financial confidence so the 19 million people, families and businesses we serve in communities throughout the UK and Ireland can rebuild and thrive. If our customers succeed, so will we.</p>
                        </div>
                    </Col>
                    <Col sm={4}><img
                        className="d-block w-100"
                        src={homeImg2}
                        alt='home1'
                    /></Col>
                </Row>
                <Row>
                    <Col sm={8}>
                        <img
                            className="d-block w-100"
                            src={homeImg1}
                            alt='home2'
                        />
                    </Col>
                    <Col style={{ backgroundColor: 'white' }} sm={4}></Col>
                </Row>
            </Container>
        </div>
    )
}

export default HomeBodyPart1