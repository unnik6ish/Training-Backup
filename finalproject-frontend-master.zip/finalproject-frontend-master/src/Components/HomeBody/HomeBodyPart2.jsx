import React from 'react'
import { Col, Container, Row } from 'react-bootstrap'
import './HomeBodyPart2.css'
import homeImg3 from '../../images/homeImg3.jpg'

const HomeBodyPart2 = () => {
    return (
        <div>
            <Container class='container'>
                <Row>
                    <Col sm={6}>
                        <h1 title='Header1' class='heading1'>Tackling the climate challenge</h1>
                        <p data-testid="para" class='para1'>Find out how we’re supporting our customers, through our products & partnerships, to tackle the climate challenge.</p>
                        <a class='h1link' href='#!'>Our approach to climate change</a>
                    </Col>
                    <Col sm={6}>
                        <img
                            className="d-block w-100"
                            src={homeImg3}
                            alt='home1' />
                    </Col>
                </Row>
            </Container>
        </div>
    )
}

export default HomeBodyPart2