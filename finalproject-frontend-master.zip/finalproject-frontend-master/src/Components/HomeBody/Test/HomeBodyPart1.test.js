import { render, screen } from "@testing-library/react";
import HomeBodyPart1 from "../HomeBodyPart1";

test('testing home header', () => {
    render(<HomeBodyPart1 />);
    const headingElement = screen.getByTitle("Header1")
    expect(headingElement).toBeInTheDocument();
});

test('testing home paragraph', () => {
    render(<HomeBodyPart1 />);
    const headingElement = screen.getByTestId("para")
    expect(headingElement).toBeInTheDocument();
});