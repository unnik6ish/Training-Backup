import { render, screen } from "@testing-library/react";
import HomeBodyPart3 from "../HomeBodyPart3";

test('testing home header', () => {
    render(<HomeBodyPart3 />);
    const headingElement = screen.getByTitle("Header1")
    expect(headingElement).toBeInTheDocument();
});

test('testing home paragraph', () => {
    render(<HomeBodyPart3 />);
    const headingElement = screen.getByTestId("para")
    expect(headingElement).toBeInTheDocument();
});