import { render, screen } from "@testing-library/react";
import HomeBodyPart2 from "../HomeBodyPart2";


test('testing home header', () => {
    render(<HomeBodyPart2/>);
    const headingElement = screen.getByTitle("Header1")
    expect(headingElement).toBeInTheDocument();
});

test('testing home paragraph', () => {
    render(<HomeBodyPart2/>);
    const headingElement = screen.getByTestId("para")
    expect(headingElement).toBeInTheDocument();
});