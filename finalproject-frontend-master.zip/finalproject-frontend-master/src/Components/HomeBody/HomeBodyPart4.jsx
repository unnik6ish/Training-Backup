import React from 'react'
import { Col, Container, Row } from 'react-bootstrap'
import homeImg5 from '../../images/homeImg5.jpg'

const HomeBodyPart2 = () => {
    return (
        <div style={{backgroundColor:"#5a287d"}}>
            <Container class='container'>
                <Row>
                    <Col sm={6}>
                        <h1 class='heading1'style={{color:"white"}}>Detecting and preventing financial crime</h1>
                        <p  class='para1' style={{color:"white"}}>At NatWest Group we recognise the important role we have to play to detect and prevent financial crime, protecting people, families, and businesses.</p>
                        <a class='h1link' href='#!' style={{color:"white"}}>Find out more</a>
                    </Col>
                    <Col sm={6}>
                        <img
                            className="d-block w-100"
                            src={homeImg5}
                            alt='home1' />
                    </Col>
                </Row>
            </Container>
        </div>
    )
}

export default HomeBodyPart2