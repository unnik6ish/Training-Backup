import React from 'react'
import { Container, Nav, Navbar } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import NWLogo from '../../images/NWLogo.png'

const NavbarForContact = () => {

    const navigate = useNavigate();

    const routeToHome = () => {
        navigate('/')
    }
    return (
        <div>
            <Navbar collapseOnSelect expand="lg" style={{ backgroundColor: 'white' }} variant="#401664">
                <Container>
                    <Navbar.Brand>
                        <img className='navImage'
                            alt="Natwest Logo"
                            src={NWLogo}
                        />
                    </Navbar.Brand>
                    <Navbar.Toggle aria-controls="responsive-navbar-nav" />
                    <Navbar.Collapse id="responsive-navbar-nav" className="justify-content-end">
                        <Nav>
                            <Nav.Link class='nav-link' style={{ color: "#5e10b1" }} onClick={routeToHome}>Home</Nav.Link>
                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>
        </div>
    )
}

export default NavbarForContact