import React from 'react'
import ContactBodyPart1 from '../ContactBody/ContactBodyPart1'
import ContactBodyPart2 from '../ContactBody/ContactBodyPart2'
import ContactBodyPart3 from '../ContactBody/ContactBodyPart3'
import Footer from '../Footer/Footer'
import NavbarForContact from './NavbarForContact'

const ContactPage = () => {
  return (
    <div>
        <NavbarForContact />
        <ContactBodyPart1 />
        <ContactBodyPart2 />
        <ContactBodyPart3 />
        <Footer />
    </div>
  )
}

export default ContactPage