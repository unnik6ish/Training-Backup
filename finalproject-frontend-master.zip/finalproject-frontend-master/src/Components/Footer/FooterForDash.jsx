import React from 'react'

const FooterForDash = () => {
    return (
        <div className='pt-5 pb-5'style={{fontFamily:"RNHouseSansRegular,sans-serif"}}>
            <footer class="bg-light text-center" style={{color:"#5e10b1"}}>
                <div class="text-center p-3" style={{ backgroundColor: 'white', color:"#5e10b1"}}>
                    © 2022 Copyright : NatWest Group 2022
                </div>
            </footer>

        </div>
    )
}

export default FooterForDash