import { MDBCol, MDBContainer, MDBFooter, MDBRow } from 'mdb-react-ui-kit'
import React from 'react'

const Footer = () => {
    return (
        <div style={{fontFamily:"RNHouseSansRegular,sans-serif"}}>
            <MDBFooter bgColor='white' className='text-center text-lg-start text-muted'>
                <section className=''>
                    <MDBContainer className='text-center text-md-start' style={{color:"#5e10b1"}}>
                        <MDBRow>
                            <MDBCol md="3" lg="4" xl="3" className='mx-auto mb-4'>
                                <h6 className='fw-bold mb-4 mt-4'style={{color:"black"}}>
                                    NatWest Group
                                </h6>
                                <p style={{color:"#5e10b1"}}>
                                    Here you can find all the useful links.
                                </p>
                            </MDBCol>
                            <MDBCol md="2" lg="2" xl="2" className='mx-auto mb-4 mt-4' >
                                <h6 className='fw-bold mb-4' style={{color:"black"}}>Products</h6>
                                <p>
                                    <a href='#!' className='text-reset' >
                                        Loans
                                    </a>
                                </p>
                                <p>
                                    <a href='#!' className='text-reset' >
                                        Credit Card
                                    </a>
                                </p>
                                <p>
                                    <a href='#!' className='text-reset' >
                                        Fixed Deposit
                                    </a>
                                </p>
                                <p>
                                    <a href='#!' className='text-reset' >
                                        Saving Account
                                    </a>
                                </p>
                            </MDBCol>

                            <MDBCol md="3" lg="2" xl="2" className='mx-auto mb-4 mt-4'>
                                <h6 className='fw-bold mb-4' style={{color:"black"}}>Useful links</h6>
                                <p>
                                    <a href='#!' className='text-reset'>
                                        Pricing
                                    </a>
                                </p>
                                <p>
                                    <a href='#!' className='text-reset'>
                                        Settings
                                    </a>
                                </p>
                                <p>
                                    <a href='#!' className='text-reset'>
                                        Orders
                                    </a>
                                </p>
                                <p>
                                    <a href='#!' className='text-reset'>
                                        Help
                                    </a>
                                </p>
                            </MDBCol>

                            <MDBCol md="4" lg="3" xl="3" className='mx-auto mb-md-0 mb-4 mt-4'>
                                <h6 className='fw-bold mb-4' style={{color:"black"}}>Contact</h6>
                                <p>
                                    36 St Andrew Square, Edinburgh, United Kingdom, EH2 2YB.
                                </p>
                                <p>
                                    n.service@natwestgroup.com
                                </p>
                                <p>
                                    +022-40021534
                                </p>
                                <p>
                                    +022-40021535
                                </p>
                            </MDBCol>
                        </MDBRow>
                    </MDBContainer>
                </section>

                <div className='text-center p-4' style={{ backgroundColor: '#f4f0e8', color:"#5e10b1"}}>
                    © 2022 Copyright : NatWest Group 2022
                </div>
            </MDBFooter>
        </div>
    )
}

export default Footer