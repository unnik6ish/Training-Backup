import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Container, Table } from 'react-bootstrap';
import FooterForDash from '../Footer/FooterForDash';
import NavForLoanApp from '../LoanApplication/NavForLoanApp';

const ApplicationTable = () => {

    let loggedUser = JSON.parse(localStorage.getItem('loggedUser'))

    const [loanAppDetails, setLoanAppDetails] = useState([])

    useEffect(() => {
        loadLoanDetails();
    }, []);

    const loadLoanDetails = () => {
        axios.get(`http://localhost:8080/loandetails/accno?accno=${loggedUser.accno}`)
            .then(response => setLoanAppDetails(response.data))
            .catch(error => console.log(error))
    };

    return (
        <div className='text-center'>
            <NavForLoanApp />
            <Container className='mt-2 pt-2' style={{ backgroundColor: '#f4f0e8' }}>
                <h4 className='text-center pt-3 pb-3' style={{ color: "#401664" }}>Your submissions</h4>
                <Table striped bordered hover style={{ border: "black", backgroundColor: 'white' }}>
                    <thead>
                        <tr style={{ backgroundColor: '#401664', color: 'white' }}>
                            <th>Loan Application</th>
                            <th>Loan Amount</th>
                            <th>Business</th>
                            <th>Car Model</th>
                            <th>Employement</th>
                            <th>Experience</th>
                            <th>Income</th>
                            <th>Tenure</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            loanAppDetails.map(data => (
                                <tr key={data.loanappno}>
                                    <td>{data.loanappno}</td>
                                    <td>{data.amount}</td>
                                    <td>{data.business}</td>
                                    <td>{data.carmodel}</td>
                                    <td>{data.employment}</td>
                                    <td>{data.experience}</td>
                                    <td>{data.income}</td>
                                    <td>{data.tenure}</td>
                                    <td>{data.status}</td>
                                </tr>
                            ))}
                    </tbody>
                </Table>
            </Container>
            <FooterForDash />
        </div>
    )
}

export default ApplicationTable