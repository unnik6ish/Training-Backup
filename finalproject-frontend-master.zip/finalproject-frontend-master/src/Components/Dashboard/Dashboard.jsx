import React from 'react'
import { Button, Card, Col, Container, Row } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom';
import dashImgCar from '../../images/dashImgCar.jpg'
import dashImgHome from '../../images/dashImgHome.jpg'
import dashImgPersonal from '../../images/dashImgPersonal.jpg'
import FooterForDash from '../Footer/FooterForDash';
import NavBarForDashboard from './NavBarForDashboard';

const Dashboard = () => {

  const navigate = useNavigate();

  const RouteToLoanapplication = () => {
    navigate('/loanapplication')
  }

  return (
    <div>
      <NavBarForDashboard />
      <div className="py-1 m-auto" style={{ backgroundColor: '#f4f0e8' }}>
        <Container>
          <Row className="d-flex align-items-center justify-content-center">
            <Col className="py-5 d-flex align-items-center justify-content-center" >
              <Card border="light" style={{ width: '18rem' }} >
                <Card.Img variant="top" src={dashImgCar} />
                <Card.Body>
                  <Card.Title>Car Loan</Card.Title>
                  <Card.Text>
                    Choose the below option if you are looking new car loan with zero % interest.
                  </Card.Text>
                  <Button style={{backgroundColor:"#5B1F8E", borderColor:"#5B1F8E"}} onClick={RouteToLoanapplication}>Click Here</Button>
                </Card.Body>
              </Card>
            </Col>
            <Col className="py-5 d-flex align-items-center justify-content-center" >
              <Card style={{ width: '18rem' }} >
                <Card.Img variant="top" src={dashImgHome} />
                <Card.Body>
                  <Card.Title>Home Loan</Card.Title>
                  <Card.Text>
                    Choose the below option if you are looking for new homeloan with low interest.
                  </Card.Text>
                  <Button style={{backgroundColor:"#5B1F8E", borderColor:"#5B1F8E"}} disabled>Click Here</Button>
                </Card.Body>
              </Card>
            </Col>
            <Col className="py-5 d-flex align-items-center justify-content-center" >
              <Card style={{ width: '18rem' }} >
                <Card.Img variant="top" src={dashImgPersonal} />
                <Card.Body>
                  <Card.Title>Personal Loan</Card.Title>
                  <Card.Text>
                    Choose the below option if you are looking for new homeloan with low interest.
                  </Card.Text>
                  <Button disabled style={{backgroundColor:"#5B1F8E", borderColor:"#5B1F8E"}}>Click Here</Button>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Container>
      </div>
      <FooterForDash />
    </div>
  )
}

export default Dashboard