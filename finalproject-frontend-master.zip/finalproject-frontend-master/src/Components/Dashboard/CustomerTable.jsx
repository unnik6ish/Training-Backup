import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Container, Table } from 'react-bootstrap';
import FooterForDash from '../Footer/FooterForDash';
import NavForCustomerTable from './NavForCustomerTable';

const CustomerTable = () => {

    const [customerDetails, setCustomerDetails] = useState([])

    useEffect(() => {
        getUserDetails();
    }, []);

    const getUserDetails = () => {

        axios.get(`http://localhost:8080/loanusers`)
            .then(res => setCustomerDetails(res.data))
            .catch(err => console.log(err))

    }

    return (
        <div className='text-center'>
            <NavForCustomerTable />
            <Container className='mt-2 pt-2' style={{ backgroundColor: '#f4f0e8' }}>
                <h4 className='text-center pt-3 pb-3' style={{ color: "#401664" }}>Customer Details</h4>
                <Table striped bordered hover style={{ border: "black", backgroundColor: 'white' }}>
                    <thead>
                        <tr style={{ backgroundColor: '#401664', color: 'white' }}>
                            <th>Account No</th>
                            <th>Customer Name</th>
                            <th>Mobile No</th>
                            <th>Email ID</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            customerDetails.map(data => (
                                <tr key={data.id}>
                                    <td>{data.accno}</td>
                                    <td>{data.name}</td>
                                    <td>{data.mobno}</td>
                                    <td>{data.id}</td>
                                </tr>
                            ))}
                    </tbody>
                </Table>
            </Container>
            <FooterForDash />
        </div>
    )
}

export default CustomerTable