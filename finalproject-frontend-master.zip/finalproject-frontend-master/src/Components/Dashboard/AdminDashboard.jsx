import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Button, Container, Table } from 'react-bootstrap'
import FooterForDash from '../Footer/FooterForDash';
import NavBarForAdmin from '../Login/NavBarForAdmin';

const AdminDashboard = () => {

  const [loanDetails, setLoanDetails] = useState([])

  let getLoan;

  useEffect(() => {
    getLoanDetails();
  });

  const getLoanDetails = () => {
    axios.get("http://localhost:8080/loandetails")
      .then(response => setLoanDetails(response.data))
      .catch(error => console.log(error))
  }

  const acceptLoan = (e) => {
    console.log(e.target.id);
    var loanID = e.target.id
    axios.get(`http://localhost:8080/loandetails/${loanID}`)
      .then(response => {
        console.log(response)
        getLoan = response.data
        getLoan["status"] = "Accepted"
        console.log(getLoan);
      })
      .catch(error => console.log(error))
    setTimeout(() => {
      axios.put(`http://localhost:8080/loandetails`, getLoan)
        .then(response => console.log(response))
        .catch(error => console.log(error))
    }, 1000);
    getLoanDetails()
  }
  const rejectLoan = (e) => {
    console.log(e.target.id);
    var loanID = e.target.id
    axios.get(`http://localhost:8080/loandetails/${loanID}`)
      .then(response => {
        console.log(response)
        getLoan = response.data
        getLoan["status"] = "Rejected"
        console.log(getLoan);
      })
      .catch(error => console.log(error))
    setTimeout(() => {
      axios.put(`http://localhost:8080/loandetails`, getLoan)
        .then(response => console.log(response))
        .catch(error => console.log(error))
    }, 1000);
    getLoanDetails()
  }

  return (
    <div className='text-center'>
      <NavBarForAdmin />
      <Container className='mt-2 pt-2' style={{ backgroundColor: '#f4f0e8' }}>
        <h4 className='text-center pt-3 pb-3' style={{ color: "#401664" }} >Loan Applications</h4>
        <Table striped bordered hover style={{ border: "black", backgroundColor: 'white' }}>
          <thead>
            <tr style={{ backgroundColor: '#401664', color: 'white' }}>
              <th>Employement</th>
              <th>Business</th>
              <th>Experience</th>
              <th>Icome</th>
              <th>Loan Amount</th>
              <th>Tenture</th>
              <th>Credit Score</th>
              <th>Status</th>
              <th>Accept/Reject</th>
            </tr>
          </thead>
          <tbody>
            {
              loanDetails.map(data => (
                <tr key={data.loanappno}>
                  <td>{data.employment}</td>
                  <td>{data.business}</td>
                  <td>{data.experience}</td>
                  <td>{data.income}</td>
                  <td>{data.amount}</td>
                  <td>{data.tenure}</td>
                  <td>{data.creditscore}</td>
                  <td>{data.status}</td>
                  <td>
                    <Button id={data.loanappno} onClick={acceptLoan} variant="success" className='m-2 btn'>Accept</Button>
                    <Button id={data.loanappno} onClick={rejectLoan} variant="danger" >Reject</Button>
                  </td>
                </tr>
              ))}
          </tbody>
        </Table>
      </Container>
      <FooterForDash />
    </div>
  )
}

export default AdminDashboard