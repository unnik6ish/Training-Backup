package com.example.demo.service;

import java.util.List;

import com.example.demo.exception.UserAlreadyExistException;
import com.example.demo.exception.UserNotFoundException;
import com.example.demo.model.InstLoanAppUsers;

public interface InstLoanAppUsersService {

	public InstLoanAppUsers registerUser(InstLoanAppUsers instLoanAppUsers) throws UserAlreadyExistException; //post request - save a user record
	public InstLoanAppUsers findUserbyId(String username) throws UserNotFoundException; // get request - retrieve a record
	public List<InstLoanAppUsers> getAllUser(); //get request - to retrieve all records
	public InstLoanAppUsers deleteAUser(String username); //delete request
	public InstLoanAppUsers updateAUser(InstLoanAppUsers instLoanAppUsers); // PUT - PATCH request
	
	
	
	
	
	
	
	
	
}
